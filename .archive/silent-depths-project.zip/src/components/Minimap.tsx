import { useEffect, useRef } from "react";
import type { GameState, TerrainCell } from "@/game/types";
import { WORLD_SIZE } from "@/game/world";

export type MinimapSnapshot = {
  subX: number;
  subY: number;
  subHeading: number;
  ships: { x: number; y: number; cls: string }[];
  /** Hydrophone / ASDIC picture — preferred over raw ship list. */
  contacts: { x: number; y: number; label: string; source: string; strength: number }[];
  powerups: { x: number; y: number; kind: string }[];
  baseX: number;
  baseY: number;
  baseRadius: number;
  seed: number;
  time: number;
  docked: boolean;
  sonarPing: number;
};

const KIND_COLOR: Record<string, string> = {
  health: "#f07178",
  ammo: "#e6c07b",
  hull: "#94a3b8",
  weapon: "#fb923c",
  speed: "#5eead4",
  counter: "#3b9eff",
};

/** Top-down radar-style minimap. Click plots a course. */
export function Minimap({
  snap,
  terrain,
  size = 148,
  onPlot,
}: {
  snap: MinimapSnapshot | null;
  terrain: TerrainCell[][] | null;
  size?: number;
  onPlot?: (wx: number, wy: number) => void;
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const landCache = useRef<{ seed: number; data: ImageData } | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || !snap || !terrain) return;
    const dpr = Math.min(window.devicePixelRatio || 1, 1.5);
    const css = size;
    if (canvas.width !== Math.floor(css * dpr) || canvas.height !== Math.floor(css * dpr)) {
      canvas.width = Math.floor(css * dpr);
      canvas.height = Math.floor(css * dpr);
      canvas.style.width = `${css}px`;
      canvas.style.height = `${css}px`;
    }
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

    // Land base layer (cached per seed)
    if (!landCache.current || landCache.current.seed !== snap.seed) {
      const off = document.createElement("canvas");
      off.width = css;
      off.height = css;
      const octx = off.getContext("2d")!;
      const img = octx.createImageData(css, css);
      const data = img.data;
      for (let py = 0; py < css; py++) {
        for (let px = 0; px < css; px++) {
          const wx = (px / css) * WORLD_SIZE;
          const wy = (py / css) * WORLD_SIZE;
          const tx = Math.min(WORLD_SIZE - 1, Math.max(0, wx | 0));
          const ty = Math.min(WORLD_SIZE - 1, Math.max(0, wy | 0));
          const cell = terrain[ty]?.[tx];
          const i = (py * css + px) * 4;
          if (!cell) {
            data[i] = 6;
            data[i + 1] = 12;
            data[i + 2] = 20;
            data[i + 3] = 255;
            continue;
          }
          if (cell.land) {
            data[i] = 42;
            data[i + 1] = 52;
            data[i + 2] = 48;
            data[i + 3] = 255;
          } else if (cell.height > 0.55) {
            data[i] = 22;
            data[i + 1] = 48;
            data[i + 2] = 62;
            data[i + 3] = 255;
          } else {
            const d = 1 - cell.height;
            data[i] = (8 + d * 6) | 0;
            data[i + 1] = (22 + d * 18) | 0;
            data[i + 2] = (36 + d * 28) | 0;
            data[i + 3] = 255;
          }
        }
      }
      octx.putImageData(img, 0, 0);
      landCache.current = { seed: snap.seed, data: img };
      // store canvas instead for draw
      (landCache.current as any).canvas = off;
    }

    const landCanvas = (landCache.current as any).canvas as HTMLCanvasElement;
    ctx.drawImage(landCanvas, 0, 0, css, css);

    // Soft vignette
    const vg = ctx.createRadialGradient(css / 2, css / 2, css * 0.35, css / 2, css / 2, css * 0.72);
    vg.addColorStop(0, "rgba(0,0,0,0)");
    vg.addColorStop(1, "rgba(0,0,0,0.35)");
    ctx.fillStyle = vg;
    ctx.fillRect(0, 0, css, css);

    const toPx = (wx: number, wy: number) => ({
      x: (wx / WORLD_SIZE) * css,
      y: (wy / WORLD_SIZE) * css,
    });

    // Base
    {
      const p = toPx(snap.baseX, snap.baseY);
      const rr = (snap.baseRadius / WORLD_SIZE) * css;
      ctx.strokeStyle = snap.docked ? "rgba(127,217,154,0.9)" : "rgba(94,234,212,0.75)";
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.arc(p.x, p.y, Math.max(4, rr), 0, Math.PI * 2);
      ctx.stroke();
      ctx.fillStyle = snap.docked ? "rgba(127,217,154,0.85)" : "rgba(94,234,212,0.75)";
      ctx.beginPath();
      ctx.arc(p.x, p.y, 2.5, 0, Math.PI * 2);
      ctx.fill();
    }

    // Powerups
    for (const pu of snap.powerups) {
      const p = toPx(pu.x, pu.y);
      ctx.fillStyle = KIND_COLOR[pu.kind] ?? "#a0a0ab";
      ctx.beginPath();
      ctx.arc(p.x, p.y, 2.2, 0, Math.PI * 2);
      ctx.fill();
    }

    // Sonar contacts (realistic picture) — fall back to ships if empty list still bootstrapping
    const contacts = snap.contacts ?? [];
    if (contacts.length > 0) {
      for (const c of contacts) {
        const p = toPx(c.x, c.y);
        const active = c.source === "active";
        ctx.fillStyle = active ? "#3b9eff" : "#5eead4";
        ctx.globalAlpha = 0.45 + c.strength * 0.55;
        ctx.beginPath();
        ctx.arc(p.x, p.y, active ? 2.8 : 2.1, 0, Math.PI * 2);
        ctx.fill();
        if (active) {
          ctx.strokeStyle = "rgba(255,255,255,0.5)";
          ctx.lineWidth = 1;
          ctx.beginPath();
          ctx.arc(p.x, p.y, 4, 0, Math.PI * 2);
          ctx.stroke();
        }
        ctx.globalAlpha = 1;
      }
    } else {
      for (const sh of snap.ships) {
        const p = toPx(sh.x, sh.y);
        ctx.fillStyle =
          sh.cls === "sub" ? "#ff8060" : sh.cls === "battleship" ? "#fbbf24" : "#f07178";
        ctx.beginPath();
        ctx.arc(p.x, p.y, sh.cls === "battleship" ? 2.8 : 2.1, 0, Math.PI * 2);
        ctx.fill();
      }
    }

    // Active ping ring on minimap
    if (snap.sonarPing > 0) {
      const age = Math.max(0, 4.8 - snap.sonarPing);
      const r = Math.min(css * 0.48, (age / 1.05) * (22 / 96) * css);
      const p = toPx(snap.subX, snap.subY);
      ctx.strokeStyle = `rgba(59,158,255,${0.55 * (1 - age / 1.2)})`;
      ctx.lineWidth = 1.2;
      ctx.beginPath();
      ctx.arc(p.x, p.y, Math.max(2, r), 0, Math.PI * 2);
      ctx.stroke();
    }

    // Player
    {
      const p = toPx(snap.subX, snap.subY);
      const ang = snap.subHeading;
      ctx.save();
      ctx.translate(p.x, p.y);
      ctx.rotate(ang);
      ctx.fillStyle = "#5eead4";
      ctx.beginPath();
      ctx.moveTo(5, 0);
      ctx.lineTo(-4, 3.2);
      ctx.lineTo(-2.5, 0);
      ctx.lineTo(-4, -3.2);
      ctx.closePath();
      ctx.fill();
      // pulse ring
      ctx.strokeStyle = `rgba(94,234,212,${0.35 + Math.sin(snap.time * 3) * 0.2})`;
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.arc(0, 0, 7, 0, Math.PI * 2);
      ctx.stroke();
      ctx.restore();
    }

    // Border
    ctx.strokeStyle = "rgba(232,238,246,0.18)";
    ctx.lineWidth = 1;
    ctx.strokeRect(0.5, 0.5, css - 1, css - 1);
  }, [snap, terrain, size]);

  const handleClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!onPlot || !snap) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const px = e.clientX - rect.left;
    const py = e.clientY - rect.top;
    const wx = (px / rect.width) * WORLD_SIZE;
    const wy = (py / rect.height) * WORLD_SIZE;
    onPlot(wx, wy);
  };

  return (
    <div className="pointer-events-auto select-none">
      <div className="overflow-hidden rounded-xl border border-border bg-surface/90 shadow-lg backdrop-blur-md">
        <div className="flex items-center justify-between border-b border-border/60 px-2.5 py-1">
          <span className="font-mono text-[10px] uppercase tracking-wider text-muted">
            Sector map
          </span>
          <span className="font-mono text-[9px] text-subtle">tap to plot</span>
        </div>
        <canvas
          ref={canvasRef}
          className="block cursor-crosshair"
          width={size}
          height={size}
          onClick={handleClick}
          aria-label="Minimap — click to set course"
        />
        <div className="flex flex-wrap gap-x-2 gap-y-0.5 border-t border-border/60 px-2 py-1 text-[9px] text-muted">
          <span className="inline-flex items-center gap-1">
            <i className="inline-block h-1.5 w-1.5 rounded-full bg-accent" /> You
          </span>
          <span className="inline-flex items-center gap-1">
            <i className="inline-block h-1.5 w-1.5 rounded-full bg-sonar" /> Contact
          </span>
          <span className="inline-flex items-center gap-1">
            <i className="inline-block h-1.5 w-1.5 rounded-full bg-accent-dim" /> FOB
          </span>
          <span className="inline-flex items-center gap-1">
            <i className="inline-block h-1.5 w-1.5 rounded-full bg-warn" /> Crate
          </span>
        </div>
      </div>
    </div>
  );
}

export function buildMinimapSnap(state: GameState): MinimapSnapshot {
  return {
    subX: state.sub.x,
    subY: state.sub.y,
    subHeading: state.sub.displayHeading,
    ships: state.ships
      .filter((s) => !s.dead)
      .map((s) => ({ x: s.x, y: s.y, cls: s.class })),
    contacts: (state.sonarContacts ?? []).map((c) => ({
      x: c.x,
      y: c.y,
      label: c.label,
      source: c.source,
      strength: c.strength,
    })),
    powerups: state.powerups.map((p) => ({ x: p.x, y: p.y, kind: p.kind })),
    baseX: state.base.x,
    baseY: state.base.y,
    baseRadius: state.base.radius,
    seed: state.seed,
    time: state.time,
    docked: state.sub.docked > 0,
    sonarPing: state.sonarPing ?? 0,
  };
}
