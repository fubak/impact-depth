import {
  useCallback,
  useEffect,
  useLayoutEffect,
  useRef,
  useState,
  type CSSProperties,
} from "react";
import { ChevronLeft, ChevronRight, GraduationCap, X } from "lucide-react";

export type TutorialAnchor =
  | "center"
  | "status"
  | "depth"
  | "tactics"
  | "magazine"
  | "minimap"
  | "contacts"
  | "canvas";

export interface TutorialStep {
  id: string;
  title: string;
  body: string;
  tip?: string;
  anchor: TutorialAnchor;
  /** Optional action label shown under tip */
  action?: string;
}

const STEPS: TutorialStep[] = [
  {
    id: "welcome",
    title: "Welcome aboard, Captain",
    body: "This short tour walks you through helm, stealth, weapons, and combat AI. You can skip anytime and reopen Help from the HUD.",
    tip: "The ocean is isometric — dark blue is deep water, land is impassable.",
    anchor: "center",
  },
  {
    id: "course",
    title: "Plot a course",
    body: "Click or tap open water to set a waypoint. Your boat steers around shoals automatically. Drag to pan the camera; double-click recenters on the sub.",
    tip: "Right-click fires the selected weapon toward that point.",
    action: "Try clicking the sea to move",
    anchor: "canvas",
  },
  {
    id: "status",
    title: "Hull, battery & noise",
    body: "Top-left is your boat status. Hull is life. Battery drains when submerged — surface or snorkel to charge. Noise is how loud you are to enemy hydrophones.",
    tip: "Night / Layer badges show time of day and whether you're above or below the thermocline.",
    anchor: "status",
  },
  {
    id: "depth",
    title: "Depth & speed",
    body: "Bottom-left sets depth bands and speed orders. Surface is fast but deadly. Periscope depth for shots. Deep is quiet and safer from deck guns — but slower.",
    tip: "Dead Slow + Silent is your default transit profile.",
    anchor: "depth",
  },
  {
    id: "tactics",
    title: "Stealth tactics",
    body: "Silent caps speed and noise. Scope raises the periscope (peri depth only) for visual risk. Snorkel charges batteries but lights you up to escorts and aircraft.",
    tip: "Below: Ambush / Stalk / Intercept / Evade / RTB hand the helm to combat AI.",
    action: "Pick a ship, then Ambush to see AI drive",
    anchor: "tactics",
  },
  {
    id: "ambush",
    title: "Ambush doctrine",
    body: "Ambush: silent deep approach to the target's beam → rise to peri → fire a Mk-14 spread → break contact deep and quiet. Best against freighters on a steady course.",
    tip: "Stalk trails quietly; Intercept closes hard; Evade breaks contact; RTB docks at FOB.",
    anchor: "tactics",
  },
  {
    id: "magazine",
    title: "Magazine & sonar",
    body: "Mk-14 straight runners, Mk-18 acoustic seekers, Foxer decoys, and bubble screens. Exact counts and reload bars show tube state. Sonar pings for range — but everyone hears you.",
    tip: "Use Spread for multi-fish Mk-14 attacks. Fire only at peri / attack depth.",
    anchor: "magazine",
  },
  {
    id: "contacts",
    title: "Hydrophone picture",
    body: "Contacts list bearings and rough class from passive listening. Active returns are sharper but cost noise and alert escorts. Damaged sonar degrades this picture.",
    tip: "Click a contact ship in the world to lock a target for AI or manual fire.",
    anchor: "contacts",
  },
  {
    id: "minimap",
    title: "Minimap & FOB",
    body: "Bottom-right is the tactical plot. Cyan ring is FOB Argus — dock there to repair hull, systems, restock tubes, and recharge. You cannot be attacked inside the safe zone.",
    tip: "Click the minimap to plot a long-range course. Supply crates upgrade hull, warheads, and engines.",
    anchor: "minimap",
  },
  {
    id: "threats",
    title: "What hunts you",
    body: "Destroyers throw Hedgehog ahead when they have a solution. Battleships drop depth charges. Enemy U-boats fire torpedoes. Aircraft punish masts and shallow noise.",
    tip: "If held down: Silent + deep under the layer, bubble screen, then RTB if flooding.",
    anchor: "center",
  },
  {
    id: "done",
    title: "You're on station",
    body: "Sink enough ships to clear the sector. Co-op captains can join mid-patrol. Reopen this guide anytime with Help.",
    tip: "Fair winds — stay quiet, shoot from the beam, and get home.",
    action: "End tutorial and take the conn",
    anchor: "center",
  },
];

const STORAGE_KEY = "silent-depths-tutorial-v1";
const PAD = 10;

export function tutorialWasCompleted(): boolean {
  try {
    return localStorage.getItem(STORAGE_KEY) === "1";
  } catch {
    return false;
  }
}

export function markTutorialComplete() {
  try {
    localStorage.setItem(STORAGE_KEY, "1");
  } catch {
    /* ignore */
  }
}

export interface SpotlightRect {
  x: number;
  y: number;
  w: number;
  h: number;
  /** Element found and measured live */
  live: boolean;
}

/** data-tutorial attribute candidates for each anchor (first visible wins). */
const ANCHOR_SELECTORS: Record<TutorialAnchor, string[]> = {
  center: [],
  status: ['[data-tutorial="status"]'],
  depth: ['[data-tutorial="depth"]'],
  tactics: ['[data-tutorial="tactics"]'],
  magazine: ['[data-tutorial="magazine"]'],
  minimap: [
    '[data-tutorial="minimap"]',
    '[data-tutorial="minimap-mobile"]',
  ],
  contacts: ['[data-tutorial="contacts"]'],
  canvas: ["canvas"],
};

function isVisible(el: Element): boolean {
  const style = window.getComputedStyle(el);
  if (style.display === "none" || style.visibility === "hidden") return false;
  const r = el.getBoundingClientRect();
  return r.width > 2 && r.height > 2;
}

function queryAnchor(anchor: TutorialAnchor): Element | null {
  const sels = ANCHOR_SELECTORS[anchor] ?? [];
  for (const sel of sels) {
    const nodes = document.querySelectorAll(sel);
    for (const n of nodes) {
      if (isVisible(n)) return n;
    }
  }
  return null;
}

/** Fallback rects if DOM target missing (viewport-relative px). */
function fallbackRect(anchor: TutorialAnchor, vw: number, vh: number): SpotlightRect | null {
  switch (anchor) {
    case "status":
      return { x: 8, y: 8, w: Math.min(320, vw * 0.3), h: Math.min(160, vh * 0.2), live: false };
    case "contacts":
      return { x: 8, y: vh * 0.16, w: Math.min(180, vw * 0.22), h: Math.min(200, vh * 0.28), live: false };
    case "magazine":
      return {
        x: 8,
        y: vh - Math.min(140, vh * 0.2) - 12,
        w: Math.min(vw * 0.55, 520),
        h: Math.min(120, vh * 0.16),
        live: false,
      };
    case "tactics":
      return {
        x: 8,
        y: vh - Math.min(280, vh * 0.36) - 12,
        w: Math.min(vw * 0.4, 360),
        h: Math.min(200, vh * 0.28),
        live: false,
      };
    case "depth":
      return {
        x: 8,
        y: vh - Math.min(200, vh * 0.26) - 12,
        w: Math.min(vw * 0.42, 400),
        h: Math.min(100, vh * 0.14),
        live: false,
      };
    case "minimap":
      return {
        x: vw - Math.min(180, vw * 0.22) - 12,
        y: vh - Math.min(200, vh * 0.28) - 12,
        w: Math.min(168, vw * 0.2),
        h: Math.min(168, vh * 0.24),
        live: false,
      };
    case "canvas":
      return {
        x: vw * 0.14,
        y: vh * 0.18,
        w: vw * 0.72,
        h: vh * 0.5,
        live: false,
      };
    case "center":
    default:
      return null;
  }
}

function measureSpotlight(
  anchor: TutorialAnchor,
  root: HTMLElement | null,
): SpotlightRect | null {
  const vw = window.innerWidth;
  const vh = window.innerHeight;
  if (anchor === "center") return null;

  const el = queryAnchor(anchor);
  const rootRect = root?.getBoundingClientRect();
  const ox = rootRect?.left ?? 0;
  const oy = rootRect?.top ?? 0;

  if (el) {
    const r = el.getBoundingClientRect();
    return {
      x: Math.max(0, r.left - ox - PAD),
      y: Math.max(0, r.top - oy - PAD),
      w: Math.min(vw, r.width + PAD * 2),
      h: Math.min(vh, r.height + PAD * 2),
      live: true,
    };
  }

  const fb = fallbackRect(anchor, vw, vh);
  if (!fb) return null;
  return {
    ...fb,
    x: fb.x - ox,
    y: fb.y - oy,
  };
}

type CardPlace = "center" | "top" | "bottom" | "left" | "right";

/** Place tutorial card opposite the spotlight so it doesn't cover the target. */
function pickCardPlacement(spot: SpotlightRect | null, vw: number, vh: number): CardPlace {
  if (!spot) return "center";
  const cx = spot.x + spot.w / 2;
  const cy = spot.y + spot.h / 2;
  const space = {
    top: spot.y,
    bottom: vh - (spot.y + spot.h),
    left: spot.x,
    right: vw - (spot.x + spot.w),
  };
  // Prefer the largest free region
  const entries = Object.entries(space) as [CardPlace, number][];
  entries.sort((a, b) => b[1] - a[1]);
  const best = entries[0]![0];
  // If spotlight is very central, still use best free edge
  if (entries[0]![1] < 120) {
    // tiny free space — put card opposite center of mass
    if (cy < vh * 0.45) return "bottom";
    if (cy > vh * 0.55) return "top";
    return cx < vw * 0.5 ? "right" : "left";
  }
  return best;
}

function cardLayoutClass(place: CardPlace): string {
  switch (place) {
    case "top":
      return "items-start justify-center pt-6 px-4";
    case "bottom":
      return "items-end justify-center pb-6 px-4";
    case "left":
      return "items-center justify-start pl-4 pr-4";
    case "right":
      return "items-center justify-end pl-4 pr-4";
    default:
      return "items-center justify-center px-4";
  }
}

export function TutorialOverlay({
  open,
  onClose,
  onComplete,
}: {
  open: boolean;
  onClose: () => void;
  onComplete: () => void;
}) {
  const [step, setStep] = useState(0);
  const rootRef = useRef<HTMLDivElement>(null);
  const [spot, setSpot] = useState<SpotlightRect | null>(null);
  const [place, setPlace] = useState<CardPlace>("center");
  const current = STEPS[step]!;

  const remeasure = useCallback(() => {
    if (!open) return;
    const rect = measureSpotlight(current.anchor, rootRef.current);
    setSpot(rect);
    const vw = window.innerWidth;
    const vh = window.innerHeight;
    setPlace(pickCardPlacement(rect, vw, vh));
  }, [open, current.anchor, step]);

  useEffect(() => {
    if (open) setStep(0);
  }, [open]);

  useLayoutEffect(() => {
    if (!open) return;
    remeasure();
  }, [open, step, remeasure]);

  useEffect(() => {
    if (!open) return;

    let raf = 0;
    const schedule = () => {
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(remeasure);
    };

    window.addEventListener("resize", schedule);
    window.addEventListener("scroll", schedule, true);
    // HUD may layout after mount / orientation change
    const ro = typeof ResizeObserver !== "undefined" ? new ResizeObserver(schedule) : null;
    ro?.observe(document.documentElement);
    const hud = document.querySelector('[data-tutorial="status"]')?.closest(".absolute");
    if (hud) ro?.observe(hud);

    // Poll briefly so late-mounted HUD / minimap get picked up
    const timers = [50, 150, 300, 600, 1000].map((ms) => window.setTimeout(schedule, ms));
    // Keep tracking while open (layout shifts from messages / autopilot status)
    const interval = window.setInterval(schedule, 500);

    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", schedule);
      window.removeEventListener("scroll", schedule, true);
      ro?.disconnect();
      timers.forEach(clearTimeout);
      clearInterval(interval);
    };
  }, [open, step, remeasure]);

  if (!open) return null;

  const progress = ((step + 1) / STEPS.length) * 100;
  const isLast = step >= STEPS.length - 1;

  const finish = () => {
    markTutorialComplete();
    onComplete();
    onClose();
  };

  const next = () => {
    if (isLast) finish();
    else setStep((s) => Math.min(STEPS.length - 1, s + 1));
  };

  const back = () => setStep((s) => Math.max(0, s - 1));

  const spotStyle: CSSProperties | undefined = spot
    ? {
        position: "absolute",
        left: spot.x,
        top: spot.y,
        width: spot.w,
        height: spot.h,
        borderRadius: 16,
        boxShadow: "0 0 0 9999px rgba(6, 12, 24, 0.64)",
        transition:
          "left 0.28s ease, top 0.28s ease, width 0.28s ease, height 0.28s ease",
      }
    : undefined;

  // Punch hole: dim full screen, clear ring over target; pass clicks through hole
  return (
    <div ref={rootRef} className="pointer-events-none absolute inset-0 z-40">
      {/* Full dim when no spotlight */}
      {!spot ? (
        <div className="pointer-events-auto absolute inset-0 bg-bg/55 backdrop-blur-[2px]" />
      ) : (
        <>
          {/* Spotlight ring + hole-shadow dim — clicks outside blocked via separate layer */}
          <div
            className="pointer-events-none absolute z-[1] ring-2 ring-accent/85"
            style={spotStyle}
            data-live={spot.live ? "1" : "0"}
          />
          {/* Soft pulse edge */}
          <div
            className="pointer-events-none absolute z-[1] animate-pulse rounded-2xl ring-1 ring-accent/40"
            style={{
              left: spot.x - 4,
              top: spot.y - 4,
              width: spot.w + 8,
              height: spot.h + 8,
              transition:
                "left 0.28s ease, top 0.28s ease, width 0.28s ease, height 0.28s ease",
            }}
          />
          {/* Block pointer outside spotlight: four panels */}
          <div
            className="pointer-events-auto absolute inset-x-0 top-0 bg-bg/50 backdrop-blur-[1px]"
            style={{ height: Math.max(0, spot.y) }}
          />
          <div
            className="pointer-events-auto absolute inset-x-0 bottom-0 bg-bg/50 backdrop-blur-[1px]"
            style={{ height: Math.max(0, window.innerHeight - (spot.y + spot.h)) }}
          />
          <div
            className="pointer-events-auto absolute bg-bg/50 backdrop-blur-[1px]"
            style={{
              top: spot.y,
              left: 0,
              width: Math.max(0, spot.x),
              height: spot.h,
            }}
          />
          <div
            className="pointer-events-auto absolute bg-bg/50 backdrop-blur-[1px]"
            style={{
              top: spot.y,
              left: spot.x + spot.w,
              right: 0,
              height: spot.h,
            }}
          />
        </>
      )}

      {/* Card */}
      <div
        className={`pointer-events-none absolute inset-0 z-[2] flex ${cardLayoutClass(place)}`}
      >
        <div className="pointer-events-auto modal-enter w-full max-w-md rounded-2xl border border-border bg-surface/95 p-4 shadow-2xl backdrop-blur-md sm:p-5">
          <div className="mb-3 flex items-start justify-between gap-3">
            <div className="flex items-center gap-2">
              <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-accent/15 text-accent">
                <GraduationCap size={18} />
              </div>
              <div>
                <div className="flex items-center gap-2 font-mono text-[10px] uppercase tracking-wider text-muted">
                  <span>
                    Tutorial · {step + 1}/{STEPS.length}
                  </span>
                  {spot?.live ? (
                    <span className="rounded bg-accent/15 px-1.5 py-0.5 text-accent">
                      live
                    </span>
                  ) : current.anchor !== "center" ? (
                    <span className="rounded bg-fg/10 px-1.5 py-0.5">approx</span>
                  ) : null}
                </div>
                <h2 className="text-base font-semibold tracking-tight text-fg sm:text-lg">
                  {current.title}
                </h2>
              </div>
            </div>
            <button
              type="button"
              onClick={finish}
              className="rounded-lg p-1.5 text-muted transition hover:bg-fg/10 hover:text-fg"
              aria-label="Close tutorial"
            >
              <X size={18} />
            </button>
          </div>

          <div className="mb-3 h-1 overflow-hidden rounded-full bg-fg/10">
            <div
              className="h-full rounded-full bg-accent transition-all duration-300"
              style={{ width: `${progress}%` }}
            />
          </div>

          <p className="text-sm leading-relaxed text-fg/90">{current.body}</p>
          {current.tip ? (
            <p className="mt-2 rounded-lg border border-border/80 bg-bg/40 px-3 py-2 text-xs leading-relaxed text-muted">
              <span className="font-semibold text-accent">Tip · </span>
              {current.tip}
            </p>
          ) : null}
          {current.action ? (
            <p className="mt-2 font-mono text-[11px] uppercase tracking-wide text-sonar">
              {current.action}
            </p>
          ) : null}

          <div className="mt-4 flex items-center gap-2">
            <button
              type="button"
              onClick={back}
              disabled={step === 0}
              className="inline-flex min-h-10 items-center gap-1 rounded-xl bg-fg/5 px-3 text-sm font-medium text-fg transition hover:bg-fg/10 disabled:opacity-30"
            >
              <ChevronLeft size={16} /> Back
            </button>
            <button
              type="button"
              onClick={finish}
              className="min-h-10 rounded-xl px-3 text-sm text-muted transition hover:text-fg"
            >
              Skip
            </button>
            <div className="flex-1" />
            <button
              type="button"
              onClick={next}
              className="inline-flex min-h-10 items-center gap-1 rounded-xl bg-fg px-4 text-sm font-semibold text-bg transition hover:brightness-110"
            >
              {isLast ? "Finish" : "Next"}
              {!isLast ? <ChevronRight size={16} /> : null}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export { STEPS as TUTORIAL_STEPS };
