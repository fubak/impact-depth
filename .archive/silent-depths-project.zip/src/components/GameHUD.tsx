import {
  CircleHelp,
  Crosshair,
  Gauge,
  Pause,
  Radio,
  Target,
  Volume2,
  VolumeX,
  Waves,
  Wrench,
} from "lucide-react";
import type { GameState, TerrainCell } from "@/game/types";
import { Minimap, type MinimapSnapshot } from "./Minimap";

export type ContactHud = {
  label: string;
  bearing: number;
  range: number;
  strength: number;
  source: "passive" | "active";
};

export interface HudSnapshot {
  phase: GameState["phase"];
  hp: number;
  maxHp: number;
  torpedoes: number;
  maxTorpedoes: number;
  seekers: number;
  maxSeekers: number;
  decoys: number;
  maxDecoys: number;
  cmCharges: number;
  maxCmCharges: number;
  cmCooldown: number;
  cmActive: boolean;
  depth: number;
  targetDepth: number;
  speed: number;
  targetSpeed: number;
  speedOrder: number;
  noise: number;
  score: number;
  shipsSunk: number;
  wave: number;
  victoryTarget: number;
  weapon: GameState["weapon"];
  message: string;
  messageLife: number;
  reload: number;
  reloadMk14: number;
  reloadMk18: number;
  reloadMk14Max: number;
  reloadMk18Max: number;
  timeSurvived: number;
  gameOverReason: string;
  selectedName: string;
  muted: boolean;
  debugFacing: boolean;
  hullTier: number;
  weaponTier: number;
  speedTier: number;
  docked: boolean;
  maxSpeed: number;
  baseName: string;
  sonarContacts: number;
  sonarCooldown: number;
  sonarPing: number;
  contacts: ContactHud[];
  battery: number;
  maxBattery: number;
  silentRunning: boolean;
  scopeUp: boolean;
  snorkel: boolean;
  sysSonar: number;
  sysPropulsion: number;
  sysTubes: number;
  sysFlood: number;
  crewStress: number;
  timeOfDay: number;
  dayPhase: "night" | "dawn" | "day" | "dusk";
  missionType: string;
  torpedoSpread: boolean;
  layerHint: string;
  autopilotOn: boolean;
  autopilotTactic: string;
  autopilotStatus: string;
}

function Bar({
  value,
  max,
  color,
  danger,
}: {
  value: number;
  max: number;
  color: string;
  danger?: boolean;
}) {
  const pct = Math.max(0, Math.min(1, value / max));
  return (
    <div className="h-1.5 w-full overflow-hidden rounded-full bg-fg/10">
      <div
        className={`h-full rounded-full transition-[width] duration-200 ease-out ${danger && pct < 0.35 ? "danger-glow" : ""}`}
        style={{ width: `${pct * 100}%`, background: color }}
      />
    </div>
  );
}

function depthLabel(d: number) {
  if (d < 0.12) return "SURFACE";
  if (d < 0.4) return "PERISCOPE";
  if (d < 0.7) return "ATTACK";
  return "DEEP";
}

function fmtTime(s: number) {
  const m = Math.floor(s / 60);
  const sec = Math.floor(s % 60);
  return `${m}:${sec.toString().padStart(2, "0")}`;
}

function bearingLabel(rad: number) {
  let deg = Math.round(((rad * 180) / Math.PI + 360) % 360);
  return `${deg.toString().padStart(3, "0")}°`;
}

function TierPips({ n, label }: { n: number; label: string }) {
  return (
    <div className="flex items-center gap-1.5">
      <span className="w-10 text-[10px] uppercase tracking-wider text-muted">{label}</span>
      <div className="flex gap-0.5">
        {[0, 1, 2].map((i) => (
          <span
            key={i}
            className={`h-1.5 w-3 rounded-sm ${i < n ? "bg-accent" : "bg-fg/10"}`}
          />
        ))}
      </div>
    </div>
  );
}

/** Magazine chip with exact counts + optional reload timer ring. */
function MagChip({
  label,
  cur,
  max,
  active,
  reload = 0,
  reloadMax = 1,
  onClick,
}: {
  label: string;
  cur: number;
  max: number;
  active?: boolean;
  reload?: number;
  reloadMax?: number;
  onClick?: () => void;
}) {
  const empty = cur <= 0;
  const reloading = reload > 0.02;
  const progress = reloading ? 1 - Math.min(1, reload / Math.max(0.01, reloadMax)) : 1;
  const cls = `relative flex min-h-11 min-w-[5.25rem] flex-col items-center justify-center overflow-hidden rounded-lg px-2.5 py-1 transition ${
    active
      ? "bg-accent text-bg ring-1 ring-accent/40"
      : empty
        ? "bg-fg/5 text-muted"
        : "bg-fg/5 text-fg hover:bg-fg/10"
  }`;
  const body = (
    <>
      {reloading ? (
        <span
          className="pointer-events-none absolute inset-x-0 bottom-0 h-0.5 bg-sonar/80"
          style={{ width: `${progress * 100}%` }}
        />
      ) : null}
      <span className="text-[10px] font-medium uppercase tracking-wider opacity-80">
        {label}
      </span>
      <span className="font-mono text-base font-bold tabular-nums leading-none tracking-tight">
        {cur}
        <span className="text-[11px] font-semibold opacity-65">/{max}</span>
      </span>
      {reloading ? (
        <span className="font-mono text-[9px] tabular-nums opacity-80">
          {Math.max(1, Math.ceil(reload))}s
        </span>
      ) : (
        <span className="text-[9px] opacity-50">ready</span>
      )}
    </>
  );
  if (onClick) {
    return (
      <button type="button" onClick={onClick} className={cls} title={`${label}: ${cur} of ${max}`}>
        {body}
      </button>
    );
  }
  return <div className={cls}>{body}</div>;
}

export function GameHUD({
  ui,
  minimap,
  terrain,
  onDepth,
  onSpeed,
  onWeapon,
  onFire,
  onSonar,
  onCountermeasure,
  onMute,
  onPause,
  onDebug,
  onSilent,
  onScope,
  onSnorkel,
  onSpread,
  onAutopilot,
  onClearEngagement,
  onHelp,
  onMinimapPlot,
}: {
  ui: HudSnapshot;
  minimap: MinimapSnapshot | null;
  terrain: TerrainCell[][] | null;
  onDepth: (d: number) => void;
  onSpeed: (s: number) => void;
  onWeapon: (w: GameState["weapon"]) => void;
  onFire: () => void;
  onSonar: () => void;
  onCountermeasure: () => void;
  onMute: () => void;
  onPause: () => void;
  onDebug: () => void;
  onSilent: () => void;
  onScope: () => void;
  onSnorkel: () => void;
  onSpread: () => void;
  onAutopilot: (tactic: string) => void;
  onClearEngagement: () => void;
  onHelp: () => void;
  onMinimapPlot: (wx: number, wy: number) => void;
}) {
  const cmReady = ui.cmCharges > 0 && ui.cmCooldown <= 0;
  const flank = Math.max(2.4, ui.maxSpeed);
  const maxDecoys = ui.maxDecoys || 3;
  const contacts = ui.contacts ?? [];

  return (
    <div className="pointer-events-none absolute inset-0 z-10 overflow-hidden">
      {/* TOP */}
      <div className="pointer-events-none absolute inset-x-0 top-0 z-20 flex items-start justify-between gap-2 p-2 sm:p-3">
        <div
          data-tutorial="status"
          className="pointer-events-auto min-w-0 max-w-[min(100%,18rem)] shrink rounded-xl border border-border bg-surface/90 px-2.5 py-2 shadow-lg backdrop-blur-md sm:max-w-[22rem] sm:px-3"
        >
          <div className="flex flex-wrap items-center gap-x-2 gap-y-1">
            <h1 className="text-xs font-semibold tracking-tight text-fg sm:text-sm">
              USS Nautilus
            </h1>
            <span className="font-mono text-[10px] uppercase tracking-wider text-muted">
              W{ui.wave}
            </span>
            {ui.docked ? (
              <span className="inline-flex items-center gap-1 rounded-full border border-success/40 bg-success/15 px-1.5 py-0.5 font-mono text-[9px] uppercase tracking-wider text-success">
                <Wrench size={9} /> Safe · FOB
              </span>
            ) : null}
            {ui.cmActive ? (
              <span className="rounded-full border border-sonar/40 bg-sonar/15 px-1.5 py-0.5 font-mono text-[9px] uppercase tracking-wider text-sonar">
                Screen
              </span>
            ) : null}
          </div>
          <div className="mt-1.5 grid grid-cols-3 gap-2 text-[10px] text-muted sm:text-[11px]">
            <div>
              <div className="mb-0.5 flex justify-between gap-1">
                <span>Hull</span>
                <span className="font-mono tabular-nums text-fg">
                  {Math.round(ui.hp)}/{Math.round(ui.maxHp)}
                </span>
              </div>
              <Bar value={ui.hp} max={ui.maxHp} color="var(--color-danger)" danger />
            </div>
            <div>
              <div className="mb-0.5 flex justify-between gap-1">
                <span>Battery</span>
                <span className="font-mono tabular-nums text-fg">
                  {Math.round(ui.battery ?? 100)}%
                </span>
              </div>
              <Bar
                value={ui.battery ?? 100}
                max={ui.maxBattery || 100}
                color="var(--color-accent)"
                danger
              />
            </div>
            <div>
              <div className="mb-0.5 flex justify-between gap-1">
                <span>Noise</span>
                <span className="font-mono tabular-nums text-fg">
                  {Math.round(ui.noise * 100)}%
                </span>
              </div>
              <Bar value={ui.noise} max={1} color="var(--color-warn)" />
            </div>
          </div>
          <div className="mt-1.5 grid grid-cols-2 gap-2 text-[10px] text-muted">
            <div>
              <div className="mb-0.5 flex justify-between">
                <span>Depth</span>
                <span className="font-mono text-fg">{depthLabel(ui.depth)}</span>
              </div>
              <Bar value={ui.depth} max={1} color="var(--color-sonar)" />
            </div>
            <div className="flex flex-wrap items-center gap-1 pt-0.5">
              <span className="rounded bg-fg/5 px-1.5 py-0.5 font-mono text-[9px] uppercase text-muted">
                {ui.dayPhase ?? "day"}
              </span>
              <span className="rounded bg-fg/5 px-1.5 py-0.5 font-mono text-[9px] uppercase text-sonar">
                Layer {ui.layerHint ?? "—"}
              </span>
              {ui.sysFlood > 0.05 ? (
                <span className="rounded bg-danger/20 px-1.5 py-0.5 font-mono text-[9px] text-danger">
                  Flood {(ui.sysFlood * 100).toFixed(0)}%
                </span>
              ) : null}
            </div>
          </div>
          {(ui.hullTier > 0 || ui.weaponTier > 0 || ui.speedTier > 0) && (
            <div className="mt-1.5 flex flex-wrap gap-x-2 gap-y-0.5 border-t border-border/50 pt-1.5">
              <TierPips n={ui.hullTier} label="Hull" />
              <TierPips n={ui.weaponTier} label="Warhead" />
              <TierPips n={ui.speedTier} label="Engine" />
            </div>
          )}
        </div>

        <div className="pointer-events-auto flex shrink-0 flex-col items-end gap-1.5">
          <div className="rounded-xl border border-border bg-surface/90 px-2.5 py-1.5 text-right shadow-lg backdrop-blur-md sm:px-3">
            <div className="font-mono text-base font-semibold tabular-nums text-fg sm:text-lg">
              {ui.score.toLocaleString()}
            </div>
            <div className="text-[9px] uppercase tracking-wider text-muted sm:text-[10px]">
              {ui.shipsSunk}/{ui.victoryTarget} · {fmtTime(ui.timeSurvived)}
            </div>
          </div>
          <div className="flex gap-1">
            <button
              type="button"
              onClick={onDebug}
              className={`flex h-9 min-w-9 items-center justify-center rounded-lg border px-1.5 text-[10px] font-semibold uppercase backdrop-blur-md transition ${
                ui.debugFacing
                  ? "border-accent/50 bg-accent/20 text-accent"
                  : "border-border bg-surface/90 text-muted hover:text-fg"
              }`}
              aria-label="Toggle facing debug"
            >
              Dir
            </button>
            <button
              type="button"
              onClick={onHelp}
              className="flex h-9 w-9 items-center justify-center rounded-lg border border-border bg-surface/90 text-muted backdrop-blur-md transition hover:text-fg"
              aria-label="Open tutorial"
              title="Tutorial"
            >
              <CircleHelp size={15} />
            </button>
            <button
              type="button"
              onClick={onMute}
              className="flex h-9 w-9 items-center justify-center rounded-lg border border-border bg-surface/90 text-muted backdrop-blur-md transition hover:text-fg"
              aria-label={ui.muted ? "Unmute" : "Mute"}
            >
              {ui.muted ? <VolumeX size={15} /> : <Volume2 size={15} />}
            </button>
            <button
              type="button"
              onClick={onPause}
              className="flex h-9 w-9 items-center justify-center rounded-lg border border-border bg-surface/90 text-muted backdrop-blur-md transition hover:text-fg"
              aria-label="Pause"
            >
              <Pause size={15} />
            </button>
          </div>
        </div>
      </div>

      {/* Sonar contact strip — left edge, below status */}
      <div
        data-tutorial="contacts"
        className="pointer-events-none absolute left-2 top-[7.25rem] z-20 w-[min(11.5rem,42vw)] sm:left-3 sm:top-[7.75rem]"
      >
        <div className="rounded-xl border border-border bg-surface/90 p-2 shadow-lg backdrop-blur-md">
          <div className="mb-1 flex items-center justify-between gap-1 px-0.5">
            <span className="font-mono text-[9px] uppercase tracking-wider text-sonar">
              Hydrophone
            </span>
            <span className="font-mono text-[9px] tabular-nums text-muted">
              {contacts.length === 0 ? "clear" : `${contacts.length}`}
            </span>
          </div>
          {contacts.length === 0 ? (
            <div className="px-0.5 text-[10px] text-muted">No contacts</div>
          ) : (
            <ul className="max-h-28 space-y-1 overflow-y-auto sm:max-h-36">
              {contacts.slice(0, 6).map((c, i) => (
                <li
                  key={`${c.label}-${i}-${c.bearing.toFixed(2)}`}
                  className="flex items-center gap-1.5 rounded-md bg-fg/5 px-1.5 py-1"
                >
                  <span
                    className={`h-1.5 w-1.5 shrink-0 rounded-full ${
                      c.source === "active" ? "bg-sonar" : "bg-accent"
                    }`}
                    style={{ opacity: 0.45 + c.strength * 0.55 }}
                  />
                  <div className="min-w-0 flex-1">
                    <div className="truncate font-mono text-[10px] font-semibold text-fg">
                      {c.label}
                    </div>
                    <div className="font-mono text-[9px] tabular-nums text-muted">
                      {bearingLabel(c.bearing)} · {c.range.toFixed(0)}u
                      {c.source === "active" ? " · ASDIC" : ""}
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>

      {/* Center messages */}
      <div className="pointer-events-none absolute left-1/2 top-[7.5rem] z-10 w-[min(92%,20rem)] -translate-x-1/2 space-y-1.5 px-2 sm:top-[6.75rem]">
        {ui.selectedName ? (
          <button
            type="button"
            onClick={onClearEngagement}
            className="pointer-events-auto mx-auto flex w-fit items-center gap-1.5 rounded-full border border-accent/30 bg-surface/90 px-3 py-1 text-xs text-accent backdrop-blur-md transition hover:border-danger/50 hover:text-danger"
            title="Clear target and stop AI"
          >
            <Target size={12} />
            <span className="font-medium">{ui.selectedName}</span>
            <span className="font-mono text-[9px] uppercase text-muted">× clear</span>
          </button>
        ) : null}
        {ui.autopilotOn ? (
          <button
            type="button"
            onClick={() => onAutopilot("manual")}
            className="pointer-events-auto mx-auto flex w-fit items-center gap-1.5 rounded-full border border-danger/40 bg-danger/15 px-3 py-1 text-xs font-semibold text-danger backdrop-blur-md"
          >
            AI {ui.autopilotTactic} · tap to STOP
          </button>
        ) : null}
        {ui.messageLife > 0 && ui.message ? (
          <div className="rounded-lg border border-border bg-surface-elevated/92 px-3 py-1.5 text-center text-xs text-fg shadow-lg backdrop-blur-md sm:text-sm">
            {ui.message}
          </div>
        ) : null}
      </div>

      {/* BOTTOM: magazine + helm LEFT, minimap RIGHT — never overlap */}
      <div className="pointer-events-auto absolute inset-x-0 bottom-0 z-20 p-2 sm:p-3">
        <div className="mx-auto flex max-w-6xl items-end gap-2 sm:gap-3">
          {/* Controls column */}
          <div className="min-w-0 flex-1 space-y-2">
            <div
              data-tutorial="magazine"
              className="rounded-xl border border-border bg-surface/90 p-2 shadow-lg backdrop-blur-md"
            >
              <div className="mb-1.5 flex flex-wrap items-center justify-between gap-2 px-0.5">
                <span className="flex items-center gap-1.5 text-[10px] uppercase tracking-wider text-muted">
                  <Crosshair size={12} /> Magazine
                </span>
                <span className="font-mono text-[10px] tabular-nums text-muted">
                  Mk-14 {ui.torpedoes}/{ui.maxTorpedoes}
                  {" · "}
                  Mk-18 {ui.seekers}/{ui.maxSeekers}
                  {ui.weaponTier > 0 ? ` · W${ui.weaponTier}` : ""}
                </span>
              </div>
              <div className="flex flex-wrap items-stretch gap-1.5">
                <MagChip
                  label="Mk-14"
                  cur={ui.torpedoes}
                  max={ui.maxTorpedoes}
                  active={ui.weapon === "torpedo"}
                  reload={ui.reloadMk14}
                  reloadMax={ui.reloadMk14Max}
                  onClick={() => onWeapon("torpedo")}
                />
                <MagChip
                  label="Mk-18"
                  cur={ui.seekers}
                  max={ui.maxSeekers}
                  active={ui.weapon === "seeker"}
                  reload={ui.reloadMk18}
                  reloadMax={ui.reloadMk18Max}
                  onClick={() => onWeapon("seeker")}
                />
                <MagChip
                  label="Foxer"
                  cur={ui.decoys}
                  max={maxDecoys}
                  active={ui.weapon === "decoy"}
                  onClick={() => onWeapon("decoy")}
                />
                <MagChip
                  label="Screen"
                  cur={ui.cmCharges}
                  max={ui.maxCmCharges}
                  reload={ui.cmCooldown}
                  reloadMax={6}
                  onClick={onCountermeasure}
                />
                <button
                  type="button"
                  onClick={onSpread}
                  className={`flex min-h-11 items-center rounded-lg px-2.5 text-[10px] font-semibold uppercase tracking-wider transition ${
                    ui.torpedoSpread
                      ? "bg-accent/25 text-accent ring-1 ring-accent/40"
                      : "bg-fg/5 text-muted hover:text-fg"
                  }`}
                  title="Mk-14 spread of 2–3 fish"
                >
                  {ui.torpedoSpread ? "Spread" : "Single"}
                </button>
                <button
                  type="button"
                  onClick={onSonar}
                  className={`flex min-h-11 items-center gap-1.5 rounded-lg px-3 text-xs font-medium transition ${
                    ui.sonarPing > 0
                      ? "bg-sonar/25 text-sonar ring-1 ring-sonar/40"
                      : ui.sonarCooldown > 0
                        ? "bg-fg/5 text-muted"
                        : "bg-sonar/15 text-sonar hover:bg-sonar/25"
                  }`}
                  title="Active ASDIC ping"
                >
                  <Radio size={14} />
                  {ui.sonarPing > 0
                    ? "Pinging"
                    : ui.sonarCooldown > 0
                      ? `${Math.max(1, Math.ceil(ui.sonarCooldown))}s`
                      : "Sonar"}
                </button>
                <button
                  type="button"
                  onClick={onFire}
                  disabled={
                    (ui.weapon === "torpedo" && (ui.torpedoes <= 0 || ui.reloadMk14 > 0)) ||
                    (ui.weapon === "seeker" && (ui.seekers <= 0 || ui.reloadMk18 > 0))
                  }
                  className="min-h-11 min-w-[4.75rem] rounded-lg bg-danger px-4 text-sm font-semibold text-fg transition hover:brightness-110 enabled:active:scale-[0.98] disabled:opacity-40"
                >
                  Fire
                </button>
              </div>
              {ui.cmCooldown > 0 ? (
                <div className="mt-1 px-0.5 font-mono text-[9px] text-muted">
                  Bubble screen recycle {Math.max(1, Math.ceil(ui.cmCooldown))}s
                </div>
              ) : null}
            </div>

            <div className="flex flex-wrap gap-2">
              <div
                data-tutorial="tactics"
                className="rounded-xl border border-border bg-surface/90 p-1.5 shadow-lg backdrop-blur-md sm:p-2"
              >
                <div className="mb-1 flex items-center justify-between gap-2 px-1 text-[10px] uppercase tracking-wider text-muted">
                  <span>Tactics</span>
                  {ui.autopilotOn ? (
                    <span className="max-w-[9rem] truncate font-mono normal-case text-accent">
                      {ui.autopilotStatus}
                    </span>
                  ) : null}
                </div>
                <div className="flex flex-wrap gap-1">
                  {[
                    {
                      label: "Silent",
                      on: ui.silentRunning,
                      fn: onSilent,
                      title: "Silent running — creep, low noise",
                    },
                    {
                      label: "Scope",
                      on: ui.scopeUp,
                      fn: onScope,
                      title: "Raise periscope (peri depth)",
                    },
                    {
                      label: "Snorkel",
                      on: ui.snorkel,
                      fn: onSnorkel,
                      title: "Charge battery — noisy & visible",
                    },
                  ].map((b) => (
                    <button
                      key={b.label}
                      type="button"
                      onClick={b.fn}
                      title={b.title}
                      className={`min-h-9 rounded-lg px-2.5 text-xs font-medium transition ${
                        b.on
                          ? "bg-sonar text-bg"
                          : "bg-fg/5 text-fg hover:bg-fg/10"
                      }`}
                    >
                      {b.label}
                    </button>
                  ))}
                </div>
                <div className="mt-1.5 flex flex-wrap gap-1 border-t border-border/50 pt-1.5">
                  {(
                    [
                      ["ambush", "Ambush"],
                      ["stalk", "Stalk"],
                      ["intercept", "Intercept"],
                      ["evade", "Evade"],
                      ["exfil", "RTB"],
                    ] as const
                  ).map(([id, label]) => (
                    <button
                      key={id}
                      type="button"
                      onClick={() => onAutopilot(id)}
                      title={
                        id === "ambush"
                          ? "Silent approach → beam shot → deep evade"
                          : id === "stalk"
                            ? "Trail quietly; fire when aspect is good"
                            : id === "intercept"
                              ? "Close and attack aggressively"
                              : id === "evade"
                                ? "Break contact — silent deep"
                                : "Return to FOB under AI helm"
                      }
                      className={`min-h-9 rounded-lg px-2 text-[11px] font-medium transition ${
                        ui.autopilotOn && ui.autopilotTactic === id
                          ? "bg-accent text-bg"
                          : "bg-fg/5 text-fg hover:bg-fg/10"
                      }`}
                    >
                      {label}
                    </button>
                  ))}
                  {ui.autopilotOn ? (
                    <button
                      type="button"
                      onClick={() => onAutopilot("manual")}
                      className="min-h-9 rounded-lg bg-danger px-2.5 text-[11px] font-semibold text-fg"
                    >
                      Stop AI
                    </button>
                  ) : null}
                  {ui.selectedName || ui.autopilotOn ? (
                    <button
                      type="button"
                      onClick={onClearEngagement}
                      className="min-h-9 rounded-lg bg-fg/10 px-2 text-[11px] font-medium text-muted hover:text-fg"
                      title="Clear target, stop AI, all stop"
                    >
                      Clear
                    </button>
                  ) : null}
                </div>
                {ui.autopilotOn ? (
                  <div className="mt-1 px-0.5 font-mono text-[9px] text-accent">
                    {ui.autopilotStatus} — Stop AI or plot a course to take helm
                  </div>
                ) : ui.selectedName ? (
                  <div className="mt-1 px-0.5 font-mono text-[9px] text-muted">
                    Target: {ui.selectedName} — Ambush/Stalk or Clear
                  </div>
                ) : null}
              </div>

              <div
                data-tutorial="depth"
                className="rounded-xl border border-border bg-surface/90 p-1.5 shadow-lg backdrop-blur-md sm:p-2"
              >
                <div className="mb-1 flex items-center gap-1.5 px-1 text-[10px] uppercase tracking-wider text-muted">
                  <Waves size={12} /> Depth
                </div>
                <div className="flex gap-1">
                  {[
                    { label: "Surf", d: 0.05 },
                    { label: "Peri", d: 0.28 },
                    { label: "Atk", d: 0.5 },
                    { label: "Deep", d: 0.82 },
                  ].map((btn) => (
                    <button
                      key={btn.label}
                      type="button"
                      onClick={() => onDepth(btn.d)}
                      className={`min-h-9 min-w-11 rounded-lg px-2 text-xs font-medium transition sm:min-h-10 sm:min-w-12 ${
                        Math.abs((ui.targetDepth ?? ui.depth) - btn.d) < 0.12
                          ? "bg-accent text-bg"
                          : "bg-fg/5 text-fg hover:bg-fg/10"
                      }`}
                    >
                      {btn.label}
                    </button>
                  ))}
                </div>
              </div>

              <div className="rounded-xl border border-border bg-surface/90 p-1.5 shadow-lg backdrop-blur-md sm:p-2">
                <div className="mb-1 flex items-center gap-1.5 px-1 text-[10px] uppercase tracking-wider text-muted">
                  <Gauge size={12} /> Speed
                </div>
                <div className="flex gap-1">
                  {[
                    { label: "Stop", s: 0, order: 0 },
                    { label: "1/3", s: flank * 0.33, order: 0.33 },
                    { label: "2/3", s: flank * 0.66, order: 0.66 },
                    { label: "Flank", s: flank, order: 1 },
                  ].map((btn) => {
                    const order = ui.speedOrder ?? (flank > 0 ? ui.targetSpeed / flank : 0);
                    const selected = Math.abs(order - btn.order) < 0.12;
                    return (
                    <button
                      key={btn.label}
                      type="button"
                      onClick={() => onSpeed(btn.s)}
                      className={`min-h-9 min-w-11 rounded-lg px-2 text-xs font-medium transition sm:min-h-10 sm:min-w-12 ${
                        selected
                          ? "bg-accent text-bg"
                          : "bg-fg/5 text-fg hover:bg-fg/10"
                      }`}
                    >
                      {btn.label}
                    </button>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>

          {/* Minimap column — sibling, never under magazine */}
          <div data-tutorial="minimap" className="hidden shrink-0 sm:block">
            <Minimap snap={minimap} terrain={terrain} size={148} onPlot={onMinimapPlot} />
          </div>
        </div>

        {/* Mobile minimap: above bottom controls, right-aligned, not covering magazine */}
        <div
          data-tutorial="minimap-mobile"
          className="pointer-events-auto absolute bottom-[11.5rem] right-2 sm:hidden"
        >
          <Minimap snap={minimap} terrain={terrain} size={108} onPlot={onMinimapPlot} />
        </div>
      </div>
    </div>
  );
}
