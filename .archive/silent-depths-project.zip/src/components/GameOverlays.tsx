import { Anchor, RotateCcw, Trophy, Users } from "lucide-react";
import type { GamePhase } from "@/game/types";

export function GameOverlays({
  phase,
  score,
  shipsSunk,
  wave,
  victoryTarget,
  timeSurvived,
  gameOverReason,
  onStart,
  onStartTutorial,
  onRestart,
  onResume,
  peerCount = 0,
}: {
  phase: GamePhase;
  score: number;
  shipsSunk: number;
  wave: number;
  victoryTarget: number;
  timeSurvived: number;
  gameOverReason: string;
  onStart: () => void;
  onStartTutorial?: () => void;
  onRestart: () => void;
  onResume: () => void;
  peerCount?: number;
}) {
  if (phase === "playing") return null;

  const mins = Math.floor(timeSurvived / 60);
  const secs = Math.floor(timeSurvived % 60);

  if (phase === "menu") {
    return (
      <div className="absolute inset-0 z-30 flex items-center justify-center bg-bg/70 px-4 backdrop-blur-sm">
        <div className="modal-enter w-full max-w-lg rounded-2xl border border-border bg-surface p-6 shadow-2xl sm:p-8">
          <div className="mb-1 text-[10px] font-medium uppercase tracking-[0.2em] text-muted">
            Pacific Theater · Open station
          </div>
          <h1 className="text-3xl font-semibold tracking-tight text-fg sm:text-4xl">
            Silent Depths
          </h1>
          <p className="mt-3 max-w-md text-sm leading-relaxed text-muted">
            Co-op submarine command. Drop in anytime — sign in with X so the
            pack knows your callsign. Stay quiet for passive tracks; active sonar
            ranges contacts but broadcasts your position. Battleships and U-boats dump depth charges.
          </p>

          <ul className="mt-5 space-y-2 text-sm text-fg/90">
            <li className="flex gap-2">
              <span className="text-accent">·</span>
              Click water to plot course — land tiles are impassable
            </li>
            <li className="flex gap-2">
              <span className="text-accent">·</span>
              Right-click / Fire for Mk-14 or Seeker torpedoes
            </li>
            <li className="flex gap-2">
              <span className="text-accent">·</span>
              Dive deep: blue veil = submerged · sun glints = surface
            </li>
            <li className="flex gap-2">
              <span className="text-accent">·</span>
              Hydrophones always listen — Active Sonar pings range but reveals you
            </li>
            <li className="flex gap-2">
              <span className="text-accent">·</span>
              Battery, Silent, Scope, Snorkel — manage energy and mast risk
            </li>
            <li className="flex gap-2">
              <span className="text-accent">·</span>
              Click a ship to target, then Ambush / Stalk / Intercept — AI drives the boat
            </li>
            <li className="flex gap-2">
              <span className="text-accent">·</span>
              Destroyers throw Hedgehog; U-boats fire torpedoes; go deep under the layer
            </li>
            <li className="flex gap-2">
              <span className="text-accent">·</span>
              Battleships & large U-boats drop depth charges — 2–3 tiles off the hull
            </li>
            <li className="flex gap-2">
              <span className="text-accent">·</span>
              U-boats are huge hunter-killers with DC patterns — bubble screens spoof them
            </li>
            <li className="flex gap-2">
              <span className="text-accent">·</span>
              Dock at FOB Argus (minimap ring) to repair & restock
            </li>
            <li className="flex gap-2">
              <span className="text-accent">·</span>
              Supply crates: hull, warheads, engines, ammo, CM
            </li>
            <li className="flex gap-2">
              <span className="text-accent">·</span>
              Allies appear as blue-ringed subs — anyone can join mid-patrol
            </li>
          </ul>

          <div className="mt-4 flex items-center gap-2 rounded-lg border border-border/80 bg-bg/50 px-3 py-2 text-xs text-muted">
            <Users size={14} className="shrink-0 text-accent" />
            {peerCount === 0
              ? "No other captains on station yet — solo is fine."
              : `${peerCount} captain${peerCount === 1 ? "" : "s"} already on the wire.`}
          </div>

          <div className="mt-6 flex flex-col gap-2 sm:flex-row sm:items-center">
            <button
              type="button"
              onClick={onStart}
              className="inline-flex min-h-12 flex-1 items-center justify-center gap-2 rounded-xl bg-fg px-5 text-sm font-semibold text-bg transition hover:brightness-110 active:scale-[0.98]"
            >
              <Anchor size={18} />
              {peerCount > 0 ? "Join patrol" : "Begin Patrol"}
            </button>
            {onStartTutorial ? (
              <button
                type="button"
                onClick={onStartTutorial}
                className="inline-flex min-h-12 items-center justify-center gap-2 rounded-xl border border-border bg-fg/5 px-4 text-sm font-medium text-fg transition hover:bg-fg/10"
              >
                Guided tour
              </button>
            ) : null}
            <div className="text-center text-xs text-subtle sm:text-left">
              Sink {victoryTarget} ships to clear the sector
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (phase === "paused") {
    return (
      <div className="absolute inset-0 z-30 flex items-center justify-center bg-bg/60 px-4 backdrop-blur-sm">
        <div className="modal-enter w-full max-w-sm rounded-2xl border border-border bg-surface p-6 text-center shadow-2xl">
          <h2 className="text-xl font-semibold tracking-tight">Patrol Paused</h2>
          <p className="mt-2 text-sm text-muted">Orders held. The sea waits.</p>
          <div className="mt-6 flex flex-col gap-2">
            <button
              type="button"
              onClick={onResume}
              className="min-h-11 rounded-xl bg-fg text-sm font-semibold text-bg transition hover:brightness-110"
            >
              Resume
            </button>
            <button
              type="button"
              onClick={onRestart}
              className="min-h-11 rounded-xl border border-border text-sm font-medium text-muted transition hover:bg-bg"
            >
              Restart
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (phase === "gameover") {
    return (
      <div className="absolute inset-0 z-30 flex items-center justify-center bg-bg/70 px-4 backdrop-blur-sm">
        <div className="modal-enter w-full max-w-md rounded-2xl border border-border bg-surface p-6 text-center shadow-2xl sm:p-8">
          <h2 className="text-2xl font-semibold tracking-tight text-danger">Hull Breached</h2>
          <p className="mt-2 text-sm text-muted">{gameOverReason || "The sea took her."}</p>
          <div className="mt-5 grid grid-cols-3 gap-3 text-center">
            <div>
              <div className="text-lg font-semibold text-fg">{score}</div>
              <div className="text-[10px] uppercase tracking-wider text-muted">Score</div>
            </div>
            <div>
              <div className="text-lg font-semibold text-fg">{shipsSunk}</div>
              <div className="text-[10px] uppercase tracking-wider text-muted">Sunk</div>
            </div>
            <div>
              <div className="text-lg font-semibold text-fg">
                {mins}:{secs.toString().padStart(2, "0")}
              </div>
              <div className="text-[10px] uppercase tracking-wider text-muted">Time</div>
            </div>
          </div>
          <button
            type="button"
            onClick={onRestart}
            className="mt-6 inline-flex min-h-12 w-full items-center justify-center gap-2 rounded-xl bg-fg text-sm font-semibold text-bg transition hover:brightness-110"
          >
            <RotateCcw size={16} />
            New patrol
          </button>
        </div>
      </div>
    );
  }

  if (phase === "victory") {
    return (
      <div className="absolute inset-0 z-30 flex items-center justify-center bg-bg/70 px-4 backdrop-blur-sm">
        <div className="modal-enter w-full max-w-md rounded-2xl border border-border bg-surface p-6 text-center shadow-2xl sm:p-8">
          <Trophy className="mx-auto text-accent" size={32} />
          <h2 className="mt-3 text-2xl font-semibold tracking-tight">Sector Cleared</h2>
          <p className="mt-2 text-sm text-muted">
            Wave {wave} complete. {shipsSunk} ships sent to the deep.
          </p>
          <div className="mt-5 text-3xl font-semibold text-fg">{score}</div>
          <div className="text-[10px] uppercase tracking-wider text-muted">Final score</div>
          <button
            type="button"
            onClick={onRestart}
            className="mt-6 inline-flex min-h-12 w-full items-center justify-center gap-2 rounded-xl bg-fg text-sm font-semibold text-bg transition hover:brightness-110"
          >
            <Anchor size={16} />
            Sail again
          </button>
        </div>
      </div>
    );
  }

  return null;
}
