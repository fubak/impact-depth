import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Link } from "@tanstack/react-router";
import {
  createGame,
  deployCountermeasure,
  detachCamera,
  fireWeapon,
  orderMove,
  pickShipAtScreen,
  restartGame,
  selectTarget,
  setDepthOrder,
  setSpeedOrder,
  setWeapon,
  sonarPulse,
  startMission,
  toggleDebugFacing,
  toggleSilentRunning,
  toggleScope,
  toggleSnorkel,
  toggleTorpedoSpread,
  setAutopilot,
  clearEngagement,
  updateGame,
  applyHostSeed,
} from "@/game/engine";
import { noteFrameMs, renderGame } from "@/game/render";
import { panCameraByScreenDelta, screenToWorld } from "@/game/iso";
import type { GameState, TerrainCell } from "@/game/types";
import { unlockAudio, setMuted } from "@/game/audio";
import {
  applyHello,
  applyHostSnap,
  applyHostTick,
  applyPlayerSnap,
  hostTickFingerprint,
  hostTickInterval,
  interpolateRemotes,
  isHost,
  packDc,
  packHostTick,
  packPlayerSnap,
  packShip,
  packTorp,
  pruneRemotes,
  shouldAnswerSync,
  type HostSnap,
  type NetMsg,
  type RemotePlayer,
} from "@/game/net";
import { useP2PRoom } from "@/lib/multiplayer/use-p2p-room";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { UserButton, SignedIn, SignedOut } from "@/lib/auth/gates";
import { authEnabled } from "@/lib/auth/client";
import { GameHUD } from "./GameHUD";
import { GameOverlays } from "./GameOverlays";
import {
  TutorialOverlay,
  markTutorialComplete,
  tutorialWasCompleted,
} from "./TutorialOverlay";
import { buildMinimapSnap, type MinimapSnapshot } from "./Minimap";

type Bundle = { state: GameState; terrain: TerrainCell[][] };

export function SubmarineGame() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const wrapRef = useRef<HTMLDivElement>(null);
  const bundleRef = useRef<Bundle | null>(null);
  const remotesRef = useRef<Map<string, RemotePlayer>>(new Map());
  const hostFlagRef = useRef(true);
  const lastHostFpRef = useRef(0);
  const contactsBufRef = useRef<{ x: number; y: number; z: number; noise: number }[]>([]);
  const liveIdsRef = useRef(new Set<string>());
  const peerIdsRef = useRef<string[]>([]);
  const { user, isPending } = useCurrentUserState();

  const playerName = useMemo(() => {
    if (user?.displayName) return user.displayName.slice(0, 24);
    if (user?.primaryEmail) return user.primaryEmail.split("@")[0]!.slice(0, 24);
    return "Captain";
  }, [user]);

  const avatar = user?.profileImageUrl ?? null;

  const p2p = useP2PRoom({
    name: playerName,
    enabled: true,
  });

  const [ui, setUi] = useState({
    phase: "menu" as GameState["phase"],
    hp: 100,
    maxHp: 100,
    torpedoes: 8,
    maxTorpedoes: 8,
    seekers: 4,
    maxSeekers: 4,
    decoys: 3,
    maxDecoys: 3,
    cmCharges: 3,
    maxCmCharges: 3,
    cmCooldown: 0,
    cmActive: false,
    depth: 0.45,
    targetDepth: 0.45,
    speed: 0,
    targetSpeed: 0,
    speedOrder: 0,
    noise: 0.2,
    score: 0,
    shipsSunk: 0,
    wave: 1,
    victoryTarget: 8,
    weapon: "torpedo" as GameState["weapon"],
    message: "",
    messageLife: 0,
    reload: 0,
    reloadMk14: 0,
    reloadMk18: 0,
    reloadMk14Max: 2.5,
    reloadMk18Max: 3.4,
    timeSurvived: 0,
    gameOverReason: "",
    selectedName: "",
    muted: false,
    debugFacing: false,
    hullTier: 0,
    weaponTier: 0,
    speedTier: 0,
    docked: false,
    maxSpeed: 2.4,
    baseName: "FOB Argus",
    sonarContacts: 0,
    sonarCooldown: 0,
    sonarPing: 0,
    contacts: [] as {
      label: string;
      bearing: number;
      range: number;
      strength: number;
      source: "passive" | "active";
    }[],
    battery: 100,
    maxBattery: 100,
    silentRunning: false,
    scopeUp: false,
    snorkel: false,
    sysSonar: 1,
    sysPropulsion: 1,
    sysTubes: 1,
    sysFlood: 0,
    crewStress: 0,
    timeOfDay: 0.2,
    dayPhase: "night" as "night" | "dawn" | "day" | "dusk",
    missionType: "patrol",
    torpedoSpread: false,
    layerHint: "above",
    autopilotOn: false,
    autopilotTactic: "manual",
    autopilotStatus: "Manual helm",
  });
  const [minimapSnap, setMinimapSnap] = useState<MinimapSnapshot | null>(null);
  const [tutorialOpen, setTutorialOpen] = useState(false);

  const [netUi, setNetUi] = useState({
    peers: 0,
    joined: false,
    isHost: true,
    names: [] as string[],
  });

  const dragRef = useRef({
    panning: false,
    lastX: 0,
    lastY: 0,
    moved: false,
    pointerId: -1,
    button: 0,
  });
  const pinchRef = useRef<{ dist: number; zoom: number } | null>(null);

  if (!bundleRef.current) {
    bundleRef.current = createGame();
  }

  const syncUi = useCallback(() => {
    const b = bundleRef.current;
    if (!b) return;
    const s = b.state;
    const sel = s.ships.find((sh) => sh.id === s.selectedTarget);
    setUi({
      phase: s.phase,
      hp: s.sub.hp,
      maxHp: s.sub.maxHp,
      torpedoes: s.sub.torpedoes,
      maxTorpedoes: s.sub.maxTorpedoes,
      seekers: s.sub.seekers,
      maxSeekers: s.sub.maxSeekers,
      decoys: s.sub.decoys,
      maxDecoys: 3,
      cmCharges: s.sub.cmCharges,
      maxCmCharges: s.sub.maxCmCharges,
      cmCooldown: s.sub.cmCooldown,
      cmActive: s.countermeasures.some((c) => c.kind === "bubble" && c.life > 0),
      depth: s.sub.z,
      targetDepth: s.sub.targetDepth,
      speed: s.sub.speed,
      targetSpeed: s.sub.targetSpeed,
      speedOrder: s.sub.speedOrder ?? (s.sub.maxSpeed > 0 ? s.sub.targetSpeed / s.sub.maxSpeed : 0),
      noise: s.sub.noise,
      score: s.stats.score,
      shipsSunk: s.stats.shipsSunk,
      wave: s.stats.wave,
      victoryTarget: s.victoryTarget,
      weapon: s.weapon,
      message: s.message,
      messageLife: s.messageLife,
      reload: s.sub.reload,
      reloadMk14: s.sub.reloadMk14 ?? 0,
      reloadMk18: s.sub.reloadMk18 ?? 0,
      reloadMk14Max: s.sub.reloadMk14Max || 2.5,
      reloadMk18Max: s.sub.reloadMk18Max || 3.4,
      timeSurvived: s.stats.timeSurvived,
      gameOverReason: s.gameOverReason,
      selectedName: sel?.name ?? "",
      muted: s.muted,
      debugFacing: s.debugFacing,
      hullTier: s.sub.hullTier ?? 0,
      weaponTier: s.sub.weaponTier ?? 0,
      speedTier: s.sub.speedTier ?? 0,
      docked: (s.sub.docked ?? 0) > 0,
      maxSpeed: s.sub.maxSpeed,
      baseName: s.base?.name ?? "FOB Argus",
      sonarContacts: s.sonarContacts?.length ?? 0,
      sonarCooldown: s.sonarActiveCooldown ?? 0,
      sonarPing: s.sonarPing ?? 0,
      contacts: (s.sonarContacts ?? []).map((c) => ({
        label: c.label,
        bearing: c.bearing,
        range: c.range,
        strength: c.strength,
        source: c.source,
      })),
      battery: s.sub.battery ?? 100,
      maxBattery: s.sub.maxBattery ?? 100,
      silentRunning: !!s.sub.silentRunning,
      scopeUp: !!s.sub.scopeUp,
      snorkel: !!s.sub.snorkel,
      sysSonar: s.sub.sysSonar ?? 1,
      sysPropulsion: s.sub.sysPropulsion ?? 1,
      sysTubes: s.sub.sysTubes ?? 1,
      sysFlood: s.sub.sysFlood ?? 0,
      crewStress: s.sub.crewStress ?? 0,
      timeOfDay: s.timeOfDay ?? 0.5,
      dayPhase: (() => {
        const t = s.timeOfDay ?? 0.5;
        if (t < 0.22 || t > 0.88) return "night";
        if (t < 0.3) return "dawn";
        if (t > 0.78) return "dusk";
        return "day";
      })(),
      missionType: s.missionType ?? "patrol",
      torpedoSpread: !!s.torpedoSpread,
      layerHint: s.sub.z > 0.48 ? "below" : "above",
      autopilotOn: !!s.autopilot?.enabled,
      autopilotTactic: s.autopilot?.tactic ?? "manual",
      autopilotStatus: s.autopilot?.status ?? "Manual helm",
    });
    setMinimapSnap(buildMinimapSnap(s));
  }, []);

  useEffect(() => {
    return p2p.onMessage((from, data) => {
      const b = bundleRef.current;
      if (!b || !data || typeof data !== "object") return;
      const msg = data as NetMsg;
      const now = performance.now();

      if (msg.t === "ps" && from !== p2p.selfId) {
        applyPlayerSnap(remotesRef.current, msg, now);
      } else if (msg.t === "hi" && from !== p2p.selfId) {
        applyHello(remotesRef.current, msg, now);
      } else if (msg.t === "req") {
        const peerIds = peerIdsRef.current;
        if (shouldAnswerSync(p2p.selfId, peerIds, from) && b.state.phase !== "menu") {
          const snap: HostSnap = {
            t: "hs",
            seed: b.state.seed,
            wave: b.state.stats.wave,
            score: b.state.stats.score,
            sunk: b.state.stats.shipsSunk,
            phase: b.state.phase,
            time: b.state.time,
            ships: b.state.ships.map(packShip),
            dcs: b.state.depthCharges.map(packDc),
            torps: b.state.torpedoes.map(packTorp),
          };
          p2p.send(snap, from);
        }
      } else if (msg.t === "hs") {
        if (!hostFlagRef.current || b.state.phase === "menu") {
          applyHostSeed(b, msg.seed);
          applyHostSnap(b.state, msg);
          if (b.state.phase === "menu") {
            b.state.phase = "playing";
            b.state.message = "Joined ongoing patrol — welcome aboard.";
            b.state.messageLife = 4;
          }
        }
      } else if (msg.t === "hw") {
        if (!hostFlagRef.current) {
          applyHostTick(b.state, msg);
          if (b.state.phase === "menu") {
            b.state.phase = "playing";
            b.state.message = "Synced with sector lead.";
            b.state.messageLife = 2.5;
          }
        }
      }
    });
  }, [p2p.onMessage, p2p.selfId, p2p.send]);

  useEffect(() => {
    if (!p2p.joined) return;
    p2p.send({ t: "req" });
    p2p.send({ t: "hi", id: p2p.selfId, n: playerName, a: avatar });
  }, [p2p.joined, p2p.send, p2p.selfId, playerName, avatar]);

  const prevPeerCount = useRef(0);
  useEffect(() => {
    peerIdsRef.current = p2p.peers.map((p) => p.id);
    if (p2p.peers.length > prevPeerCount.current) {
      p2p.send({ t: "hi", id: p2p.selfId, n: playerName, a: avatar });
    }
    prevPeerCount.current = p2p.peers.length;
    hostFlagRef.current = isHost(p2p.selfId, peerIdsRef.current);
    setNetUi({
      peers: p2p.peers.length,
      joined: p2p.joined,
      isHost: hostFlagRef.current,
      names: p2p.peers.map((p) => p.name || p.id),
    });
  }, [p2p.peers, p2p.selfId, p2p.joined, p2p.send, playerName, avatar]);

  useEffect(() => {
    let raf = 0;
    let last = performance.now();
    let uiAcc = 0;
    let netAcc = 0;
    let hostAcc = 0;
    let layoutAcc = 0;
    let cachedW = 0;
    let cachedH = 0;
    let cachedDpr = 0;
    let ctx: CanvasRenderingContext2D | null = null;
    let lastPlayerFp = 0;
    let frameMsEma = 16;
    let lastDprCap = 1.25;
    let dprHold = 0;

    const frame = (now: number) => {
      const raw = (now - last) / 1000;
      const frameMs = now - last;
      last = now;
      frameMsEma = frameMsEma * 0.88 + frameMs * 0.12;
      noteFrameMs(frameMsEma);

      const dt = Math.min(raw, 0.1);
      const b = bundleRef.current;
      const canvas = canvasRef.current;
      const wrap = wrapRef.current;
      if (b && canvas && wrap) {
        const peerIds = peerIdsRef.current;
        const hasPeers = peerIds.length > 0;
        const hosting = isHost(p2p.selfId, peerIds);
        hostFlagRef.current = hosting;

        const contacts = contactsBufRef.current;
        contacts.length = 0;
        for (const r of remotesRef.current.values()) {
          contacts.push({ x: r.x, y: r.y, z: r.z, noise: r.noise });
        }

        updateGame(b.state, b.terrain, dt, {
          simulateWorld: hosting || !hasPeers,
          contacts,
        });

        interpolateRemotes(remotesRef.current, dt);
        const live = liveIdsRef.current;
        live.clear();
        for (const id of peerIds) live.add(id);
        pruneRemotes(remotesRef.current, live, now);

        netAcc += dt;
        const moving = b.state.sub.speed > 0.15 || b.state.sub.waypoint != null;
        const playerInterval = moving ? 0.12 : 0.2;
        if (netAcc >= playerInterval && p2p.joined && hasPeers) {
          netAcc = 0;
          const snap = packPlayerSnap(p2p.selfId, b.state.sub, b.state.phase, playerName);
          const fp =
            snap.x +
            snap.y * 3 +
            snap.z * 7 +
            snap.dh * 11 +
            snap.hp * 13 +
            snap.ph +
            snap.sp * 17;
          if (fp !== lastPlayerFp || moving) {
            lastPlayerFp = fp;
            p2p.broadcast(snap);
          }
        }

        hostAcc += dt;
        const hInterval = hostTickInterval(b.state);
        if (hosting && hostAcc >= hInterval && p2p.joined && hasPeers && b.state.phase === "playing") {
          hostAcc = 0;
          const tick = packHostTick(b.state);
          const fp = hostTickFingerprint(tick);
          if (fp !== lastHostFpRef.current) {
            lastHostFpRef.current = fp;
            p2p.broadcast(tick);
          }
        }

        const rawDpr = window.devicePixelRatio || 1;
        // Quantize + heavy hysteresis so canvas never thrash-resizes (main published flicker)
        let dprCap = viewAreaDprCap(cachedW, cachedH, frameMsEma);
        dprCap = quantizeDpr(dprCap);
        if (dprHold > 0) {
          dprHold--;
          dprCap = lastDprCap;
        } else if (Math.abs(dprCap - lastDprCap) >= 0.12) {
          // Only step when meaningful
          lastDprCap = dprCap;
          dprHold = 240; // ~4s at 60fps
        } else {
          dprCap = lastDprCap;
        }
        const dpr = quantizeDpr(Math.min(rawDpr, dprCap));
        layoutAcc += dt;
        if (cachedW === 0 || layoutAcc > 0.75) {
          layoutAcc = 0;
          const rect = wrap.getBoundingClientRect();
          cachedW = Math.max(1, Math.floor(rect.width));
          cachedH = Math.max(1, Math.floor(rect.height));
        }
        const w = cachedW;
        const h = cachedH;
        const pw = Math.max(1, Math.floor(w * dpr));
        const ph = Math.max(1, Math.floor(h * dpr));
        if (canvas.width !== pw || canvas.height !== ph || Math.abs(cachedDpr - dpr) > 0.01) {
          canvas.width = pw;
          canvas.height = ph;
          canvas.style.width = `${w}px`;
          canvas.style.height = `${h}px`;
          cachedDpr = dpr;
          // desynchronized can tear on production GPUs
          ctx = canvas.getContext("2d", { alpha: false, desynchronized: false });
        }
        if (!ctx) ctx = canvas.getContext("2d", { alpha: false, desynchronized: false });
        if (ctx) {
          renderGame(ctx, b.state, b.terrain, w, h, dpr, remotesRef.current, playerName);
        }

        uiAcc += dt;
        if (uiAcc > 0.15) {
          uiAcc = 0;
          syncUi();
        }
      }
      raf = requestAnimationFrame(frame);
    };
    raf = requestAnimationFrame(frame);
    return () => cancelAnimationFrame(raf);
  }, [syncUi, p2p, playerName]);

  const clientToCanvas = (clientX: number, clientY: number) => {
    const canvas = canvasRef.current;
    if (!canvas) return null;
    const rect = canvas.getBoundingClientRect();
    return {
      sx: clientX - rect.left,
      sy: clientY - rect.top,
      w: rect.width,
      h: rect.height,
    };
  };

  const clientToWorld = (clientX: number, clientY: number) => {
    const b = bundleRef.current;
    const c = clientToCanvas(clientX, clientY);
    if (!b || !c) return null;
    return screenToWorld(
      c.sx,
      c.sy,
      b.state.camera.x,
      b.state.camera.y,
      b.state.camera.zoom,
      c.w,
      c.h,
      0,
    );
  };

  const onPointerDown = (e: React.PointerEvent) => {
    const b = bundleRef.current;
    if (!b) return;
    unlockAudio();

    dragRef.current = {
      panning: e.button === 1 || e.altKey || e.shiftKey,
      lastX: e.clientX,
      lastY: e.clientY,
      moved: false,
      pointerId: e.pointerId,
      button: e.button,
    };
    (e.target as HTMLElement).setPointerCapture?.(e.pointerId);
  };

  const onPointerMove = (e: React.PointerEvent) => {
    const b = bundleRef.current;
    if (!b) return;
    const world = clientToWorld(e.clientX, e.clientY);
    if (world) b.state.hoverWorld = world;

    const d = dragRef.current;
    if (d.pointerId !== e.pointerId) return;

    const dx = e.clientX - d.lastX;
    const dy = e.clientY - d.lastY;
    if (Math.hypot(dx, dy) > 4) d.moved = true;

    const panning =
      d.panning ||
      (d.button === 0 && d.moved && e.buttons === 1) ||
      (d.button === 2 && d.moved && e.buttons === 2);

    if (panning && (e.buttons & 7) !== 0) {
      d.panning = true;
      detachCamera(b.state);
      panCameraByScreenDelta(b.state.camera, dx, dy, b.state.camera.zoom);
    }
    d.lastX = e.clientX;
    d.lastY = e.clientY;
  };

  const onPointerUp = (e: React.PointerEvent) => {
    const b = bundleRef.current;
    if (!b) return;
    const d = dragRef.current;
    if (d.pointerId !== e.pointerId) return;

    if (b.state.phase === "menu") {
      startMission(b.state);
      syncUi();
      return;
    }
    if (b.state.phase !== "playing") return;

    const canvas = clientToCanvas(e.clientX, e.clientY);
    const world = clientToWorld(e.clientX, e.clientY);
    if (!canvas || !world) return;

    if (!d.moved) {
      if (d.button === 0) {
        const ship = pickShipAtScreen(
          b.state,
          canvas.sx,
          canvas.sy,
          canvas.w,
          canvas.h,
          32,
        );
        if (ship) {
          selectTarget(b.state, ship.id);
        } else {
          selectTarget(b.state, null);
          orderMove(b.state, world.x, world.y, b.terrain);
        }
      } else if (d.button === 2) {
        const ship = pickShipAtScreen(
          b.state,
          canvas.sx,
          canvas.sy,
          canvas.w,
          canvas.h,
          40,
        );
        if (ship) {
          selectTarget(b.state, ship.id);
          fireWeapon(b.state, ship.x, ship.y);
        } else {
          fireWeapon(b.state, world.x, world.y);
        }
      }
    }
    d.pointerId = -1;
    syncUi();
  };

  const onContextMenu = (e: React.MouseEvent) => {
    e.preventDefault();
  };

  useEffect(() => {
    const el = canvasRef.current;
    if (!el) return;

    const onWheel = (e: WheelEvent) => {
      e.preventDefault();
      const b = bundleRef.current;
      if (!b) return;
      const factor = e.deltaY > 0 ? 0.92 : 1.08;
      b.state.camera.zoom = Math.min(2.2, Math.max(0.45, b.state.camera.zoom * factor));
    };

    const onTouchMove = (e: TouchEvent) => {
      if (e.touches.length === 2) {
        e.preventDefault();
        const b = bundleRef.current;
        if (!b) return;
        const t0 = e.touches[0]!;
        const t1 = e.touches[1]!;
        const dist = Math.hypot(t0.clientX - t1.clientX, t0.clientY - t1.clientY);
        if (!pinchRef.current) {
          pinchRef.current = { dist, zoom: b.state.camera.zoom };
        } else {
          const scale = dist / pinchRef.current.dist;
          b.state.camera.zoom = Math.min(
            2.2,
            Math.max(0.45, pinchRef.current.zoom * scale),
          );
        }
      }
    };
    const onTouchEnd = () => {
      pinchRef.current = null;
    };

    el.addEventListener("wheel", onWheel, { passive: false });
    el.addEventListener("touchmove", onTouchMove, { passive: false });
    el.addEventListener("touchend", onTouchEnd);
    return () => {
      el.removeEventListener("wheel", onWheel);
      el.removeEventListener("touchmove", onTouchMove);
      el.removeEventListener("touchend", onTouchEnd);
    };
  }, []);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const b = bundleRef.current;
      if (!b) return;
      if (e.code === "KeyC" && !e.repeat) {
        if (b.state.phase !== "playing") return;
        deployCountermeasure(b.state);
        syncUi();
      }
      if (e.code === "KeyD" && !e.repeat) {
        toggleDebugFacing(b.state);
        syncUi();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [syncUi]);

  const onDoubleClick = (e: React.MouseEvent) => {
    const b = bundleRef.current;
    if (!b || b.state.phase !== "playing") return;
    const canvas = clientToCanvas(e.clientX, e.clientY);
    const world = clientToWorld(e.clientX, e.clientY);
    if (!canvas || !world) return;
    const ship = pickShipAtScreen(b.state, canvas.sx, canvas.sy, canvas.w, canvas.h, 40);
    if (ship) {
      selectTarget(b.state, ship.id);
      fireWeapon(b.state, ship.x, ship.y);
    } else {
      fireWeapon(b.state, world.x, world.y);
    }
    syncUi();
  };

  const handleDepth = (d: number) => {
    const b = bundleRef.current;
    if (!b) return;
    setDepthOrder(b.state, d);
    syncUi();
  };

  const handleSpeed = (s: number) => {
    const b = bundleRef.current;
    if (!b) return;
    setSpeedOrder(b.state, s);
    syncUi();
  };

  const handleWeapon = (w: GameState["weapon"]) => {
    const b = bundleRef.current;
    if (!b) return;
    setWeapon(b.state, w);
    syncUi();
  };

  const handleFire = () => {
    const b = bundleRef.current;
    if (!b || b.state.phase !== "playing") return;
    const sel = b.state.ships.find((s) => s.id === b.state.selectedTarget);
    if (sel) fireWeapon(b.state, sel.x, sel.y);
    else {
      const a = b.state.sub.heading;
      fireWeapon(
        b.state,
        b.state.sub.x + Math.cos(a) * 12,
        b.state.sub.y + Math.sin(a) * 12,
      );
    }
    syncUi();
  };

  const handleSonar = () => {
    const b = bundleRef.current;
    if (!b) return;
    sonarPulse(b.state);
    syncUi();
  };

  const handleCountermeasure = () => {
    const b = bundleRef.current;
    if (!b) return;
    deployCountermeasure(b.state);
    syncUi();
  };

  const handleDebug = () => {
    const b = bundleRef.current;
    if (!b) return;
    toggleDebugFacing(b.state);
    syncUi();
  };

  const handleSilent = () => {
    const b = bundleRef.current;
    if (!b) return;
    toggleSilentRunning(b.state);
    syncUi();
  };
  const handleScope = () => {
    const b = bundleRef.current;
    if (!b) return;
    toggleScope(b.state);
    syncUi();
  };
  const handleSnorkel = () => {
    const b = bundleRef.current;
    if (!b) return;
    toggleSnorkel(b.state);
    syncUi();
  };
  const handleSpread = () => {
    const b = bundleRef.current;
    if (!b) return;
    toggleTorpedoSpread(b.state);
    syncUi();
  };

  const handleAutopilot = (tactic: string) => {
    const b = bundleRef.current;
    if (!b) return;
    setAutopilot(b.state, tactic as any, b.state.selectedTarget);
    syncUi();
  };

  const handleClearEngagement = () => {
    const b = bundleRef.current;
    if (!b) return;
    clearEngagement(b.state);
    syncUi();
  };

  const handleStart = () => {
    const b = bundleRef.current;
    if (!b) return;
    startMission(b.state);
    syncUi();
    if (!tutorialWasCompleted()) {
      // slight delay so HUD mounts under the guide
      setTimeout(() => setTutorialOpen(true), 400);
    }
  };

  const handleStartTutorial = () => {
    const b = bundleRef.current;
    if (!b) return;
    if (b.state.phase === "menu") {
      startMission(b.state);
      syncUi();
    }
    setTutorialOpen(true);
  };

  const handleRestart = () => {
    const b = bundleRef.current;
    if (!b) return;
    restartGame(b);
    syncUi();
  };

  const handleMute = () => {
    const b = bundleRef.current;
    if (!b) return;
    b.state.muted = !b.state.muted;
    setMuted(b.state.muted);
    syncUi();
  };

  const handlePause = () => {
    const b = bundleRef.current;
    if (!b) return;
    if (b.state.phase === "playing") b.state.phase = "paused";
    else if (b.state.phase === "paused") b.state.phase = "playing";
    syncUi();
  };

  return (
    <div
      ref={wrapRef}
      className="relative h-dvh w-full overflow-hidden bg-bg text-fg"
      style={{ touchAction: "none" }}
    >
      <canvas
        ref={canvasRef}
        className="absolute inset-0 h-full w-full"
        onPointerDown={onPointerDown}
        onPointerMove={onPointerMove}
        onPointerUp={onPointerUp}
        onPointerCancel={onPointerUp}
        onContextMenu={onContextMenu}
        onDoubleClick={onDoubleClick}
      />

      {ui.phase === "playing" || ui.phase === "paused" ? (
        <GameHUD
          ui={ui}
          minimap={minimapSnap}
          terrain={bundleRef.current?.terrain ?? null}
          onDepth={handleDepth}
          onSpeed={handleSpeed}
          onWeapon={handleWeapon}
          onFire={handleFire}
          onSonar={handleSonar}
          onCountermeasure={handleCountermeasure}
          onMute={handleMute}
          onPause={handlePause}
          onDebug={handleDebug}
          onSilent={handleSilent}
          onScope={handleScope}
          onSnorkel={handleSnorkel}
          onSpread={handleSpread}
          onAutopilot={handleAutopilot}
          onClearEngagement={handleClearEngagement}
          onHelp={() => setTutorialOpen(true)}
          onMinimapPlot={(wx, wy) => {
            const b = bundleRef.current;
            if (!b || b.state.phase !== "playing") return;
            orderMove(b.state, wx, wy, b.terrain);
            syncUi();
          }}
        />
      ) : null}

      <GameOverlays
        phase={ui.phase}
        score={ui.score}
        shipsSunk={ui.shipsSunk}
        wave={ui.wave}
        victoryTarget={ui.victoryTarget}
        timeSurvived={ui.timeSurvived}
        gameOverReason={ui.gameOverReason}
        onStart={handleStart}
        onStartTutorial={handleStartTutorial}
        onRestart={handleRestart}
        onResume={handlePause}
        peerCount={netUi.peers}
      />

      {(ui.phase === "playing" || ui.phase === "paused") && (
        <TutorialOverlay
          open={tutorialOpen}
          onClose={() => setTutorialOpen(false)}
          onComplete={() => {
            markTutorialComplete();
            setTutorialOpen(false);
          }}
        />
      )}

      {/* Multiplayer status chip — below top status panel */}
      {netUi.joined && (
        <div className="pointer-events-none absolute left-2 top-[6.75rem] z-20 rounded-full border border-border/60 bg-surface/80 px-2.5 py-1 text-[10px] text-muted backdrop-blur-sm sm:left-3 sm:top-[7.25rem] sm:text-[11px]">
          {netUi.isHost ? "Sector lead" : "Joined patrol"}
          {netUi.peers > 0 ? ` · ${netUi.peers} ally${netUi.peers === 1 ? "" : "s"}` : " · solo"}
        </div>
      )}

      {authEnabled && (
        <div className="absolute bottom-[9.5rem] left-2 z-30 sm:bottom-auto sm:left-auto sm:right-[10.5rem] sm:top-3">
          <SignedIn>
            <UserButton />
          </SignedIn>
          <SignedOut>
            <Link
              to="/login"
              className="rounded-lg border border-border bg-surface/80 px-2 py-1 text-xs text-muted backdrop-blur-sm"
            >
              Sign in
            </Link>
          </SignedOut>
        </div>
      )}
    </div>
  );
}

function quantizeDpr(dpr: number): number {
  if (dpr <= 1.05) return 1;
  if (dpr <= 1.35) return 1.25;
  return 1.5;
}

function viewAreaDprCap(w: number, h: number, frameMs = 16): number {
  const area = Math.max(1, w * h);
  // Prefer stability over max sharpness on large / slow views
  if (frameMs > 28 || area > 2_200_000) return 1;
  if (frameMs > 22 || area > 1_400_000) return 1.25;
  return 1.5;
}
