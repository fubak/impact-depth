/**
 * Realism systems for Silent Depths:
 * battery / silent running / snorkel, systems damage,
 * day-night, aircraft patrols, hedgehog ASW, aspect bonuses.
 */
import { angleDiff, clamp, dist } from "./iso";
import type { GameState, Ship, Submarine } from "./types";

export const THERMOCLINE = 0.48;

export function dayPhase(timeOfDay: number): "night" | "dawn" | "day" | "dusk" {
  // timeOfDay 0..1, night-heavy cycle for U-boat feel
  if (timeOfDay < 0.22 || timeOfDay > 0.88) return "night";
  if (timeOfDay < 0.3) return "dawn";
  if (timeOfDay > 0.78) return "dusk";
  return "day";
}

export function dayLight(timeOfDay: number): number {
  // 0 dark … 1 bright
  const p = dayPhase(timeOfDay);
  if (p === "night") return 0.28;
  if (p === "dawn" || p === "dusk") return 0.55;
  return 0.92;
}

export function ambientNoiseAt(x: number, y: number, worldSize: number): number {
  // Shipping lanes along map mid-bands = noisier water (easier to hide)
  const laneX = Math.abs(x - worldSize * 0.5) / (worldSize * 0.5);
  const laneY = Math.abs(y - worldSize * 0.45) / (worldSize * 0.45);
  const lane = 1 - Math.min(laneX, laneY);
  return clamp(0.15 + lane * 0.45, 0.1, 0.7);
}

/** Aspect factor for torpedo damage/hit quality: beam best, bow/stern worse. */
export function aspectBonus(
  torpedoHeading: number,
  targetHeading: number,
): { mul: number; label: string } {
  // Angle between torpedo approach and target bow
  const rel = Math.abs(angleDiff(targetHeading, torpedoHeading + Math.PI));
  // 0 = head-on bow, PI = stern chase, PI/2 = perfect beam
  const beamness = 1 - Math.abs(rel - Math.PI / 2) / (Math.PI / 2);
  if (beamness > 0.72) return { mul: 1.35, label: "BEAM" };
  if (beamness > 0.4) return { mul: 1.1, label: "QUARTER" };
  if (rel < 0.55) return { mul: 0.72, label: "BOW" };
  return { mul: 0.85, label: "STERN" };
}

export function updateBattery(boat: Submarine, dt: number, seaState: number): void {
  const silent = boat.silentRunning;
  const snorkel = boat.snorkel;
  const surfaced = boat.z < 0.12;
  const peri = boat.z >= 0.12 && boat.z < 0.4;

  // Drain from speed (electric when submerged)
  const speedFrac = clamp(boat.speed / Math.max(0.2, boat.maxSpeed), 0, 1);
  let drain = 0;
  if (!surfaced && !snorkel) {
    drain = 0.8 + speedFrac * speedFrac * (silent ? 1.1 : 4.2);
    if (boat.scopeUp) drain += 0.35;
    if (Math.abs(boat.z - boat.targetDepth) > 0.08) drain += 0.6; // ballast work
  } else if (snorkel && peri) {
    // Snorkel: slow charge but noisy
    boat.battery = Math.min(boat.maxBattery, boat.battery + dt * 4.5);
    boat.noise = Math.min(1, boat.noise + dt * 0.15);
  } else if (surfaced) {
    boat.battery = Math.min(boat.maxBattery, boat.battery + dt * 9);
  }

  if (drain > 0) {
    boat.battery = Math.max(0, boat.battery - drain * dt * (1 + seaState * 0.15));
  }

  // Empty battery: crawl (caller applies speed caps from speedOrder)
  if (boat.battery <= 0.5 && !surfaced && !snorkel) {
    boat.battery = 0;
  }

  // Silent running: noise floor only — do not permanently rewrite speed orders
  if (silent) {
    boat.noise = Math.min(boat.noise, 0.18);
  }
}

export function applySystemsNoise(boat: Submarine): number {
  let n = boat.noise;
  if (boat.silentRunning) n *= 0.45;
  const scopeActive = boat.scopeUp && boat.z >= 0.08 && boat.z <= 0.45;
  const snorkelActive = boat.snorkel && boat.z >= 0.12 && boat.z <= 0.42;
  if (scopeActive) n = Math.max(n, 0.32);
  if (snorkelActive) n = Math.max(n, 0.55);
  if (boat.sysSonar < 0.5) n *= 1.05;
  if (boat.sysPropulsion < 0.7) n = Math.max(n, 0.4);
  return clamp(n, 0.05, 1);
}

/** Mast / visual-radar signature 0..1 for surface hunters. */
export function mastSignature(boat: Submarine, timeOfDay: number): number {
  let s = 0;
  const scopeActive = boat.scopeUp && boat.z >= 0.08 && boat.z <= 0.45;
  const snorkelActive = boat.snorkel && boat.z >= 0.12 && boat.z <= 0.42;
  if (boat.z < 0.12) s = 0.95; // fully surfaced
  else if (scopeActive) s = 0.55;
  else if (snorkelActive) s = 0.7;
  else if (boat.z < 0.22) s = 0.25; // sail almost awash
  // Night reduces visual, radar still bites snorkel
  const light = dayLight(timeOfDay);
  if (!snorkelActive) s *= 0.35 + light * 0.65;
  return clamp(s, 0, 1);
}

export function damageSystems(boat: Submarine, dmg: number): string | null {
  // Chance to hurt a subsystem proportional to damage
  if (Math.random() > Math.min(0.85, dmg / 40)) return null;
  const roll = Math.random();
  if (roll < 0.28) {
    boat.sysSonar = Math.max(0.15, boat.sysSonar - 0.25 - Math.random() * 0.2);
    return "Sonar array damaged";
  }
  if (roll < 0.5) {
    boat.sysPropulsion = Math.max(0.2, boat.sysPropulsion - 0.2 - Math.random() * 0.25);
    boat.maxSpeed = Math.max(1.1, boat.maxSpeed * 0.92);
    return "Shaft / motors damaged";
  }
  if (roll < 0.72) {
    boat.sysTubes = Math.max(0.2, boat.sysTubes - 0.3);
    return "Torpedo tubes jammed";
  }
  boat.sysFlood = Math.min(1, boat.sysFlood + 0.12 + Math.random() * 0.1);
  return "Flooding in compartments";
}

export function tickSystems(boat: Submarine, dt: number, docked: boolean): void {
  // Flooding slowly drains HP
  if (boat.sysFlood > 0.05 && !docked) {
    boat.hp = Math.max(0, boat.hp - boat.sysFlood * 4.5 * dt);
    // Slow auto-pump if not critical
    if (boat.sysFlood < 0.5 && boat.battery > 10) {
      boat.sysFlood = Math.max(0, boat.sysFlood - dt * 0.04);
      boat.battery -= dt * 0.8;
    }
  }
  if (docked) {
    boat.sysFlood = Math.max(0, boat.sysFlood - dt * 0.25);
    boat.sysSonar = Math.min(1, boat.sysSonar + dt * 0.12);
    boat.sysPropulsion = Math.min(1, boat.sysPropulsion + dt * 0.1);
    boat.sysTubes = Math.min(1, boat.sysTubes + dt * 0.15);
    boat.battery = Math.min(boat.maxBattery, boat.battery + dt * 14);
  }
}

export function fireHedgehog(
  state: GameState,
  ship: Ship,
  targetX: number,
  targetY: number,
  targetZ: number,
  uid: () => number,
): void {
  // Ahead-thrown pattern ~2.2 tiles ahead of ship toward target
  const ang = Math.atan2(targetY - ship.y, targetX - ship.x);
  const baseR = 2.0 + Math.random() * 0.4;
  const cx = ship.x + Math.cos(ang) * baseR;
  const cy = ship.y + Math.sin(ang) * baseR;
  // 6 contact-fused bombs in ellipse
  for (let i = 0; i < 6; i++) {
    const a = (i / 6) * Math.PI * 2;
    const ox = Math.cos(a) * 0.55;
    const oy = Math.sin(a) * 0.35;
    state.depthCharges.push({
      id: uid(),
      x: cx + ox,
      y: cy + oy,
      z: 0.05,
      vz: 1.6 + Math.random() * 0.4,
      fuse: 0.85 + Math.random() * 0.25,
      radius: 0.85,
      damage: 22 + Math.random() * 10,
      divertX: null,
      divertY: null,
      diverted: false,
      contact: true,
      setDepth: clamp(targetZ + (Math.random() - 0.5) * 0.12, 0.15, 0.9),
    } as any);
  }
  ship.fireCooldown = 5.5 + Math.random();
  // Hedgehog keeps sonar solution better — brief alert hold
  ship.alert = Math.min(1, ship.alert + 0.15);
  state.floats.push({
    x: ship.x,
    y: ship.y,
    text: "HEDGEHOG!",
    life: 1.3,
    color: "#7ec8ff",
    vy: -0.5,
  });
}

export function updateAircraft(state: GameState, dt: number): void {
  if (!state.aircraft) {
    state.aircraft = { x: 0, y: 0, heading: 0, life: 0, cooldown: 40 + Math.random() * 30 };
  }
  const air = state.aircraft;
  air.cooldown -= dt;
  if (air.life <= 0 && air.cooldown <= 0) {
    // Spawn patrol near player
    const a = Math.random() * Math.PI * 2;
    air.x = state.sub.x + Math.cos(a) * 22;
    air.y = state.sub.y + Math.sin(a) * 22;
    air.heading = Math.atan2(state.sub.y - air.y, state.sub.x - air.x);
    air.life = 28;
    air.cooldown = 55 + Math.random() * 40;
    if (state.messageLife < 0.3) {
      state.message = "Aircraft patrol inbound — keep the mast down.";
      state.messageLife = 3;
    }
  }
  if (air.life <= 0) return;
  air.life -= dt;
  // Orbit / hunt toward high mast signature
  const boat = state.sub;
  const mast = mastSignature(boat, state.timeOfDay);
  const hunt = mast > 0.2 || boat.noise > 0.55;
  const tx = hunt ? boat.x : boat.x + Math.cos(state.time * 0.1) * 18;
  const ty = hunt ? boat.y : boat.y + Math.sin(state.time * 0.1) * 18;
  const des = Math.atan2(ty - air.y, tx - air.x);
  air.heading += clamp(angleDiff(air.heading, des), -1.8 * dt, 1.8 * dt);
  air.x += Math.cos(air.heading) * 7.5 * dt;
  air.y += Math.sin(air.heading) * 7.5 * dt;

  const d = dist(air.x, air.y, boat.x, boat.y);
  if (d < 6 && mast > 0.35 && boat.z < 0.35) {
    // Force dive pressure + occasional bomb
    if (Math.random() < dt * 0.35) {
      for (const ship of state.ships) {
        if (!ship.dead) ship.alert = Math.min(1, ship.alert + 0.25);
      }
    }
    if (Math.random() < dt * 0.12) {
      state.depthCharges.push({
        id: (state.nextId++),
        x: boat.x + (Math.random() - 0.5) * 1.5,
        y: boat.y + (Math.random() - 0.5) * 1.5,
        z: 0.02,
        vz: 2.2,
        fuse: 1.1,
        radius: 1.8,
        damage: 28,
        divertX: null,
        divertY: null,
        diverted: false,
      });
      state.floats.push({
        x: air.x,
        y: air.y,
        text: "AIR ATTACK!",
        life: 1.5,
        color: "#f07178",
        vy: -0.55,
      });
    }
  }
}

export function convoyScreenOffset(
  index: number,
  total: number,
  freighterHeading: number,
): { x: number; y: number } {
  // Escorts take bow/beam/stern stations
  const stations = [
    { f: 4.5, s: 0 }, // bow
    { f: 1.5, s: 3.2 }, // starboard beam
    { f: 1.5, s: -3.2 }, // port beam
    { f: -3.5, s: 1.5 }, // quarter
    { f: -3.5, s: -1.5 },
    { f: 0, s: 4.5 },
  ];
  const st = stations[index % stations.length]!;
  const c = Math.cos(freighterHeading);
  const s = Math.sin(freighterHeading);
  return {
    x: c * st.f - s * st.s,
    y: s * st.f + c * st.s,
  };
}
