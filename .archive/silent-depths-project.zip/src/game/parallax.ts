/**
 * Multi-layer parallax backdrop for the isometric ocean theater.
 * Drawn behind terrain; scrolls with camera at different rates.
 * Kept intentionally light — few gradients, few shapes.
 */
import { clamp, hash2 } from "./iso";

export type ParallaxState = {
  camX: number;
  camY: number;
  time: number;
  viewW: number;
  viewH: number;
  seed: number;
  /** Sub depth 0..1 darkens lower atmosphere. */
  depth: number;
};

type Layer = {
  factor: number;
  yBias: number;
};

const LAYERS: Layer[] = [
  { factor: 0.08, yBias: 0.2 },
  { factor: 0.18, yBias: 0.4 },
  { factor: 0.32, yBias: 0.58 },
  { factor: 0.48, yBias: 0.74 },
];

function skyGradient(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  depth: number,
) {
  const g = ctx.createLinearGradient(0, 0, 0, h);
  const night = clamp(depth * 0.55, 0, 0.55);
  g.addColorStop(0, `rgb(8,${18 - night * 10 | 0},${40 - night * 8 | 0})`);
  g.addColorStop(0.4, `rgb(6,${24 - night * 12 | 0},${50 - night * 10 | 0})`);
  g.addColorStop(1, `rgb(2,${14 - night * 8 | 0},${28 - night * 6 | 0})`);
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, w, h);
}

function drawStars(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  camX: number,
  camY: number,
  time: number,
  seed: number,
  depth: number,
) {
  const alpha = 0.15 + depth * 0.35;
  if (alpha < 0.08) return;
  const ox = -camX * 2.5;
  const oy = -camY * 1.2;
  for (let i = 0; i < 12; i++) {
    const hx = hash2(i, 1, seed);
    const hy = hash2(i, 2, seed);
    const x = ((hx * w * 2 + ox) % (w + 40) + w + 40) % (w + 40) - 20;
    const y = ((hy * h * 0.55 + oy) % (h * 0.55) + h * 0.55) % (h * 0.55);
    const tw = 0.5 + Math.sin(time * 2 + i) * 0.5;
    ctx.fillStyle = `rgba(200,220,255,${alpha * (0.35 + tw * 0.65)})`;
    ctx.fillRect(x, y, 1.5 + (i % 3 === 0 ? 1 : 0), 1.5);
  }
}

function drawCloudBand(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  camX: number,
  camY: number,
  time: number,
  seed: number,
  layer: Layer,
  layerIndex: number,
) {
  const ox = -camX * layer.factor * 28;
  const oy = -camY * layer.factor * 14;
  const baseY = h * layer.yBias;
  const count = 4 + layerIndex; // fewer clouds

  for (let i = 0; i < count; i++) {
    const hx = hash2(i, layerIndex + 10, seed);
    const hy = hash2(i, layerIndex + 20, seed);
    const span = w + 280;
    const x =
      ((hx * span + ox + time * (3 + layerIndex) * (i % 2 === 0 ? 1 : -0.6)) %
        span +
        span) %
        span -
      140;
    const y = baseY + (hy - 0.5) * 40 + oy * 0.15;
    const sc = 0.75 + hx * 0.85 + layerIndex * 0.06;
    const alpha = 0.06 + (1 - layer.factor) * 0.07;

    ctx.save();
    ctx.translate(x, y);
    ctx.scale(sc, sc * 0.55);
    // Solid soft ellipse — cheaper than multi-stop radial every cloud
    ctx.fillStyle = `rgba(120,160,200,${alpha})`;
    ctx.beginPath();
    ctx.ellipse(0, 0, 62, 24, 0, 0, Math.PI * 2);
    ctx.ellipse(-36, 5, 36, 16, 0, 0, Math.PI * 2);
    ctx.ellipse(34, 4, 32, 14, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }
}

function drawIslandSilhouette(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  camX: number,
  camY: number,
  seed: number,
  layer: Layer,
  layerIndex: number,
) {
  const ox = -camX * layer.factor * 36;
  const oy = -camY * layer.factor * 10;
  const baseY = h * layer.yBias + oy * 0.2;
  const n = 3 + (layerIndex > 2 ? 1 : 0);

  ctx.save();
  for (let i = 0; i < n; i++) {
    const hx = hash2(i * 3, layerIndex + 40, seed);
    const span = w + 400;
    const x = ((hx * span + ox) % span + span) % span - 200;
    const peak = 16 + hash2(i, layerIndex + 50, seed) * (24 + layerIndex * 8);
    const width = 48 + hash2(i, layerIndex + 60, seed) * 80;
    const alpha = 0.12 + layer.factor * 0.18;

    ctx.fillStyle = `rgba(8,22,36,${alpha})`;
    ctx.beginPath();
    ctx.moveTo(x - width, baseY + 20);
    // 4-step ridge (was 6)
    const steps = 4;
    for (let s = 0; s <= steps; s++) {
      const t = s / steps;
      const px = x - width + t * width * 2;
      const nse = hash2(i + s, layerIndex, seed);
      const py =
        baseY +
        20 -
        Math.sin(t * Math.PI) * peak * (0.75 + nse * 0.4) -
        (s === Math.floor(steps / 2) ? peak * 0.2 : 0);
      ctx.lineTo(px, py);
    }
    ctx.lineTo(x + width, baseY + 20);
    ctx.closePath();
    ctx.fill();
  }
  ctx.restore();
}

function drawHorizonGlow(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  time: number,
  depth: number,
) {
  const y = h * 0.42;
  const g = ctx.createLinearGradient(0, y - 40, 0, y + 80);
  const a = 0.08 * (1 - depth * 0.5);
  g.addColorStop(0, "rgba(40,90,140,0)");
  g.addColorStop(0.45, `rgba(60,120,170,${a})`);
  g.addColorStop(1, "rgba(20,50,80,0)");
  ctx.fillStyle = g;
  ctx.fillRect(0, y - 40, w, 140);

  const sx = w * (0.72 + Math.sin(time * 0.05) * 0.04);
  const sy = h * 0.28;
  const bloom = ctx.createRadialGradient(sx, sy, 0, sx, sy, 100);
  bloom.addColorStop(0, `rgba(255,210,140,${0.06 * (1 - depth * 0.6)})`);
  bloom.addColorStop(1, "rgba(40,80,120,0)");
  ctx.fillStyle = bloom;
  ctx.beginPath();
  ctx.arc(sx, sy, 100, 0, Math.PI * 2);
  ctx.fill();
}

function drawUnderwaterRays(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  camX: number,
  time: number,
  depth: number,
) {
  if (depth < 0.15) return;
  ctx.save();
  ctx.globalCompositeOperation = "screen";
  const ox = -camX * 8;
  // 3 rays instead of 6
  for (let i = 0; i < 3; i++) {
    const x = ((i * 200 + ox + time * 10) % (w + 160) + w + 160) % (w + 160) - 80;
    const g = ctx.createLinearGradient(x, 0, x + 40, h);
    const a = 0.02 + depth * 0.035;
    g.addColorStop(0, `rgba(100,180,220,${a})`);
    g.addColorStop(1, "rgba(0,0,0,0)");
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x + 48, 0);
    ctx.lineTo(x + 18, h);
    ctx.lineTo(x - 28, h);
    ctx.closePath();
    ctx.fill();
  }
  ctx.restore();
}

/** Full parallax stack — call first each frame before terrain. */
export function drawParallax(ctx: CanvasRenderingContext2D, p: ParallaxState) {
  const { viewW: w, viewH: h, camX, camY, time, seed, depth } = p;

  skyGradient(ctx, w, h, depth);
  drawStars(ctx, w, h, camX, camY, time, seed, depth);
  drawHorizonGlow(ctx, w, h, time, depth);

  drawCloudBand(ctx, w, h, camX, camY, time, seed, LAYERS[0]!, 0);
  drawCloudBand(ctx, w, h, camX, camY, time, seed, LAYERS[1]!, 1);
  drawIslandSilhouette(ctx, w, h, camX, camY, seed, LAYERS[2]!, 2);
  drawIslandSilhouette(ctx, w, h, camX, camY, seed, LAYERS[3]!, 3);

  drawUnderwaterRays(ctx, w, h, camX, time, depth);

  const blend = ctx.createLinearGradient(0, h * 0.55, 0, h * 0.85);
  blend.addColorStop(0, "rgba(3,16,28,0)");
  blend.addColorStop(1, "rgba(3,16,28,0.55)");
  ctx.fillStyle = blend;
  ctx.fillRect(0, h * 0.55, w, h * 0.45);
}
