/**
 * WebGL water pass — directional ocean surface, land-masked, shore breakers.
 * Offscreen WebGL2 composite; not Three.js.
 */
import { TILE_H, TILE_W } from "./iso";
import { WORLD_SIZE } from "./world";
import type { TerrainCell } from "./types";

const VERT = `#version 300 es
precision highp float;
layout(location=0) in vec2 a_pos;
void main(){
  gl_Position = vec4(a_pos, 0.0, 1.0);
}
`;

// Realistic-leaning ocean: sharp Gerstner ridges, dark troughs, thin speculars,
// and shoreline breakers that run up onto the beach — not soft cloud blobs.
const FRAG = `#version 300 es
precision highp float;
out vec4 o_color;

uniform vec2 u_res;
uniform vec2 u_cam;
uniform float u_zoom;
uniform float u_time;
uniform float u_depth;
uniform float u_sea;
uniform sampler2D u_land; // R land 0/1, G shore 0..1 (1=edge), B unused

vec2 screenToWorld(vec2 frag) {
  float kX = (float(TILE_W) * 0.5) * u_zoom;
  float kY = (float(TILE_H) * 0.5) * u_zoom;
  vec2 mid = u_res * 0.5;
  float sx = frag.x - mid.x;
  float sy = frag.y - mid.y;
  float rx = (sx / kX + sy / kY) * 0.5;
  float ry = (sy / kY - sx / kX) * 0.5;
  return vec2(rx + u_cam.x, ry + u_cam.y);
}

vec4 landTex(vec2 w) {
  vec2 uv = w / float(WORLD_SIZE);
  if (uv.x < 0.0 || uv.y < 0.0 || uv.x > 1.0 || uv.y > 1.0)
    return vec4(1.0, 0.0, 0.0, 1.0);
  return texture(u_land, uv);
}

// Classic multi-Gerstner ocean height + analytical-ish slope
// Returns vec3(height, dH/dx, dH/dy)
vec3 gerstner(vec2 p, float t) {
  float H = 0.0;
  float dHx = 0.0;
  float dHy = 0.0;

  // dir, wavelength-ish (k), amplitude, speed, steepness Q
  // Primary long swell (NE)
  {
    vec2 D = normalize(vec2(0.85, 0.52));
    float k = 0.62;
    float A = 0.42;
    float w = 1.35;
    float Q = 0.55;
    float ph = k * dot(D, p) - w * t;
    float s = sin(ph);
    float c = cos(ph);
    H += A * s;
    // Gerstner horizontal steepening → sharper crests
    H += Q * A * c * 0.0; // height stays A*sin; slope gets boost
    float slope = A * k * c;
    dHx += D.x * slope * (1.0 + Q);
    dHy += D.y * slope * (1.0 + Q);
  }
  // Secondary swell
  {
    vec2 D = normalize(vec2(-0.35, 0.94));
    float k = 0.95;
    float A = 0.22;
    float w = 1.7;
    float Q = 0.4;
    float ph = k * dot(D, p) - w * t + 1.7;
    float c = cos(ph);
    H += A * sin(ph);
    float slope = A * k * c;
    dHx += D.x * slope * (1.0 + Q);
    dHy += D.y * slope * (1.0 + Q);
  }
  // Wind chop (shorter)
  {
    vec2 D = normalize(vec2(0.2, 1.0));
    float k = 2.1;
    float A = 0.08 * (0.6 + u_sea);
    float w = 3.2;
    float ph = k * dot(D, p) - w * t;
    float c = cos(ph);
    H += A * sin(ph);
    dHx += D.x * A * k * c;
    dHy += D.y * A * k * c;
  }
  // Micro ripple
  {
    vec2 D = normalize(vec2(1.0, -0.3));
    float k = 4.5;
    float A = 0.03;
    float w = 5.5;
    float ph = k * dot(D, p) - w * t * 1.2;
    H += A * sin(ph);
    dHx += D.x * A * k * cos(ph);
    dHy += D.y * A * k * cos(ph);
  }

  return vec3(H, dHx, dHy);
}

// Hash for spray grain
float hash21(vec2 p) {
  return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
}

void main() {
  vec2 frag = vec2(gl_FragCoord.x, u_res.y - gl_FragCoord.y);
  vec2 w = screenToWorld(frag);

  vec4 Ltex = landTex(w);
  float land = Ltex.r;
  float shore = Ltex.g; // 1 at waterline, 0 far offshore

  // HARD cut on land — no cloud bleed over islands
  if (land > 0.55) {
    o_color = vec4(0.0);
    return;
  }

  float t = u_time;
  vec3 G = gerstner(w, t);
  float h = G.x;
  vec2 slope = vec2(G.y, G.z);

  float surfaceMix = clamp(1.0 - u_depth * 1.35, 0.0, 1.0);
  float underMix = clamp(u_depth * 1.05, 0.0, 1.0);

  // ---- Body water: deep navy / teal, NOT milky white ----
  // Height modulates brightness: troughs dark, faces mid, crests light
  float face = clamp(h * 0.55 + 0.5, 0.0, 1.0);
  vec3 colDeep = vec3(0.015, 0.06, 0.12);
  vec3 colMid  = vec3(0.04, 0.18, 0.32);
  vec3 colShal = vec3(0.08, 0.32, 0.42); // near shore turquoise
  vec3 col = mix(colDeep, colMid, face);
  col = mix(col, colShal, shore * 0.55 * (0.6 + face * 0.4));

  // Shade from slope (directional light upper-left in iso)
  vec3 N = normalize(vec3(-slope.x, -slope.y, 0.55));
  vec3 lightDir = normalize(vec3(-0.5, -0.7, 0.85));
  float ndl = clamp(dot(N, lightDir), 0.0, 1.0);
  col *= 0.55 + ndl * 0.55;

  // Thin specular ridge — sharp highlight lines, not soft blobs
  float crest = smoothstep(0.25, 0.72, h);
  float ridge = pow(max(0.0, ndl), 48.0);
  // Align highlight to crest
  float crestLine = crest * ridge;
  col += vec3(0.75, 0.9, 1.0) * crestLine * 0.85 * surfaceMix;

  // Dark trough lines (reads as wave structure)
  float trough = smoothstep(0.05, -0.35, h);
  col = mix(col, col * vec3(0.45, 0.55, 0.7), trough * 0.55);

  // Open-ocean whitecaps: ONLY very sharp crest tips, sparse
  float capNoise = hash21(floor(w * 2.5 + t * 0.5));
  float whiteCap =
    smoothstep(0.62, 0.88, h) * smoothstep(0.35, 0.8, capNoise) * surfaceMix * (0.4 + u_sea * 0.5);
  // keep whitecaps thin
  whiteCap *= (1.0 - shore * 0.5);
  col = mix(col, vec3(0.9, 0.95, 1.0), whiteCap * 0.55);

  // ---- Shoreline BREAKERS ----
  // Wave trains run toward shore; foam wall + run-up when crest meets beach
  // shore: 1 at edge → 0 at ~6 tiles out
  float nearShore = smoothstep(0.05, 0.95, shore);
  // Incoming phase: use primary swell projected onto shore-ish direction
  // Approximate "toward land" with gradient of shore field (finite difference)
  float sR = landTex(w + vec2(0.4, 0.0)).g;
  float sU = landTex(w + vec2(0.0, 0.4)).g;
  vec2 shoreGrad = vec2(sR - shore, sU - shore);
  float gLen = length(shoreGrad) + 1e-4;
  vec2 toShore = shoreGrad / gLen;

  // Wave age along approach
  float approach = dot(w, toShore) * 1.15 - t * (1.8 + u_sea * 0.6);
  float breakerWave = sin(approach);
  // Peaking: crest that tightens near shore
  float peak = pow(max(0.0, breakerWave), 2.5);
  // Foam only in the shore band and on the forward face of the breaker
  float runUp = nearShore * peak;
  // Collapse splash right at the waterline (shore ~0.7–1.0)
  float waterline = smoothstep(0.55, 0.92, shore) * (1.0 - land);
  float crashPulse = waterline * (0.45 + 0.55 * peak);
  // Secondary wash (previous wave foam sliding back)
  float wash = waterline * smoothstep(0.2, 0.9, sin(approach * 0.55 + 1.2) * 0.5 + 0.5) * 0.45;

  float crash = (runUp * 0.75 + crashPulse * 1.1 + wash) * surfaceMix;
  crash = clamp(crash, 0.0, 1.0);

  // Turbulent foam texture (grainy, not cloudy)
  float grain =
    hash21(floor(w * 14.0 + vec2(t * 3.0, t * 2.2))) * 0.6 +
    hash21(floor(w * 28.0 - t * 5.0)) * 0.4;
  float foamMask = crash * mix(0.55, 1.0, grain);

  // Dark wet sand edge under the foam (thin)
  float wet = waterline * (1.0 - peak * 0.5) * 0.35;
  col = mix(col, vec3(0.12, 0.14, 0.16), wet);

  // Opaque white water at crash
  vec3 foam = vec3(0.93, 0.97, 1.0);
  // slight green-blue in aerated water
  foam = mix(foam, vec3(0.75, 0.9, 0.95), 0.15);
  col = mix(col, foam, foamMask * 0.92);

  // Spray flecks just above waterline (screen-space-ish via hash)
  float spray =
    waterline * peak * step(0.82, hash21(floor(frag * 0.35 + t * 8.0))) * surfaceMix;
  col = mix(col, vec3(1.0), spray * 0.7);

  // Underwater: kill surface foam, deep blue veil
  if (underMix > 0.02) {
    vec3 deep = vec3(0.01, 0.06, 0.14);
    col = mix(col, deep, underMix * 0.8);
    foamMask *= 1.0 - underMix;
    crestLine *= 1.0 - underMix;
  }

  // Subtle caustics only when shallow-looking (shore or surface)
  float caust = sin(w.x * 3.0 + t * 1.4) * sin(w.y * 2.6 - t * 1.1);
  caust = caust * 0.5 + 0.5;
  col += vec3(0.05, 0.14, 0.16) * caust * 0.1 * surfaceMix * (0.3 + shore * 0.7);

  // Alpha: structured, not a fog blanket
  // Base tint light; strong only on crests + shore crash
  float alpha =
    (0.14 + surfaceMix * 0.12) * (0.55 + face * 0.35) +
    crestLine * 0.35 * surfaceMix +
    whiteCap * 0.25 +
    foamMask * 0.72 +
    spray * 0.4;
  // Near shore always more opaque so breakers read
  alpha += nearShore * 0.12 * surfaceMix;
  alpha *= (1.0 - underMix * 0.55);
  // Fade hard at land edge
  alpha *= smoothstep(0.55, 0.2, land);
  alpha = clamp(alpha, 0.0, 0.88);

  // Premultiply-ish: keep color saturated at low alpha
  o_color = vec4(col, alpha);
}
`
  .replace(/TILE_W/g, String(TILE_W))
  .replace(/TILE_H/g, String(TILE_H))
  .replace(/WORLD_SIZE/g, String(WORLD_SIZE));

type WaterGL = {
  canvas: HTMLCanvasElement;
  gl: WebGL2RenderingContext;
  prog: WebGLProgram;
  vao: WebGLVertexArrayObject;
  landTex: WebGLTexture;
  u: Record<string, WebGLUniformLocation | null>;
  w: number;
  h: number;
  dpr: number;
  seed: number;
};

let waterGL: WaterGL | null = null;
let failed = false;

export function resetWaterPassFailure() {
  failed = false;
  waterGL = null;
}

function compile(gl: WebGL2RenderingContext, type: number, src: string) {
  const sh = gl.createShader(type)!;
  gl.shaderSource(sh, src);
  gl.compileShader(sh);
  if (!gl.getShaderParameter(sh, gl.COMPILE_STATUS)) {
    const err = gl.getShaderInfoLog(sh);
    gl.deleteShader(sh);
    throw new Error(err || "shader compile failed");
  }
  return sh;
}

function link(gl: WebGL2RenderingContext, vs: WebGLShader, fs: WebGLShader) {
  const p = gl.createProgram()!;
  gl.attachShader(p, vs);
  gl.attachShader(p, fs);
  gl.linkProgram(p);
  if (!gl.getProgramParameter(p, gl.LINK_STATUS)) {
    const err = gl.getProgramInfoLog(p);
    gl.deleteProgram(p);
    throw new Error(err || "program link failed");
  }
  return p;
}

/** R=land, G=shore proximity (1 at beach into water). */
export function buildLandShoreTextureData(terrain: TerrainCell[][]): Uint8Array {
  const n = WORLD_SIZE;
  const land = new Uint8Array(n * n);
  for (let y = 0; y < n; y++) {
    for (let x = 0; x < n; x++) {
      land[y * n + x] = terrain[y]![x]!.land ? 1 : 0;
    }
  }
  // Wider shore field for visible breaker zone (~8 tiles)
  const shore = new Float32Array(n * n);
  const maxR = 8;
  for (let y = 0; y < n; y++) {
    for (let x = 0; x < n; x++) {
      const i = y * n + x;
      if (land[i]) {
        shore[i] = 1;
        continue;
      }
      let best = maxR + 1;
      for (let r = 1; r <= maxR; r++) {
        let hit = false;
        for (let dy = -r; dy <= r && !hit; dy++) {
          for (let dx = -r; dx <= r; dx++) {
            if (Math.max(Math.abs(dx), Math.abs(dy)) !== r) continue;
            const xx = x + dx;
            const yy = y + dy;
            if (xx < 0 || yy < 0 || xx >= n || yy >= n) continue;
            if (land[yy * n + xx]) {
              best = r;
              hit = true;
              break;
            }
          }
        }
        if (hit) break;
      }
      // 1.0 at waterline (r=1), 0 far out
      shore[i] = best > maxR ? 0 : 1 - (best - 1) / maxR;
    }
  }
  const data = new Uint8Array(n * n * 4);
  for (let i = 0; i < n * n; i++) {
    data[i * 4] = land[i] ? 255 : 0;
    data[i * 4 + 1] = Math.max(0, Math.min(255, (shore[i]! * 255) | 0));
    data[i * 4 + 2] = 0;
    data[i * 4 + 3] = 255;
  }
  return data;
}

function ensureWaterGL(viewW: number, viewH: number, dpr: number): WaterGL | null {
  if (failed) return null;
  if (typeof document === "undefined") return null;

  const cssW = Math.max(1, viewW | 0);
  const cssH = Math.max(1, viewH | 0);
  // Cap water pass dpr so resize thrash is rare; still looks sharp
  const waterDpr = Math.min(dpr, 1.25);
  const bw = Math.max(1, Math.floor(cssW * waterDpr));
  const bh = Math.max(1, Math.floor(cssH * waterDpr));

  // Require larger dpr delta before realloc (avoids flash on tiny cap changes)
  if (waterGL && waterGL.w === bw && waterGL.h === bh && Math.abs(waterGL.dpr - dpr) < 0.1) {
    return waterGL;
  }

  try {
    // Force rebuild program if size change after failure recovery
    const canvas = waterGL?.canvas ?? document.createElement("canvas");
    canvas.width = bw;
    canvas.height = bh;
    const gl =
      waterGL?.gl ??
      (canvas.getContext("webgl2", {
        alpha: true,
        premultipliedAlpha: false,
        antialias: false,
        depth: false,
        stencil: false,
        preserveDrawingBuffer: true,
      }) as WebGL2RenderingContext | null);
    if (!gl) {
      failed = true;
      return null;
    }

    if (!waterGL) {
      const vs = compile(gl, gl.VERTEX_SHADER, VERT);
      const fs = compile(gl, gl.FRAGMENT_SHADER, FRAG);
      const prog = link(gl, vs, fs);
      gl.deleteShader(vs);
      gl.deleteShader(fs);

      const vao = gl.createVertexArray()!;
      gl.bindVertexArray(vao);
      const buf = gl.createBuffer()!;
      gl.bindBuffer(gl.ARRAY_BUFFER, buf);
      gl.bufferData(
        gl.ARRAY_BUFFER,
        new Float32Array([-1, -1, 1, -1, -1, 1, 1, 1]),
        gl.STATIC_DRAW,
      );
      gl.enableVertexAttribArray(0);
      gl.vertexAttribPointer(0, 2, gl.FLOAT, false, 0, 0);

      const landTex = gl.createTexture()!;
      gl.bindTexture(gl.TEXTURE_2D, landTex);
      // NEAREST keeps coasts sharp (LINEAR = cloudy soft land edges)
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
      gl.texImage2D(
        gl.TEXTURE_2D,
        0,
        gl.RGBA,
        1,
        1,
        0,
        gl.RGBA,
        gl.UNSIGNED_BYTE,
        new Uint8Array([0, 0, 0, 255]),
      );

      const uNames = ["u_res", "u_cam", "u_zoom", "u_time", "u_depth", "u_sea", "u_land"];
      const u: Record<string, WebGLUniformLocation | null> = {};
      for (const n of uNames) u[n] = gl.getUniformLocation(prog, n);

      waterGL = {
        canvas,
        gl,
        prog,
        vao,
        landTex,
        u,
        w: bw,
        h: bh,
        dpr,
        seed: -1,
      };
    } else {
      waterGL.w = bw;
      waterGL.h = bh;
      waterGL.dpr = dpr;
    }
    return waterGL;
  } catch (e) {
    console.warn("[waterPass] WebGL unavailable, using 2D fallback", e);
    failed = true;
    waterGL = null;
    return null;
  }
}

export function uploadLandMask(terrain: TerrainCell[][], seed: number) {
  const g = waterGL;
  if (!g) return;
  if (g.seed === seed) return;
  const data = buildLandShoreTextureData(terrain);
  const gl = g.gl;
  gl.bindTexture(gl.TEXTURE_2D, g.landTex);
  gl.pixelStorei(gl.UNPACK_ALIGNMENT, 1);
  gl.texImage2D(
    gl.TEXTURE_2D,
    0,
    gl.RGBA,
    WORLD_SIZE,
    WORLD_SIZE,
    0,
    gl.RGBA,
    gl.UNSIGNED_BYTE,
    data,
  );
  g.seed = seed;
}

export function isWaterPassReady() {
  return !!waterGL && !failed;
}

export function drawWebGLWater(
  ctx: CanvasRenderingContext2D,
  terrain: TerrainCell[][],
  seed: number,
  camX: number,
  camY: number,
  zoom: number,
  viewW: number,
  viewH: number,
  dpr: number,
  time: number,
  subDepth: number,
  seaState = 0.45,
): boolean {
  const g = ensureWaterGL(viewW, viewH, dpr);
  if (!g) return false;

  uploadLandMask(terrain, seed);

  const gl = g.gl;
  gl.viewport(0, 0, g.w, g.h);
  gl.clearColor(0, 0, 0, 0);
  gl.clear(gl.COLOR_BUFFER_BIT);
  gl.disable(gl.DEPTH_TEST);
  gl.enable(gl.BLEND);
  // Straight alpha — matches 2D canvas composite without milky premult haze
  gl.blendFuncSeparate(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA, gl.ONE, gl.ONE_MINUS_SRC_ALPHA);
  gl.useProgram(g.prog);
  gl.bindVertexArray(g.vao);

  gl.activeTexture(gl.TEXTURE0);
  gl.bindTexture(gl.TEXTURE_2D, g.landTex);

  gl.uniform2f(g.u.u_res!, viewW, viewH);
  gl.uniform2f(g.u.u_cam!, camX, camY);
  gl.uniform1f(g.u.u_zoom!, zoom);
  gl.uniform1f(g.u.u_time!, time);
  gl.uniform1f(g.u.u_depth!, subDepth);
  gl.uniform1f(g.u.u_sea!, seaState);
  gl.uniform1i(g.u.u_land!, 0);

  gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);

  ctx.save();
  ctx.globalCompositeOperation = "source-over";
  ctx.drawImage(g.canvas, 0, 0, g.w, g.h, 0, 0, viewW, viewH);
  ctx.restore();
  return true;
}

export function invalidateWaterMask() {
  if (waterGL) waterGL.seed = -1;
}
