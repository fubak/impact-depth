/**
 * Isometric ocean renderer — terrain cache, vessels, FX, WebGL water composite.
 * Anti-flicker: sticky quality, stable terrain bake, no plant thrash, smooth shore.
 */
import {
  clamp,
  depthToWorldZ,
  fbm,
  hash2,
  TILE_H,
  TILE_W,
  worldHeadingToScreen,
  worldToScreen,
} from "./iso";
import {
  drawDepthVeil,
  drawDynamicShadow,
  drawFacingDebug,
  drawFacingDebugLegend,
  drawFastTorpedo,
  drawLiveShip,
  drawLiveSub,
  ensureSpriteSheets,
} from "./sprites";
import { drawParallax } from "./parallax";
import type {
  Countermeasure,
  GameState,
  PowerupKind,
  Ship,
  TerrainCell,
  Torpedo,
} from "./types";
import type { RemotePlayer } from "./net";
import { elevationWorldZ, WORLD_SIZE } from "./world";
import { ACTIVE_PING_DURATION, ACTIVE_PING_RANGE } from "./sonar";
import { dayLight, dayPhase } from "./tactics";
import { drawWebGLWater, resetWaterPassFailure } from "./waterPass";

resetWaterPassFailure();

/** 0 = low / 1 = med / 2 = high — sticky adaptive quality (no published thrash). */
export let renderQuality = 2;
let qualityBadStreak = 0;
let qualityGoodStreak = 0;
let qualityCooldown = 180;

export function setRenderQuality(q: number) {
  renderQuality = q < 0 ? 0 : q > 2 ? 2 : (q | 0);
}

export function noteFrameMs(frameMsEma: number) {
  if (qualityCooldown > 0) {
    qualityCooldown--;
    return;
  }
  if (frameMsEma > 30) {
    qualityBadStreak++;
    qualityGoodStreak = 0;
  } else if (frameMsEma < 15) {
    qualityGoodStreak++;
    qualityBadStreak = Math.max(0, qualityBadStreak - 2);
  } else {
    qualityBadStreak = Math.max(0, qualityBadStreak - 1);
    qualityGoodStreak = Math.max(0, qualityGoodStreak - 1);
  }
  if (qualityBadStreak > 150 && renderQuality > 0) {
    setRenderQuality(renderQuality - 1);
    qualityBadStreak = 0;
    qualityGoodStreak = 0;
    qualityCooldown = 360;
  } else if (qualityGoodStreak > 480 && renderQuality < 2) {
    setRenderQuality(renderQuality + 1);
    qualityBadStreak = 0;
    qualityGoodStreak = 0;
    qualityCooldown = 480;
  }
}

function biomeColor(biome: number, height: number, shade: number): string {
  let r = 0, g = 0, b = 0;
  if (biome === 0) { r = 194 + height * 30; g = 168 + height * 20; b = 110 + height * 10; }
  else if (biome === 1) { r = 70 + height * 50; g = 78 + height * 45; b = 88 + height * 40; }
  else if (biome === 2) { r = 40 + height * 40; g = 110 + height * 50; b = 100 + height * 30; }
  else if (biome === 3) { r = 18 + height * 20; g = 28 + height * 25; b = 48 + height * 40; }
  else if (biome === 4) { r = 210 + height * 20; g = 190 + height * 15; b = 130 + height * 10; }
  else if (biome === 5) { r = 35 + height * 25; g = 90 + height * 40; b = 40 + height * 15; }
  else { r = 95 + height * 40; g = 95 + height * 35; b = 100 + height * 30; }
  r = clamp(r * shade, 0, 255);
  g = clamp(g * shade, 0, 255);
  b = clamp(b * shade, 0, 255);
  return `rgb(${r | 0},${g | 0},${b | 0})`;
}

function drawDiamond(
  ctx: CanvasRenderingContext2D,
  sx: number, sy: number, zw: number, zh: number, fill: string,
) {
  const hx = zw * 0.5, hy = zh * 0.5;
  ctx.beginPath();
  ctx.moveTo(sx, sy - hy);
  ctx.lineTo(sx + hx, sy);
  ctx.lineTo(sx, sy + hy);
  ctx.lineTo(sx - hx, sy);
  ctx.closePath();
  ctx.fillStyle = fill;
  ctx.fill();
}

function drawPlant(
  ctx: CanvasRenderingContext2D,
  sx: number, sy: number, zoom: number,
  plant: number, plantType: number, _t: number, seed: number,
) {
  const sway = Math.sin(seed * 6.1) * 1.2 * zoom;
  if (plantType === 0 || plantType === 2) {
    const blades = plantType === 0 ? 2 + ((seed * 10) | 0) % 2 : 2;
    for (let i = 0; i < blades; i++) {
      const h = (10 + plant * 22 + i * 4) * zoom;
      const ox = (i - blades / 2) * 3 * zoom;
      ctx.strokeStyle = plantType === 0
        ? `rgba(${20 + i * 15},${90 + i * 20},${50 + i * 10},${0.55 + plant * 0.3})`
        : `rgba(40,120,70,${0.4 + plant * 0.3})`;
      ctx.lineWidth = Math.max(0.5, (1.2 + plant) * zoom);
      ctx.beginPath();
      ctx.moveTo(sx + ox, sy);
      ctx.quadraticCurveTo(sx + ox + sway, sy - h * 0.5, sx + ox + sway * 0.5, sy - h);
      ctx.stroke();
    }
  } else if (plantType === 1) {
    ctx.fillStyle = `rgba(${180 + ((seed * 40) % 40)},${60 + ((seed * 80) % 50)},90,0.7)`;
    const h = 8 * plant * zoom;
    ctx.beginPath();
    ctx.moveTo(sx, sy); ctx.lineTo(sx - 4 * zoom, sy - h);
    ctx.lineTo(sx, sy - h * 1.3); ctx.lineTo(sx + 4 * zoom, sy - h);
    ctx.closePath(); ctx.fill();
  } else if (plantType === 4) {
    const trunkH = (14 + plant * 16) * zoom;
    ctx.fillStyle = "#4a3020";
    ctx.fillRect(sx - 1.5 * zoom, sy - trunkH, 3 * zoom, trunkH);
    const layers = 2 + ((seed * 5) | 0) % 2;
    for (let i = 0; i < layers; i++) {
      const yy = sy - trunkH * (0.45 + i * 0.18);
      const rr = (10 + plant * 8 - i * 2) * zoom;
      ctx.fillStyle = i % 2 === 0 ? "#1a6b38" : "#148a42";
      ctx.beginPath();
      ctx.ellipse(sx + sway * 0.15, yy, rr, rr * 0.55, 0, 0, Math.PI * 2);
      ctx.fill();
    }
  } else if (plantType === 5) {
    const trunkH = (12 + plant * 10) * zoom;
    ctx.strokeStyle = "#6b4a2a";
    ctx.lineWidth = Math.max(1.2, 2.2 * zoom);
    ctx.beginPath();
    ctx.moveTo(sx, sy);
    ctx.quadraticCurveTo(sx + sway * 0.4, sy - trunkH * 0.5, sx + sway * 0.2, sy - trunkH);
    ctx.stroke();
  } else {
    const h = (10 + plant * 12) * zoom;
    ctx.fillStyle = "#3a2a1a";
    ctx.fillRect(sx - zoom, sy - h * 0.4, 2 * zoom, h * 0.4);
    ctx.fillStyle = "#2a4a32";
    ctx.beginPath();
    ctx.moveTo(sx, sy - h);
    ctx.lineTo(sx - 6 * zoom, sy - h * 0.25);
    ctx.lineTo(sx + 6 * zoom, sy - h * 0.25);
    ctx.closePath(); ctx.fill();
  }
}

function drawMountainExtrusion(
  ctx: CanvasRenderingContext2D,
  sx: number, baseSy: number, elevPx: number, zoom: number,
  left: string, right: string, top: string,
) {
  const hx = TILE_W * 0.5 * zoom;
  const hy = TILE_H * 0.5 * zoom;
  const topY = baseSy - elevPx;
  ctx.fillStyle = left;
  ctx.beginPath();
  ctx.moveTo(sx - hx, baseSy); ctx.lineTo(sx, baseSy + hy);
  ctx.lineTo(sx, topY + hy); ctx.lineTo(sx - hx, topY);
  ctx.closePath(); ctx.fill();
  ctx.fillStyle = right;
  ctx.beginPath();
  ctx.moveTo(sx + hx, baseSy); ctx.lineTo(sx, baseSy + hy);
  ctx.lineTo(sx, topY + hy); ctx.lineTo(sx + hx, topY);
  ctx.closePath(); ctx.fill();
  ctx.fillStyle = top;
  ctx.beginPath();
  ctx.moveTo(sx, topY - hy); ctx.lineTo(sx + hx, topY);
  ctx.lineTo(sx, topY + hy); ctx.lineTo(sx - hx, topY);
  ctx.closePath(); ctx.fill();
}

type TileVis = {
  elevZ: number; elevBase: number; extruded: boolean; land: boolean;
  plant: number; plantType: number; plantSeed: number;
  top: string; left: string; right: string; floor: string;
  waterFill: string; waterFilm: string; depthVis: number;
};

let visCache: TileVis[][] | null = null;
let visSeed = -1;
const VIS_PALETTE_VER = 4;

function buildVisCache(terrain: TerrainCell[][], seed: number): TileVis[][] {
  const grid: TileVis[][] = [];
  for (let y = 0; y < WORLD_SIZE; y++) {
    const row: TileVis[] = [];
    for (let x = 0; x < WORLD_SIZE; x++) {
      const cell = terrain[y]![x]!;
      const elevZ = elevationWorldZ(cell.height, cell.land);
      const elevBase = elevZ * 40;
      const n = fbm(x * 0.15, y * 0.15, seed, 2);
      const shade = 0.75 + n * 0.35 + (x - y) * 0.002;
      const extruded = cell.land || cell.height > 0.55;
      const depthVis = 1 - cell.height;
      const wr = 6 + depthVis * 28 + (1 - depthVis) * 8;
      const wg = 28 + depthVis * 55 + (1 - depthVis) * 20;
      const wb = 72 + depthVis * 70 + (1 - depthVis) * 10;
      const wa = Math.min(0.94, 0.62 + depthVis * 0.32);
      const r = (wr * 0.55 + 18 * (1 - depthVis) + n * 8) | 0;
      const g = (wg * 0.75 + 35 * (1 - depthVis) + n * 12) | 0;
      const b = (wb * 0.9 + 22 * (1 - depthVis) + n * 10) | 0;
      const filmA = (0.22 + depthVis * 0.28) * 0.65;
      const filmR = (8 + depthVis * 40) | 0;
      const filmG = (40 + depthVis * 70) | 0;
      const filmB = (90 + depthVis * 90) | 0;
      row.push({
        elevZ, elevBase, extruded, land: cell.land,
        plant: cell.plant, plantType: cell.plantType, plantSeed: hash2(x, y, seed),
        top: biomeColor(cell.biome, cell.height, shade),
        left: biomeColor(cell.biome, cell.height, shade * 0.72),
        right: biomeColor(cell.biome, cell.height, shade * 0.55),
        floor: biomeColor(cell.biome, cell.height, shade),
        waterFill: `rgba(${r},${g},${b},${wa})`,
        waterFilm: `rgba(${filmR},${filmG},${filmB},${filmA})`,
        depthVis,
      });
    }
    grid.push(row);
  }
  return grid;
}

function getVis(terrain: TerrainCell[][], seed: number): TileVis[][] {
  const key = seed + VIS_PALETTE_VER * 1e9;
  if (!visCache || visSeed !== key) {
    visCache = buildVisCache(terrain, seed);
    visSeed = key;
  }
  return visCache;
}

function viewTileRange(viewW: number, viewH: number, zoom: number): number {
  const z = Math.max(0.35, zoom);
  const maxRx = viewW / (TILE_W * z) + 2;
  const maxRy = viewH / (TILE_H * z) + 2;
  return Math.ceil((maxRx + maxRy) * 0.5) + 1;
}

type TerrainLayer = {
  canvas: HTMLCanvasElement; ctx: CanvasRenderingContext2D;
  camX: number; camY: number; zoom: number; seed: number;
  viewW: number; viewH: number; dpr: number; pad: number;
  cssW: number; cssH: number; quality: number;
};
let terrainLayer: TerrainLayer | null = null;

function ensureTerrainLayer(viewW: number, viewH: number, dpr: number, quality: number): TerrainLayer {
  const pad = 96;
  const cssW = viewW + pad * 2;
  const cssH = viewH + pad * 2;
  const bw = Math.max(1, Math.floor(cssW * dpr));
  const bh = Math.max(1, Math.floor(cssH * dpr));
  const needNew =
    !terrainLayer ||
    terrainLayer.viewW !== viewW ||
    terrainLayer.viewH !== viewH ||
    Math.abs(terrainLayer.dpr - dpr) > 0.08;

  if (needNew) {
    const canvas = terrainLayer?.canvas ?? document.createElement("canvas");
    if (canvas.width !== bw || canvas.height !== bh) {
      canvas.width = bw;
      canvas.height = bh;
    }
    const ctx =
      terrainLayer?.ctx ??
      canvas.getContext("2d", { alpha: true, desynchronized: false })!;
    terrainLayer = {
      canvas, ctx, camX: 0, camY: 0, zoom: 0, seed: -1,
      viewW, viewH, dpr, pad, cssW, cssH, quality,
    };
  } else {
    terrainLayer!.quality = quality;
  }
  return terrainLayer!;
}

function terrainNeedsRebake(
  layer: TerrainLayer, camX: number, camY: number, zoom: number, seed: number,
): boolean {
  if (layer.seed !== seed) return true;
  if (Math.abs(layer.zoom - zoom) > 0.05) return true;
  const kX = (TILE_W / 2) * zoom;
  const kY = (TILE_H / 2) * zoom;
  const dx = camX - layer.camX;
  const dy = camY - layer.camY;
  const sdx = (dx - dy) * kX;
  const sdy = (dx + dy) * kY;
  const margin = layer.pad * 0.72;
  return Math.abs(sdx) > margin || Math.abs(sdy) > margin;
}

function bakeTerrainLayer(
  layer: TerrainLayer, terrain: TerrainCell[][],
  camX: number, camY: number, zoom: number, seed: number, _t: number,
) {
  const { ctx, dpr, pad, cssW, cssH, viewW, viewH } = layer;
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.clearRect(0, 0, cssW, cssH);
  const vis = getVis(terrain, seed);
  const range = viewTileRange(viewW, viewH, zoom) + Math.ceil(pad / (TILE_H * zoom)) + 1;
  const minX = clamp(Math.floor(camX - range), 0, WORLD_SIZE - 1);
  const maxX = clamp(Math.ceil(camX + range), 0, WORLD_SIZE - 1);
  const minY = clamp(Math.floor(camY - range), 0, WORLD_SIZE - 1);
  const maxY = clamp(Math.ceil(camY + range), 0, WORLD_SIZE - 1);
  const zw = TILE_W * zoom, zh = TILE_H * zoom;
  const kX = (TILE_W / 2) * zoom, kY = (TILE_H / 2) * zoom;
  const zPx = 40 * zoom;
  const midX = cssW / 2, midY = cssH / 2;
  // Fixed plant density — never thrash with quality
  const drawPlants = zoom >= 0.65;

  for (let y = minY; y <= maxY; y++) {
    const row = vis[y]!;
    for (let x = minX; x <= maxX; x++) {
      const v = row[x]!;
      const rx = x - camX, ry = y - camY;
      const baseSx = (rx - ry) * kX + midX;
      const baseSy = (rx + ry) * kY + midY;
      const elevPx = v.elevBase * zoom;
      const sx = baseSx;
      const sy = baseSy - v.elevZ * zPx;
      if (sx < -8 || sx > cssW + 8 || sy < -80 || sy > cssH + 8 + elevPx) continue;

      if (v.extruded) {
        drawMountainExtrusion(ctx, sx, sy + elevPx, elevPx, zoom, v.left, v.right, v.top);
        if (!v.land) drawDiamond(ctx, baseSx, baseSy, zw, zh, v.waterFilm);
      } else if (!v.land) {
        drawDiamond(ctx, baseSx, baseSy, zw, zh, v.waterFill);
      } else {
        drawDiamond(ctx, sx, sy, zw, zh, v.floor);
      }

      if (drawPlants && v.plant > 0.2) {
        if (((x + y) & 1) !== 0) continue;
        if (zoom < 0.9 && ((x * 3 + y) & 3) !== 0) continue;
        const plantSy = baseSy - (v.elevZ + (v.land ? 0.02 : 0.01)) * zPx + 0.6 * kY;
        drawPlant(ctx, baseSx, plantSy, zoom, v.plant, v.plantType, 0, v.plantSeed);
      }
    }
  }
  layer.camX = camX; layer.camY = camY; layer.zoom = zoom; layer.seed = seed;
}

function blitTerrainLayer(
  ctx: CanvasRenderingContext2D, layer: TerrainLayer,
  camX: number, camY: number, zoom: number,
) {
  const kX = (TILE_W / 2) * zoom, kY = (TILE_H / 2) * zoom;
  const dx = camX - layer.camX, dy = camY - layer.camY;
  const sdx = (dx - dy) * kX, sdy = (dx + dy) * kY;
  ctx.drawImage(
    layer.canvas, 0, 0, layer.canvas.width, layer.canvas.height,
    -layer.pad - sdx, -layer.pad - sdy, layer.cssW, layer.cssH,
  );
}

function drawSurfaceLighting(
  ctx: CanvasRenderingContext2D, sx: number, sy: number, zoom: number, time: number, strength = 1,
) {
  // Gentle pulse — avoid harsh blink
  const pulse = 0.75 + Math.sin(time * 1.6 + sx * 0.008) * 0.25;
  const r = 26 * zoom;
  const g = ctx.createRadialGradient(sx - r * 0.28, sy - r * 0.4, 0, sx, sy, r);
  g.addColorStop(0, `rgba(235,248,255,${0.14 * strength * pulse})`);
  g.addColorStop(0.4, `rgba(160,210,240,${0.06 * strength})`);
  g.addColorStop(1, "rgba(40,80,120,0)");
  ctx.fillStyle = g;
  ctx.beginPath();
  ctx.ellipse(sx, sy, r * 1.15, r * 0.52, 0, 0, Math.PI * 2);
  ctx.fill();
}

function drawWaterSurfaceFx(
  ctx: CanvasRenderingContext2D,
  camX: number, camY: number, zoom: number,
  viewW: number, viewH: number, time: number, subDepth: number, quality: number,
) {
  if (quality < 1) return;
  ctx.save();
  const depthA = clamp(subDepth * 0.3, 0, 0.4);
  if (depthA > 0.02) {
    ctx.fillStyle = `rgba(2,12,28,${depthA})`;
    ctx.fillRect(0, 0, viewW, viewH);
  }
  const bands = quality >= 2 ? 5 : 3;
  for (let i = 0; i < bands; i++) {
    const phase = time * 0.35 + i * 1.7;
    const wx = camX + Math.sin(phase) * 10;
    const wy = camY + Math.cos(phase * 0.8) * 10;
    const { sx, sy } = worldToScreen(wx, wy, 0, camX, camY, zoom, viewW, viewH);
    const rx = (30 + i * 8) * zoom;
    const g = ctx.createRadialGradient(sx, sy, 0, sx, sy, rx);
    g.addColorStop(0, "rgba(40,100,150,0.1)");
    g.addColorStop(1, "rgba(10,40,70,0)");
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.ellipse(sx, sy, rx, rx * 0.4, 0, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();
}

function drawShoreCrashFx(
  ctx: CanvasRenderingContext2D,
  terrain: TerrainCell[][],
  camX: number, camY: number, zoom: number,
  viewW: number, viewH: number, time: number, subDepth: number, quality: number,
) {
  if (quality < 1 || subDepth > 0.55) return;
  const surface = clamp(1 - subDepth * 1.4, 0, 1);
  if (surface < 0.15) return;
  ctx.save();
  const step = quality >= 2 ? 1 : 2;
  const range = quality >= 2 ? 14 : 10;
  const minX = clamp(Math.floor(camX - range), 1, WORLD_SIZE - 2);
  const maxX = clamp(Math.ceil(camX + range), 1, WORLD_SIZE - 2);
  const minY = clamp(Math.floor(camY - range), 1, WORLD_SIZE - 2);
  const maxY = clamp(Math.ceil(camY + range), 1, WORLD_SIZE - 2);

  for (let y = minY; y <= maxY; y += step) {
    for (let x = minX; x <= maxX; x += step) {
      if (terrain[y]![x]!.land) continue;
      let nextToLand = false;
      let ldx = 0, ldy = 0;
      for (let dy = -1; dy <= 1; dy++) {
        for (let dx = -1; dx <= 1; dx++) {
          if (!dx && !dy) continue;
          if (terrain[y + dy]?.[x + dx]?.land) {
            nextToLand = true;
            ldx = dx; ldy = dy;
          }
        }
      }
      if (!nextToLand) continue;

      // Continuous phase — residual foam always present (no hard pop)
      const phase = Math.sin(x * 1.1 + y * 0.85 - time * 2.0 + x * 0.17 + y * 0.13);
      const boom = clamp(phase * 0.5 + 0.5, 0, 1);
      const intensity = 0.22 + boom * 0.78;

      const { sx, sy } = worldToScreen(
        x + 0.5 - ldx * 0.15, y + 0.5 - ldy * 0.15, 0,
        camX, camY, zoom, viewW, viewH,
      );
      if (sx < -40 || sy < -40 || sx > viewW + 40 || sy > viewH + 40) continue;

      const rx = (7 + boom * 14) * zoom;
      const ry = rx * 0.36;
      ctx.globalAlpha = intensity * 0.5 * surface;

      ctx.fillStyle = `rgba(20,50,80,${0.22 * boom})`;
      ctx.beginPath();
      ctx.ellipse(sx + ldx * 2 * zoom, sy + ldy * zoom + 2 * zoom, rx * 1.05, ry * 1.05, 0.1, 0, Math.PI * 2);
      ctx.fill();

      const g = ctx.createLinearGradient(sx, sy - ry, sx, sy + ry);
      g.addColorStop(0, "rgba(255,255,255,0.85)");
      g.addColorStop(0.4, "rgba(220,240,255,0.5)");
      g.addColorStop(0.75, "rgba(140,190,220,0.12)");
      g.addColorStop(1, "rgba(40,90,120,0)");
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.ellipse(sx, sy - boom * 2.5 * zoom, rx, ry, Math.atan2(ldy, ldx) * 0.3, 0, Math.PI * 2);
      ctx.fill();

      if (quality >= 2 && boom > 0.75) {
        const sprayA = (boom - 0.75) / 0.25;
        ctx.fillStyle = "#f4fbff";
        for (let i = 0; i < 3; i++) {
          const a = Math.atan2(-1 + ldy * 0.3, ldx * 0.5 + (i - 1.5) * 0.35);
          const dist = (8 + boom * 16 + i * 2.5) * zoom;
          const px = sx + Math.cos(a) * dist;
          const py = sy + Math.sin(a) * dist * 0.45 - boom * 10 * zoom;
          ctx.globalAlpha = sprayA * 0.5 * surface * (1 - i / 4);
          ctx.beginPath();
          ctx.ellipse(px, py, (1.2 + boom) * zoom, (0.6 + boom * 0.4) * zoom, a, 0, Math.PI * 2);
          ctx.fill();
        }
      }
    }
  }
  ctx.globalAlpha = 1;
  ctx.restore();
}

function drawSonarContacts(
  ctx: CanvasRenderingContext2D, state: GameState,
  camX: number, camY: number, zoom: number, viewW: number, viewH: number, _time: number,
) {
  const contacts = state.sonarContacts;
  if (!contacts?.length) return;
  const boat = state.sub;
  const origin = worldToScreen(boat.x, boat.y, depthToWorldZ(boat.z), camX, camY, zoom, viewW, viewH);
  for (const c of contacts) {
    const { sx, sy } = worldToScreen(c.x, c.y, 0, camX, camY, zoom, viewW, viewH);
    if (sx < -20 || sy < -20 || sx > viewW + 20 || sy > viewH + 20) continue;
    const a = clamp(c.strength, 0.15, 1) * (1 - c.age / Math.max(0.01, c.maxAge));
    ctx.save();
    ctx.globalAlpha = a;
    ctx.strokeStyle = c.source === "active" ? "#5eead4" : "#3b9eff";
    ctx.lineWidth = Math.max(1, 1.4 * zoom);
    ctx.beginPath();
    ctx.arc(sx, sy, (4 + c.strength * 6) * zoom, 0, Math.PI * 2);
    ctx.stroke();
    if (c.strength > 0.35) {
      ctx.setLineDash([3 * zoom, 4 * zoom]);
      ctx.globalAlpha = a * 0.4;
      ctx.beginPath();
      ctx.moveTo(origin.sx, origin.sy);
      ctx.lineTo(sx, sy);
      ctx.stroke();
      ctx.setLineDash([]);
    }
    ctx.restore();
  }
}

function drawActiveSonarRings(
  ctx: CanvasRenderingContext2D, state: GameState,
  camX: number, camY: number, zoom: number, viewW: number, viewH: number,
) {
  if (state.sonarPing <= 0) return;
  const boat = state.sub;
  const { sx, sy } = worldToScreen(boat.x, boat.y, 0, camX, camY, zoom, viewW, viewH);
  const t = 1 - state.sonarPing / ACTIVE_PING_DURATION;
  const maxR = ACTIVE_PING_RANGE * (TILE_W * 0.55) * zoom;
  const r = maxR * t;
  ctx.save();
  ctx.strokeStyle = `rgba(94,234,212,${0.55 * (1 - t)})`;
  ctx.lineWidth = Math.max(1, 2 * zoom);
  ctx.beginPath();
  ctx.ellipse(sx, sy, r, r * 0.5, 0, 0, Math.PI * 2);
  ctx.stroke();
  ctx.restore();
}

function shipScale(cls: Ship["class"]): number {
  if (cls === "battleship") return 1.35;
  if (cls === "cruiser") return 1.15;
  if (cls === "sub") return 1.45;
  if (cls === "destroyer") return 1.0;
  if (cls === "freighter") return 1.1;
  return 0.9;
}

function drawShip(
  ctx: CanvasRenderingContext2D, ship: Ship,
  sx: number, sy: number, zoom: number, selected: boolean, time: number, debugFacing: boolean,
) {
  const q = renderQuality;
  const isEnemySub = ship.class === "sub";
  const base = shipScale(ship.class);
  const alpha = ship.sinking > 0 ? clamp(1 - ship.sinking, 0.2, 1) : 1;
  const depth = isEnemySub ? 0.35 : 0;
  const py = sy;

  if (q >= 1) {
    drawDynamicShadow(ctx, {
      sx, sy: py, depth: isEnemySub ? 0.55 : 0.05,
      radiusX: 18 * zoom * base, radiusY: 10 * zoom * base, strength: 0.85 * alpha,
    });
  }

  drawLiveShip(ctx, ship.class, ship.displayHeading, sx, py, zoom, base, alpha, depth);

  if (selected) {
    ctx.strokeStyle = "rgba(94,234,212,0.85)";
    ctx.lineWidth = Math.max(1.5, 2 * zoom);
    ctx.beginPath();
    ctx.ellipse(sx, py + 4 * zoom, 22 * zoom * base, 10 * zoom * base, 0, 0, Math.PI * 2);
    ctx.stroke();
  }

  if (ship.alert > 0.4 && q >= 1) {
    // Soft pulse — no hard blink
    const pulse = 0.55 + Math.sin(time * 3.5) * 0.25;
    ctx.fillStyle = `rgba(240,113,120,${pulse})`;
    ctx.beginPath();
    ctx.arc(sx, py - 22 * zoom * base, 3 * zoom, 0, Math.PI * 2);
    ctx.fill();
  }

  if (ship.hp < ship.maxHp && ship.sinking === 0) {
    const bw = 28 * zoom * base;
    const pct = clamp(ship.hp / ship.maxHp, 0, 1);
    ctx.fillStyle = "rgba(0,0,0,0.45)";
    ctx.fillRect(sx - bw / 2, py - 32 * zoom, bw, 3 * zoom);
    ctx.fillStyle = pct > 0.45 ? "#7fd99a" : "#f07178";
    ctx.fillRect(sx - bw / 2, py - 32 * zoom, bw * pct, 3 * zoom);
  }

  if (debugFacing) drawFacingDebug(ctx, sx, py, ship.heading, zoom, "SHIP");
  if (q >= 2 && ship.sinking === 0 && zoom >= 0.75 && !isEnemySub) {
    drawSurfaceLighting(ctx, sx, py, zoom, time, 0.5);
  }
}

function drawSubmarine(
  ctx: CanvasRenderingContext2D, state: GameState,
  sx: number, sy: number, zoom: number, playerName?: string,
) {
  const boat = state.sub;
  const q = renderQuality;
  const underwater = boat.z > 0.12;
  const alpha = underwater ? clamp(1 - boat.z * 0.42, 0.5, 0.96) : 1;
  const py = sy;

  if (q >= 1) {
    drawDynamicShadow(ctx, {
      sx, sy: py, depth: boat.z,
      radiusX: 16 * zoom, radiusY: 9 * zoom, strength: 0.9 * alpha,
    });
  }

  drawLiveSub(ctx, boat.displayHeading, sx, py, zoom, 1.05, alpha, boat.z);
  if (underwater && q >= 1) drawDepthVeil(ctx, sx, py, 20 * zoom, boat.z);
  if (q >= 2 && !underwater) drawSurfaceLighting(ctx, sx, py, zoom, state.time, 0.65);

  if (boat.scopeUp && boat.z < 0.5) {
    ctx.strokeStyle = "rgba(200,220,240,0.7)";
    ctx.lineWidth = Math.max(1, 1.2 * zoom);
    ctx.beginPath();
    ctx.moveTo(sx, py);
    ctx.lineTo(sx, py - 14 * zoom);
    ctx.stroke();
  }

  if (playerName) {
    ctx.fillStyle = "rgba(232,238,246,0.85)";
    ctx.font = `${Math.max(10, 11 * zoom)}px sans-serif`;
    ctx.textAlign = "center";
    ctx.fillText(playerName, sx, py - 28 * zoom);
  }

  if (state.debugFacing) drawFacingDebug(ctx, sx, py, boat.heading, zoom, "OWN");
}

function drawTorpedo(
  ctx: CanvasRenderingContext2D, torp: Torpedo, sx: number, sy: number, zoom: number, time: number,
) {
  const rot = worldHeadingToScreen(torp.heading);
  drawFastTorpedo(ctx, sx, sy, rot, zoom, torp.seeking, time, torp.owner === "enemy" ? 0.85 : 1);
  if (torp.seeking) {
    ctx.strokeStyle = "rgba(94,234,212,0.35)";
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.arc(sx, sy, 8 * zoom, 0, Math.PI * 2);
    ctx.stroke();
  }
}

function drawCountermeasure(
  ctx: CanvasRenderingContext2D, cm: Countermeasure, sx: number, sy: number, zoom: number, time: number,
) {
  const life = clamp(cm.life / cm.maxLife, 0, 1);
  ctx.save();
  ctx.globalAlpha = life * 0.75;
  if (cm.kind === "bubble") {
    const r = cm.radius * 10 * zoom * (0.7 + (1 - life) * 0.5);
    ctx.strokeStyle = "rgba(160,220,255,0.6)";
    ctx.lineWidth = Math.max(1, 1.5 * zoom);
    ctx.beginPath();
    ctx.ellipse(sx, sy, r, r * 0.45, 0, 0, Math.PI * 2);
    ctx.stroke();
    for (let i = 0; i < 5; i++) {
      const a = time * 2 + i * 1.2;
      ctx.fillStyle = "rgba(180,230,255,0.5)";
      ctx.beginPath();
      ctx.arc(sx + Math.cos(a) * r * 0.5, sy + Math.sin(a) * r * 0.22, 2 * zoom, 0, Math.PI * 2);
      ctx.fill();
    }
  } else {
    ctx.fillStyle = "#e6c07b";
    ctx.beginPath();
    ctx.ellipse(sx, sy, 6 * zoom, 3 * zoom, time, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();
}

function drawDepthChargeVisual(
  ctx: CanvasRenderingContext2D, sx: number, sy: number, z: number, fuse: number, zoom: number, time: number,
) {
  const r = (4 + z * 2) * zoom;
  ctx.save();
  // Soft fuse pulse near end
  const fuseA = fuse < 0.4 ? 0.75 + Math.sin(time * 12) * 0.2 : 1;
  ctx.globalAlpha = fuseA;
  ctx.fillStyle = fuse < 0.4 ? "#f07178" : "#c4a882";
  ctx.beginPath();
  ctx.arc(sx, sy, r, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = "rgba(255,255,255,0.35)";
  ctx.lineWidth = 1;
  ctx.stroke();
  ctx.restore();
}

function drawNavalBase(
  ctx: CanvasRenderingContext2D, state: GameState,
  camX: number, camY: number, zoom: number, viewW: number, viewH: number, time: number,
) {
  const b = state.base;
  if (!b) return;
  const { sx, sy } = worldToScreen(b.x, b.y, 0.05, camX, camY, zoom, viewW, viewH);
  const R = b.radius * (TILE_W * 0.55) * zoom;
  ctx.save();
  ctx.strokeStyle = "rgba(94,234,212,0.35)";
  ctx.lineWidth = Math.max(1, 1.5 * zoom);
  ctx.setLineDash([6 * zoom, 5 * zoom]);
  ctx.beginPath();
  ctx.ellipse(sx, sy, R, R * 0.5, 0, 0, Math.PI * 2);
  ctx.stroke();
  ctx.setLineDash([]);
  ctx.fillStyle = "#3a4a55";
  ctx.beginPath();
  ctx.ellipse(sx, sy, 14 * zoom, 7 * zoom, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = "#5a6a75";
  ctx.fillRect(sx - 6 * zoom, sy - 10 * zoom, 12 * zoom, 10 * zoom);
  ctx.fillStyle = "#7fd99a";
  ctx.globalAlpha = 0.55 + Math.sin(time * 1.5) * 0.15;
  ctx.fillRect(sx - 2 * zoom, sy - 14 * zoom, 4 * zoom, 4 * zoom);
  ctx.globalAlpha = 1;
  ctx.fillStyle = "rgba(232,238,246,0.8)";
  ctx.font = `${Math.max(9, 10 * zoom)}px sans-serif`;
  ctx.textAlign = "center";
  ctx.fillText(b.name || "FOB", sx, sy + 18 * zoom);
  ctx.restore();
}

function powerupColor(kind: PowerupKind): string {
  switch (kind) {
    case "health": return "#7fd99a";
    case "ammo": return "#e6c07b";
    case "hull": return "#8b9bb0";
    case "weapon": return "#f07178";
    case "speed": return "#5eead4";
    case "counter": return "#3b9eff";
    default: return "#fff";
  }
}

function drawPowerup(
  ctx: CanvasRenderingContext2D, p: GameState["powerups"][0],
  sx: number, sy: number, zoom: number, time: number,
) {
  const bob = Math.sin(time * 2.2 + p.pulse) * 2.5 * zoom;
  const col = powerupColor(p.kind);
  ctx.save();
  drawDynamicShadow(ctx, { sx, sy: sy + bob, depth: 0.05, radiusX: 8 * zoom, radiusY: 4 * zoom, strength: 0.5 });
  const g = ctx.createRadialGradient(sx, sy + bob, 0, sx, sy + bob, 10 * zoom);
  g.addColorStop(0, col);
  g.addColorStop(1, "rgba(0,0,0,0)");
  ctx.fillStyle = g;
  ctx.globalAlpha = 0.85;
  ctx.beginPath();
  ctx.arc(sx, sy + bob, 7 * zoom, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = "#fff";
  ctx.lineWidth = 1.2 * zoom;
  ctx.globalAlpha = 0.7;
  ctx.stroke();
  ctx.restore();
}

function drawImpactFx(
  ctx: CanvasRenderingContext2D,
  sx: number, sy: number, zoom: number,
  life: number, maxLife: number, radius: number, color: string, kind: string,
) {
  const t = 1 - clamp(life / maxLife, 0, 1);
  const alpha = (1 - t) * (kind === "hit" || kind === "boom" ? 1 : 0.9);
  const expand =
    kind === "boom" ? 0.4 + t * 2.4
    : kind === "shock" ? 0.5 + t * 2.0
    : kind === "pickup" ? 0.4 + t * 1.8
    : 0.45 + t * 1.3;
  const rx = radius * 16 * zoom * expand;
  const ry = rx * 0.42;
  const flash = Math.max(0, 1 - t * (kind === "boom" ? 1.5 : 2.2));

  ctx.save();
  ctx.globalAlpha = alpha;
  ctx.lineCap = "round";

  if (flash > 0.05 && (kind === "hit" || kind === "shock" || kind === "boom")) {
    ctx.globalAlpha = alpha * flash * (kind === "boom" ? 0.9 : 0.65);
    ctx.fillStyle = kind === "boom" ? "#ffd080" : color;
    ctx.beginPath();
    ctx.ellipse(sx, sy, rx * (kind === "boom" ? 1.1 : 0.85), ry * (kind === "boom" ? 1.1 : 0.85), 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = `rgba(255,255,255,${flash * 0.7})`;
    ctx.beginPath();
    ctx.ellipse(sx, sy, rx * 0.3, ry * 0.3, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.globalAlpha = alpha;
  }

  if (kind === "boom") {
    for (let ring = 0; ring < 3; ring++) {
      const k = 0.5 + ring * 0.28 + t * 0.3;
      ctx.globalAlpha = alpha * (0.85 - ring * 0.2) * (1 - t * 0.5);
      ctx.strokeStyle = ring === 0 ? "#fff" : ring === 1 ? "#ffd080" : color;
      ctx.lineWidth = Math.max(1.5, (4 - ring) * zoom * (1 - t * 0.4));
      ctx.beginPath();
      ctx.ellipse(sx, sy, rx * k, ry * k, 0, 0, Math.PI * 2);
      ctx.stroke();
    }
    const rays = 12;
    for (let i = 0; i < rays; i++) {
      const a = (i / rays) * Math.PI * 2 + t * 0.7;
      const len = rx * (0.9 + (i % 3) * 0.15) * (1 + t * 0.45);
      const inner = len * (0.2 + t * 0.25);
      ctx.strokeStyle = i % 2 === 0 ? "#fff6d0" : "#ff8040";
      ctx.globalAlpha = alpha * (0.85 - t * 0.5);
      ctx.lineWidth = Math.max(1.2, (3.2 - t * 2) * zoom);
      ctx.beginPath();
      ctx.moveTo(sx + Math.cos(a) * inner, sy + Math.sin(a) * inner * 0.45);
      ctx.lineTo(sx + Math.cos(a) * len, sy + Math.sin(a) * len * 0.45);
      ctx.stroke();
    }
  } else if (kind === "hit") {
    for (let i = 0; i < 8; i++) {
      const a = (i / 8) * Math.PI * 2 + t * 0.5;
      const len = rx * (0.65 + (i % 3) * 0.2) * (1 + t * 0.35);
      const inner = len * (0.25 + t * 0.3);
      ctx.strokeStyle = i % 2 === 0 ? "#fff" : color;
      ctx.globalAlpha = alpha * (0.85 - t * 0.5);
      ctx.lineWidth = Math.max(1.2, (2.8 - t * 1.8) * zoom);
      ctx.beginPath();
      ctx.moveTo(sx + Math.cos(a) * inner, sy + Math.sin(a) * inner * 0.45);
      ctx.lineTo(sx + Math.cos(a) * len, sy + Math.sin(a) * len * 0.45);
      ctx.stroke();
    }
    ctx.globalAlpha = alpha;
    ctx.fillStyle = "#fff";
    ctx.beginPath();
    ctx.arc(sx, sy, Math.max(2, 5 * zoom * (1 - t * 0.6)), 0, Math.PI * 2);
    ctx.fill();
  } else {
    ctx.strokeStyle = color;
    ctx.lineWidth = Math.max(1.2, (kind === "shock" ? 2.6 : 1.8) * zoom * (1 - t * 0.45));
    ctx.beginPath();
    ctx.ellipse(sx, sy, rx, ry, 0, 0, Math.PI * 2);
    ctx.stroke();
    if (kind === "pickup" || kind === "spawn") {
      ctx.globalAlpha = alpha * 0.5;
      ctx.fillStyle = color;
      ctx.beginPath();
      ctx.arc(sx, sy, Math.max(1.5, 4 * zoom * (1 - t)), 0, Math.PI * 2);
      ctx.fill();
    }
  }
  ctx.restore();
}

export function renderGame(
  ctx: CanvasRenderingContext2D,
  state: GameState,
  terrain: TerrainCell[][],
  viewW: number,
  viewH: number,
  dpr: number,
  remotes?: Map<string, RemotePlayer>,
  playerName?: string,
) {
  ensureSpriteSheets();

  const cam = state.camera;
  const zoom = cam.zoom;
  const camX = cam.x;
  const camY = cam.y;
  const t = state.time;
  const q = renderQuality;
  // Softer, deterministic shake (was *10 — too violent / flicker-like)
  const shakeAmp = cam.shake > 0.02 ? cam.shake * 5.5 : 0;
  const shakeX = shakeAmp ? Math.sin(t * 47.1) * shakeAmp : 0;
  const shakeY = shakeAmp ? Math.cos(t * 39.3) * shakeAmp * 0.85 : 0;

  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

  drawParallax(ctx, {
    camX, camY, time: t, viewW, viewH, seed: state.seed, depth: state.sub.z,
  });

  ctx.save();
  ctx.translate(shakeX, shakeY);

  const layer = ensureTerrainLayer(viewW, viewH, dpr, q);
  if (terrainNeedsRebake(layer, camX, camY, zoom, state.seed)) {
    bakeTerrainLayer(layer, terrain, camX, camY, zoom, state.seed, t);
  }
  blitTerrainLayer(ctx, layer, camX, camY, zoom);

  drawNavalBase(ctx, state, camX, camY, zoom, viewW, viewH, t);

  for (const p of state.powerups) {
    const { sx, sy } = worldToScreen(p.x, p.y, 0, camX, camY, zoom, viewW, viewH);
    if (sx < -20 || sy < -20 || sx > viewW + 20 || sy > viewH + 20) continue;
    drawPowerup(ctx, p, sx, sy, zoom, t);
  }

  type Item =
    | { kind: "ship"; ship: Ship; depth: number }
    | { kind: "sub"; depth: number }
    | { kind: "remote"; id: string; r: RemotePlayer; depth: number }
    | { kind: "torp"; i: number; depth: number }
    | { kind: "dc"; i: number; depth: number }
    | { kind: "cm"; i: number; depth: number };

  const items: Item[] = [];
  items.push({ kind: "sub", depth: state.sub.y + state.sub.x * 0.01 + state.sub.z * 0.1 });
  for (const ship of state.ships) {
    if (ship.dead && ship.sinking > 0.95) continue;
    items.push({ kind: "ship", ship, depth: ship.y + ship.x * 0.01 });
  }
  if (remotes) {
    for (const [id, r] of remotes) {
      items.push({ kind: "remote", id, r, depth: r.y + r.x * 0.01 + (r.z ?? 0) * 0.1 });
    }
  }
  for (let i = 0; i < state.torpedoes.length; i++) {
    const tp = state.torpedoes[i]!;
    items.push({ kind: "torp", i, depth: tp.y + tp.x * 0.01 });
  }
  for (let i = 0; i < state.depthCharges.length; i++) {
    const dc = state.depthCharges[i]!;
    items.push({ kind: "dc", i, depth: dc.y + dc.x * 0.01 + dc.z * 0.05 });
  }
  for (let i = 0; i < state.countermeasures.length; i++) {
    const cm = state.countermeasures[i]!;
    items.push({ kind: "cm", i, depth: cm.y + cm.x * 0.01 });
  }
  items.sort((a, b) => a.depth - b.depth);

  for (const it of items) {
    if (it.kind === "ship") {
      const { sx, sy } = worldToScreen(it.ship.x, it.ship.y, it.ship.class === "sub" ? depthToWorldZ(0.35) : 0, camX, camY, zoom, viewW, viewH);
      if (sx < -50 || sy < -50 || sx > viewW + 50 || sy > viewH + 50) continue;
      drawShip(ctx, it.ship, sx, sy, zoom, state.selectedTarget === it.ship.id, t, state.debugFacing);
    } else if (it.kind === "sub") {
      const { sx, sy } = worldToScreen(state.sub.x, state.sub.y, depthToWorldZ(state.sub.z), camX, camY, zoom, viewW, viewH);
      drawSubmarine(ctx, state, sx, sy, zoom, playerName);
      if (state.sub.waypoint) {
        const wp = worldToScreen(state.sub.waypoint.x, state.sub.waypoint.y, 0, camX, camY, zoom, viewW, viewH);
        ctx.strokeStyle = "rgba(94,234,212,0.55)";
        ctx.lineWidth = Math.max(1, 1.5 * zoom);
        ctx.setLineDash([6 * zoom, 4 * zoom]);
        ctx.beginPath();
        ctx.moveTo(sx, sy);
        ctx.lineTo(wp.sx, wp.sy);
        ctx.stroke();
        ctx.setLineDash([]);
        ctx.fillStyle = "rgba(94,234,212,0.7)";
        ctx.beginPath();
        ctx.arc(wp.sx, wp.sy, 3 * zoom, 0, Math.PI * 2);
        ctx.fill();
      }
    } else if (it.kind === "remote") {
      const r = it.r;
      const { sx, sy } = worldToScreen(r.x, r.y, depthToWorldZ(r.z ?? 0), camX, camY, zoom, viewW, viewH);
      if (sx < -40 || sy < -40 || sx > viewW + 40 || sy > viewH + 40) continue;
      drawLiveSub(ctx, r.heading ?? 0, sx, sy, zoom, 1.0, 0.9, r.z ?? 0);
      if (r.name) {
        ctx.fillStyle = "rgba(160,200,255,0.85)";
        ctx.font = `${Math.max(9, 10 * zoom)}px sans-serif`;
        ctx.textAlign = "center";
        ctx.fillText(r.name, sx, sy - 24 * zoom);
      }
    } else if (it.kind === "torp") {
      const torp = state.torpedoes[it.i]!;
      const { sx, sy } = worldToScreen(torp.x, torp.y, depthToWorldZ(clamp(torp.z, 0, 1)), camX, camY, zoom, viewW, viewH);
      if (sx < -40 || sy < -40 || sx > viewW + 40 || sy > viewH + 40) continue;
      drawTorpedo(ctx, torp, sx, sy, zoom, t);
    } else if (it.kind === "dc") {
      const dc = state.depthCharges[it.i]!;
      const { sx, sy } = worldToScreen(dc.x, dc.y, depthToWorldZ(clamp(dc.z * 0.5, 0, 1)), camX, camY, zoom, viewW, viewH);
      if (sx < -40 || sy < -40 || sx > viewW + 40 || sy > viewH + 40) continue;
      drawDepthChargeVisual(ctx, sx, sy, dc.z, dc.fuse, zoom, t);
    } else if (it.kind === "cm") {
      const cm = state.countermeasures[it.i]!;
      const { sx, sy } = worldToScreen(cm.x, cm.y, 0, camX, camY, zoom, viewW, viewH);
      if (sx < -40 || sy < -40 || sx > viewW + 40 || sy > viewH + 40) continue;
      drawCountermeasure(ctx, cm, sx, sy, zoom, t);
    }
  }

  const maxP = Math.min(state.particles.length, q >= 2 ? 110 : q >= 1 ? 80 : 45);
  for (let i = state.particles.length - maxP; i < state.particles.length; i++) {
    if (i < 0) continue;
    const p = state.particles[i]!;
    const pz = depthToWorldZ(clamp(p.z, 0, 1));
    const { sx, sy } = worldToScreen(p.x, p.y, pz, camX, camY, zoom, viewW, viewH);
    if (sx < -20 || sy < -20 || sx > viewW + 20 || sy > viewH + 20) continue;
    const life = clamp(p.life / p.maxLife, 0, 1);
    ctx.globalAlpha = life;
    if (p.kind === "bubble" || p.kind === "trail") {
      ctx.strokeStyle = p.color;
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.arc(sx, sy, Math.max(0.4, p.size * zoom * (0.6 + life * 0.5)), 0, Math.PI * 2);
      ctx.stroke();
    } else if (p.kind === "wake") {
      ctx.fillStyle = p.color;
      ctx.globalAlpha = life * 0.25;
      ctx.beginPath();
      ctx.ellipse(sx, sy, Math.max(0.5, p.size * zoom), Math.max(0.3, p.size * 0.35 * zoom), 0, 0, Math.PI * 2);
      ctx.fill();
    } else if (p.kind === "flash") {
      const s = Math.max(2, p.size * zoom * (0.5 + (1 - life) * 0.8));
      const g = ctx.createRadialGradient(sx, sy, 0, sx, sy, s);
      g.addColorStop(0, "rgba(255,255,255,0.95)");
      g.addColorStop(0.35, p.color);
      g.addColorStop(1, "rgba(0,0,0,0)");
      ctx.globalAlpha = life * 0.9;
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.arc(sx, sy, s, 0, Math.PI * 2);
      ctx.fill();
    } else if (p.kind === "ember") {
      ctx.fillStyle = p.color;
      ctx.globalAlpha = life * 0.9;
      ctx.beginPath();
      ctx.arc(sx, sy, Math.max(1, p.size * zoom) * 0.55, 0, Math.PI * 2);
      ctx.fill();
    } else if (p.kind === "spark" || p.kind === "debris") {
      ctx.fillStyle = p.color;
      const s = Math.max(1, (p.kind === "spark" ? p.size : 2) * zoom);
      ctx.fillRect(sx, sy, s, s);
    } else {
      ctx.fillStyle = p.color;
      ctx.globalAlpha = life * (p.kind === "smoke" ? 0.35 : 0.5);
      ctx.beginPath();
      ctx.arc(sx, sy, Math.max(1, p.size * zoom), 0, Math.PI * 2);
      ctx.fill();
    }
  }
  ctx.globalAlpha = 1;

  for (const imp of state.impacts) {
    const { sx, sy } = worldToScreen(imp.x, imp.y, depthToWorldZ(clamp(imp.z, 0, 1)), camX, camY, zoom, viewW, viewH);
    if (sx < -60 || sy < -60 || sx > viewW + 60 || sy > viewH + 60) continue;
    drawImpactFx(ctx, sx, sy, zoom, imp.life, imp.maxLife, imp.radius, imp.color, imp.kind);
  }

  for (const f of state.floats) {
    const { sx, sy } = worldToScreen(f.x, f.y, 0.1, camX, camY, zoom, viewW, viewH);
    ctx.globalAlpha = clamp(f.life, 0, 1);
    ctx.fillStyle = f.color;
    ctx.font = `bold ${Math.max(11, 13 * zoom)}px sans-serif`;
    ctx.textAlign = "center";
    ctx.fillText(f.text, sx, sy);
  }
  ctx.globalAlpha = 1;

  drawActiveSonarRings(ctx, state, camX, camY, zoom, viewW, viewH);
  if (state.phase === "playing") {
    drawSonarContacts(ctx, state, camX, camY, zoom, viewW, viewH, t);
  }

  ctx.restore();

  const usedGL = drawWebGLWater(
    ctx, terrain, state.seed, camX, camY, zoom, viewW, viewH, dpr, t, state.sub.z, state.seaState ?? 0.5,
  );
  if (!usedGL) {
    drawWaterSurfaceFx(ctx, camX, camY, zoom, viewW, viewH, t, state.sub.z, q);
  }
  drawShoreCrashFx(ctx, terrain, camX, camY, zoom, viewW, viewH, t, state.sub.z, q);

  {
    const tod = state.timeOfDay ?? 0.5;
    const light = dayLight(tod);
    const phase = dayPhase(tod);
    if (light < 0.9) {
      const a = (1 - light) * 0.48;
      ctx.fillStyle =
        phase === "night" ? `rgba(3,8,24,${a})`
        : phase === "dusk" ? `rgba(48,18,28,${a * 0.75})`
        : phase === "dawn" ? `rgba(50,28,18,${a * 0.65})`
        : `rgba(6,14,30,${a * 0.45})`;
      ctx.fillRect(0, 0, viewW, viewH);
    }
    if (state.sub.z > 0.48 && q >= 1) {
      ctx.fillStyle = "rgba(4,28,56,0.16)";
      ctx.fillRect(0, 0, viewW, viewH);
    }
  }

  if (state.aircraft && state.aircraft.life > 0) {
    const { sx, sy } = worldToScreen(state.aircraft.x, state.aircraft.y, 0.4, camX, camY, zoom, viewW, viewH);
    if (sx > -20 && sy > -20 && sx < viewW + 20 && sy < viewH + 20) {
      ctx.save();
      ctx.translate(sx, sy);
      ctx.fillStyle = "rgba(220,230,240,0.85)";
      ctx.beginPath();
      ctx.moveTo(10 * zoom, 0);
      ctx.lineTo(-6 * zoom, 4 * zoom);
      ctx.lineTo(-4 * zoom, 0);
      ctx.lineTo(-6 * zoom, -4 * zoom);
      ctx.closePath();
      ctx.fill();
      ctx.restore();
    }
  }

  if (q >= 1) {
    const vg = 0.16;
    const edge = Math.min(viewW, viewH) * 0.14;
    const gTop = ctx.createLinearGradient(0, 0, 0, edge);
    gTop.addColorStop(0, `rgba(0,0,0,${vg})`);
    gTop.addColorStop(1, "rgba(0,0,0,0)");
    ctx.fillStyle = gTop;
    ctx.fillRect(0, 0, viewW, edge);
    const gBot = ctx.createLinearGradient(0, viewH, 0, viewH - edge);
    gBot.addColorStop(0, `rgba(0,0,0,${vg})`);
    gBot.addColorStop(1, "rgba(0,0,0,0)");
    ctx.fillStyle = gBot;
    ctx.fillRect(0, viewH - edge, viewW, edge);
  }

  if (state.debugFacing) {
    drawFacingDebugLegend(ctx, 12, viewH - 96);
  }
}
