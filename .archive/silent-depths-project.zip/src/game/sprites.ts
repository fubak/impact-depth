/**
 * Vessel art — top-down isometric plan views.
 * Hull yaws with heading; deck structures stay "on" the deck (never roll
 * onto their side the way side-profile art does when fully rotated).
 */
import {
  ART_NOSE_OFFSET,
  TILE_H,
  TILE_W,
  worldHeadingToScreen,
} from "./iso";
import type { ShipClass } from "./types";

export const FACINGS = 16;
export const FRAME_SIZE = 96;
const BAKE_SCALE = 1.2;
/** Iso foreshortening for plan-view hulls (Y squish after yaw). */
const ISO_SQUASH = 0.52;
export const ATLAS_W = FRAME_SIZE * FACINGS;
export const ATLAS_H = FRAME_SIZE;

export type ShipSheet = {
  atlas: HTMLCanvasElement;
  class: ShipClass | "sub";
  bytes: number;
};

export type FlatSprite = {
  canvas: HTMLCanvasElement;
  class: ShipClass | "sub" | "enemySub";
};

const shipSheets = new Map<ShipClass, ShipSheet>();
const flatShips = new Map<ShipClass, FlatSprite>();
let flatSub: FlatSprite | null = null;
let flatEnemySub: FlatSprite | null = null;
let subSheet: ShipSheet | null = null;
let sheetsReady = false;
let bakedOffset = NaN;
let totalAtlasBytes = 0;
let torpMk: HTMLCanvasElement | null = null;
let torpSeeker: HTMLCanvasElement | null = null;
const FLAT_SIZE = 96;

export function normAngle(a: number): number {
  const t = Math.PI * 2;
  a = a % t;
  if (a < 0) a += t;
  return a;
}

export function screenAngleToFacing(screenAngle: number): number {
  const step = (Math.PI * 2) / FACINGS;
  const a = normAngle(screenAngle);
  return Math.round(a / step) % FACINGS;
}

export function worldHeadingToFacing(worldHeading: number): number {
  return screenAngleToFacing(worldHeadingToScreen(worldHeading));
}

export function facingToScreenAngle(facing: number): number {
  return (facing / FACINGS) * Math.PI * 2;
}

// ─── Painters: plan-view, nose = +local X ──────────────────────────────────

function drawBowChevron(ctx: CanvasRenderingContext2D, sc: number, color: string) {
  ctx.fillStyle = color;
  ctx.beginPath();
  ctx.moveTo(30 * sc, 0);
  ctx.lineTo(20 * sc, -4.5 * sc);
  ctx.lineTo(22 * sc, 0);
  ctx.lineTo(20 * sc, 4.5 * sc);
  ctx.closePath();
  ctx.fill();
}

function drawPropWash(ctx: CanvasRenderingContext2D, sc: number) {
  ctx.strokeStyle = "rgba(160,210,240,0.45)";
  ctx.lineWidth = Math.max(1, 1.3 * sc);
  ctx.lineCap = "round";
  ctx.beginPath();
  ctx.moveTo(-26 * sc, -3 * sc);
  ctx.lineTo(-32 * sc, -5 * sc);
  ctx.moveTo(-26 * sc, 3 * sc);
  ctx.lineTo(-32 * sc, 5 * sc);
  ctx.moveTo(-26 * sc, 0);
  ctx.lineTo(-34 * sc, 0);
  ctx.stroke();
}

function paintShipBody(ctx: CanvasRenderingContext2D, cls: ShipClass, sc: number) {
  if (cls === "sub") {
    paintEnemySubBody(ctx, sc);
    return;
  }

  ctx.fillStyle = "rgba(0,12,28,0.28)";
  ctx.beginPath();
  ctx.ellipse(1 * sc, 3 * sc, 26 * sc, 8 * sc, 0, 0, Math.PI * 2);
  ctx.fill();

  const hull = ctx.createLinearGradient(-28 * sc, 0, 28 * sc, 0);
  if (cls === "freighter") {
    hull.addColorStop(0, "#3a4550");
    hull.addColorStop(0.35, "#6a7580");
    hull.addColorStop(0.7, "#8a929a");
    hull.addColorStop(1, "#4a5560");
  } else if (cls === "battleship") {
    hull.addColorStop(0, "#121820");
    hull.addColorStop(0.25, "#2a3540");
    hull.addColorStop(0.5, "#4a5868");
    hull.addColorStop(0.75, "#2a3540");
    hull.addColorStop(1, "#1a222c");
  } else {
    hull.addColorStop(0, "#1a2530");
    hull.addColorStop(0.3, "#3a4a58");
    hull.addColorStop(0.55, "#5a6a78");
    hull.addColorStop(0.8, "#3a4a58");
    hull.addColorStop(1, "#243038");
  }
  ctx.fillStyle = hull;
  const bow = cls === "battleship" ? 32 : 28;
  const beam = cls === "battleship" ? 9.5 : 8.5;
  ctx.beginPath();
  ctx.moveTo(bow * sc, 0);
  ctx.quadraticCurveTo(18 * sc, -beam * sc * 0.82, 4 * sc, -beam * sc);
  ctx.lineTo(-18 * sc, -(beam - 1) * sc);
  ctx.quadraticCurveTo(-bow * sc, -4 * sc, -bow * sc, 0);
  ctx.quadraticCurveTo(-bow * sc, 4 * sc, -18 * sc, (beam - 1) * sc);
  ctx.lineTo(4 * sc, beam * sc);
  ctx.quadraticCurveTo(18 * sc, beam * sc * 0.82, bow * sc, 0);
  ctx.closePath();
  ctx.fill();

  ctx.strokeStyle = "rgba(200,220,240,0.35)";
  ctx.lineWidth = Math.max(1, 1.2 * sc);
  ctx.stroke();

  ctx.fillStyle = cls === "freighter" ? "rgba(154,138,112,0.85)" : "rgba(55,70,82,0.9)";
  ctx.beginPath();
  ctx.ellipse(-1 * sc, 0, 18 * sc, 4.2 * sc, 0, 0, Math.PI * 2);
  ctx.fill();

  ctx.strokeStyle = "rgba(255,255,255,0.12)";
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(-20 * sc, 0);
  ctx.lineTo(22 * sc, 0);
  ctx.stroke();

  if (cls === "freighter") {
    ctx.fillStyle = "#5a5040";
    ctx.fillRect(-16 * sc, -3.2 * sc, 7 * sc, 6.4 * sc);
    ctx.fillRect(-6 * sc, -3.2 * sc, 7 * sc, 6.4 * sc);
    ctx.fillRect(4 * sc, -3.2 * sc, 6 * sc, 6.4 * sc);
    ctx.fillStyle = "#c8c0b0";
    ctx.fillRect(-4 * sc, -5.5 * sc, 12 * sc, 11 * sc);
    ctx.fillStyle = "#2a3038";
    ctx.fillRect(2 * sc, -3 * sc, 4 * sc, 6 * sc);
    ctx.fillStyle = "#1a2030";
    ctx.beginPath();
    ctx.arc(0, 0, 2.2 * sc, 0, Math.PI * 2);
    ctx.fill();
  } else if (cls === "battleship") {
    // Superstructure + dual main batteries (depth-charge racks aft)
    ctx.fillStyle = "#3a4654";
    ctx.fillRect(-10 * sc, -5.5 * sc, 16 * sc, 11 * sc);
    ctx.fillStyle = "#1e2834";
    ctx.fillRect(-4 * sc, -3 * sc, 7 * sc, 6 * sc);
    // Forward turret
    ctx.fillStyle = "#c45c3e";
    ctx.fillRect(10 * sc, -2.2 * sc, 10 * sc, 4.4 * sc);
    ctx.fillStyle = "#2a3038";
    ctx.beginPath();
    ctx.arc(12 * sc, 0, 3 * sc, 0, Math.PI * 2);
    ctx.fill();
    // Aft turret
    ctx.fillStyle = "#c45c3e";
    ctx.fillRect(-20 * sc, -2 * sc, 8 * sc, 4 * sc);
    ctx.fillStyle = "#2a3038";
    ctx.beginPath();
    ctx.arc(-16 * sc, 0, 2.6 * sc, 0, Math.PI * 2);
    ctx.fill();
    // Depth charge racks (stern)
    ctx.fillStyle = "#6a5040";
    for (let i = 0; i < 4; i++) {
      ctx.fillRect((-26 - i * 1.6) * sc, -3.5 * sc, 1.3 * sc, 7 * sc);
    }
    ctx.fillStyle = "#8a7060";
    ctx.fillRect(-28 * sc, -2 * sc, 6 * sc, 4 * sc);
  } else if (cls === "destroyer" || cls === "cruiser") {
    ctx.fillStyle = "#5a6875";
    ctx.fillRect(-8 * sc, -4.5 * sc, 12 * sc, 9 * sc);
    ctx.fillStyle = "#2a3340";
    ctx.fillRect(-4 * sc, -2.5 * sc, 5 * sc, 5 * sc);
    ctx.fillStyle = "#1a2030";
    ctx.beginPath();
    ctx.arc(12 * sc, 0, 2.4 * sc, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "#c45c3e";
    ctx.fillRect(6 * sc, -1.5 * sc, 8 * sc, 3 * sc);
    if (cls === "cruiser") {
      ctx.fillStyle = "#4a5560";
      ctx.fillRect(-16 * sc, -3 * sc, 6 * sc, 6 * sc);
      ctx.fillStyle = "#c45c3e";
      ctx.fillRect(-14 * sc, -1.2 * sc, 5 * sc, 2.4 * sc);
    }
    ctx.fillStyle = "#2a3038";
    for (let i = 0; i < 3; i++) {
      ctx.beginPath();
      ctx.arc(-20 * sc - i * 2.2 * sc, (i % 2 === 0 ? -2.5 : 2.5) * sc, 1.4 * sc, 0, Math.PI * 2);
      ctx.fill();
    }
  } else {
    ctx.fillStyle = "#4a5560";
    ctx.fillRect(-4 * sc, -3 * sc, 8 * sc, 6 * sc);
    ctx.fillStyle = "#1a2030";
    ctx.beginPath();
    ctx.arc(10 * sc, 0, 1.8 * sc, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "#2a3038";
    ctx.beginPath();
    ctx.arc(-18 * sc, -2 * sc, 1.2 * sc, 0, Math.PI * 2);
    ctx.fill();
    ctx.beginPath();
    ctx.arc(-18 * sc, 2 * sc, 1.2 * sc, 0, Math.PI * 2);
    ctx.fill();
  }

  drawBowChevron(
    ctx,
    sc,
    cls === "freighter" ? "#e8d080" : cls === "battleship" ? "#ffb060" : "#ffd060",
  );
  drawPropWash(ctx, sc);
}

function paintSubBody(ctx: CanvasRenderingContext2D, sc: number) {
  ctx.fillStyle = "rgba(0,20,40,0.3)";
  ctx.beginPath();
  ctx.ellipse(0, 2.5 * sc, 22 * sc, 6 * sc, 0, 0, Math.PI * 2);
  ctx.fill();

  const hull = ctx.createLinearGradient(-24 * sc, 0, 24 * sc, 0);
  hull.addColorStop(0, "#0a2838");
  hull.addColorStop(0.3, "#1a4a5a");
  hull.addColorStop(0.55, "#2a6a78");
  hull.addColorStop(0.85, "#1a4a5a");
  hull.addColorStop(1, "#0c3040");
  ctx.fillStyle = hull;
  ctx.beginPath();
  ctx.moveTo(24 * sc, 0);
  ctx.quadraticCurveTo(14 * sc, -5.5 * sc, 0 * sc, -6 * sc);
  ctx.lineTo(-16 * sc, -5 * sc);
  ctx.quadraticCurveTo(-24 * sc, -2.5 * sc, -24 * sc, 0);
  ctx.quadraticCurveTo(-24 * sc, 2.5 * sc, -16 * sc, 5 * sc);
  ctx.lineTo(0 * sc, 6 * sc);
  ctx.quadraticCurveTo(14 * sc, 5.5 * sc, 24 * sc, 0);
  ctx.closePath();
  ctx.fill();

  ctx.strokeStyle = "rgba(140,210,230,0.35)";
  ctx.lineWidth = Math.max(1, 1.1 * sc);
  ctx.stroke();

  ctx.fillStyle = "#1a3a48";
  ctx.beginPath();
  ctx.moveTo(-2 * sc, -2 * sc);
  ctx.lineTo(6 * sc, -2 * sc);
  ctx.lineTo(5 * sc, -7 * sc);
  ctx.lineTo(-1 * sc, -7 * sc);
  ctx.closePath();
  ctx.fill();
  ctx.fillStyle = "#0a2030";
  ctx.fillRect(1 * sc, -9 * sc, 2.2 * sc, 2.5 * sc);

  ctx.strokeStyle = "rgba(94,234,212,0.25)";
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(-18 * sc, 0);
  ctx.lineTo(18 * sc, 0);
  ctx.stroke();

  drawBowChevron(ctx, sc * 0.9, "#5eead4");
}

/** Axis U-boat — larger hunter-killer silhouette, warmer/darker than allied teal. */
function paintEnemySubBody(ctx: CanvasRenderingContext2D, sc: number) {
  // Scale up local drawing — U-boats read much bigger than the player boat
  sc *= 1.35;

  ctx.fillStyle = "rgba(20,8,8,0.38)";
  ctx.beginPath();
  ctx.ellipse(0, 3.2 * sc, 28 * sc, 7.5 * sc, 0, 0, Math.PI * 2);
  ctx.fill();

  const hull = ctx.createLinearGradient(-30 * sc, 0, 30 * sc, 0);
  hull.addColorStop(0, "#1a1410");
  hull.addColorStop(0.3, "#2a2420");
  hull.addColorStop(0.55, "#3a3428");
  hull.addColorStop(0.85, "#2a2420");
  hull.addColorStop(1, "#181410");
  ctx.fillStyle = hull;
  ctx.beginPath();
  ctx.moveTo(30 * sc, 0);
  ctx.quadraticCurveTo(16 * sc, -7 * sc, 0 * sc, -7.5 * sc);
  ctx.lineTo(-20 * sc, -6.2 * sc);
  ctx.quadraticCurveTo(-30 * sc, -3 * sc, -30 * sc, 0);
  ctx.quadraticCurveTo(-30 * sc, 3 * sc, -20 * sc, 6.2 * sc);
  ctx.lineTo(0 * sc, 7.5 * sc);
  ctx.quadraticCurveTo(16 * sc, 7 * sc, 30 * sc, 0);
  ctx.closePath();
  ctx.fill();

  ctx.strokeStyle = "rgba(200,140,100,0.4)";
  ctx.lineWidth = Math.max(1, 1.25 * sc);
  ctx.stroke();

  // Conning tower
  ctx.fillStyle = "#2a2018";
  ctx.beginPath();
  ctx.moveTo(-3 * sc, -2.5 * sc);
  ctx.lineTo(8 * sc, -2.5 * sc);
  ctx.lineTo(7 * sc, -9 * sc);
  ctx.lineTo(-2 * sc, -9 * sc);
  ctx.closePath();
  ctx.fill();
  ctx.fillStyle = "#1a1008";
  ctx.fillRect(1.5 * sc, -12 * sc, 2.6 * sc, 3.2 * sc);

  // Deck gun hint
  ctx.strokeStyle = "rgba(180,150,120,0.55)";
  ctx.lineWidth = 1.2 * sc;
  ctx.beginPath();
  ctx.moveTo(10 * sc, -1 * sc);
  ctx.lineTo(16 * sc, -3 * sc);
  ctx.stroke();

  // Red ID band
  ctx.strokeStyle = "rgba(220,80,60,0.6)";
  ctx.lineWidth = 1.6 * sc;
  ctx.beginPath();
  ctx.moveTo(-8 * sc, 0);
  ctx.lineTo(8 * sc, 0);
  ctx.stroke();

  drawBowChevron(ctx, sc * 0.95, "#ff8060");
}

function paintTorpedoBody(
  ctx: CanvasRenderingContext2D,
  sc: number,
  seeking: boolean,
  time = 0,
) {
  const accent = seeking ? "#5eead4" : "#ff9f43";
  const bodyHi = seeking ? "#ecfdf5" : "#fff7ed";

  ctx.strokeStyle = seeking ? "rgba(94,234,212,0.55)" : "rgba(255,176,112,0.55)";
  ctx.lineWidth = Math.max(2, 3 * sc);
  ctx.lineCap = "round";
  ctx.beginPath();
  ctx.moveTo(-10 * sc, 0);
  ctx.lineTo(-24 * sc, Math.sin(time * 18) * 1.2 * sc);
  ctx.stroke();

  const body = ctx.createLinearGradient(-16 * sc, 0, 18 * sc, 0);
  body.addColorStop(0, "#1e293b");
  body.addColorStop(0.3, "#94a3b8");
  body.addColorStop(0.55, bodyHi);
  body.addColorStop(0.85, accent);
  body.addColorStop(1, "#fff");
  ctx.fillStyle = body;
  ctx.beginPath();
  ctx.ellipse(0, 0, 16 * sc, 4.2 * sc, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = accent;
  ctx.lineWidth = Math.max(1.2, 1.8 * sc);
  ctx.stroke();

  ctx.fillStyle = accent;
  ctx.beginPath();
  ctx.moveTo(16 * sc, 0);
  ctx.lineTo(9 * sc, -4 * sc);
  ctx.lineTo(9 * sc, 4 * sc);
  ctx.closePath();
  ctx.fill();

  ctx.fillStyle = "#0f172a";
  ctx.beginPath();
  ctx.moveTo(-12 * sc, 0);
  ctx.lineTo(-18 * sc, -5 * sc);
  ctx.lineTo(-10 * sc, 0);
  ctx.lineTo(-18 * sc, 5 * sc);
  ctx.closePath();
  ctx.fill();
}

function bakeFlat(
  paint: (ctx: CanvasRenderingContext2D, sc: number) => void,
  tag: ShipClass | "sub" | "enemySub",
): FlatSprite {
  const canvas = document.createElement("canvas");
  canvas.width = FLAT_SIZE;
  canvas.height = FLAT_SIZE;
  const ctx = canvas.getContext("2d", { alpha: true })!;
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = "high";
  ctx.translate(FLAT_SIZE / 2, FLAT_SIZE / 2);
  paint(ctx, BAKE_SCALE);
  return { canvas, class: tag };
}

function bakeFacingAtlas(
  paint: (ctx: CanvasRenderingContext2D, sc: number) => void,
  tag: ShipClass | "sub",
): ShipSheet {
  const atlas = document.createElement("canvas");
  atlas.width = ATLAS_W;
  atlas.height = ATLAS_H;
  const ctx = atlas.getContext("2d", { alpha: true })!;
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = "high";

  for (let i = 0; i < FACINGS; i++) {
    const ang = facingToScreenAngle(i);
    const ox = i * FRAME_SIZE + FRAME_SIZE / 2;
    const oy = FRAME_SIZE / 2;
    ctx.save();
    ctx.translate(ox, oy);
    ctx.rotate(ang);
    ctx.scale(1, ISO_SQUASH);
    paint(ctx, BAKE_SCALE);
    ctx.restore();
  }

  return { atlas, class: tag, bytes: ATLAS_W * ATLAS_H * 4 };
}

function bakeTorp(seeking: boolean): HTMLCanvasElement {
  const c = document.createElement("canvas");
  c.width = 64;
  c.height = 32;
  const ctx = c.getContext("2d", { alpha: true })!;
  ctx.translate(32, 16);
  paintTorpedoBody(ctx, 0.9, seeking, 0);
  return c;
}

const CLASSES: ShipClass[] = [
  "patrol",
  "destroyer",
  "freighter",
  "cruiser",
  "battleship",
  "sub",
];

export function ensureSpriteSheets(): void {
  if (typeof document === "undefined") return;
  const ART_VER = 10;
  if (sheetsReady && bakedOffset === ART_NOSE_OFFSET + ART_VER) return;
  shipSheets.clear();
  flatShips.clear();
  totalAtlasBytes = 0;
  for (const cls of CLASSES) {
    const flat = bakeFlat((c, sc) => paintShipBody(c, cls, sc), cls);
    flatShips.set(cls, flat);
    totalAtlasBytes += FLAT_SIZE * FLAT_SIZE * 4;
  }
  flatSub = bakeFlat(paintSubBody, "sub");
  flatEnemySub = bakeFlat(paintEnemySubBody, "enemySub");
  totalAtlasBytes += FLAT_SIZE * FLAT_SIZE * 4 * 2;
  torpMk = bakeTorp(false);
  torpSeeker = bakeTorp(true);
  totalAtlasBytes += 64 * 32 * 4 * 2;
  bakedOffset = ART_NOSE_OFFSET + ART_VER;
  sheetsReady = true;
}

function ensureDebugAtlas() {
  if (shipSheets.size > 0) return;
  for (const cls of CLASSES) {
    const sheet = bakeFacingAtlas((c, sc) => paintShipBody(c, cls, sc), cls);
    shipSheets.set(cls, sheet);
    totalAtlasBytes += sheet.bytes;
  }
  subSheet = bakeFacingAtlas(paintSubBody, "sub");
  totalAtlasBytes += subSheet.bytes;
}

export function getShipSheet(cls: ShipClass): ShipSheet | null {
  ensureSpriteSheets();
  ensureDebugAtlas();
  return shipSheets.get(cls) ?? null;
}

export function getSubSheet(): ShipSheet | null {
  ensureSpriteSheets();
  ensureDebugAtlas();
  return subSheet;
}

export function getSpriteMemoryStats() {
  ensureSpriteSheets();
  return {
    classes: flatShips.size + (flatSub ? 1 : 0),
    facings: FACINGS,
    frameSize: FRAME_SIZE,
    atlasBytes: totalAtlasBytes,
    atlasKB: Math.round(totalAtlasBytes / 1024),
    noseOffset: ART_NOSE_OFFSET,
  };
}

/**
 * Continuous plan-view: one drawImage of a prebaked flat hull, rotated + iso-squashed.
 * Correct at every angle; ~10–50× cheaper than re-stroking paths each frame.
 */
export function drawPlanVessel(
  dest: CanvasRenderingContext2D,
  paint: (ctx: CanvasRenderingContext2D, sc: number) => void,
  worldHeading: number,
  sx: number,
  sy: number,
  zoom: number,
  baseScale: number,
  alpha = 1,
  depth = 0,
) {
  const screenAng = worldHeadingToScreen(worldHeading);
  const squash = ISO_SQUASH * (1 - depth * 0.1);
  const sc = BAKE_SCALE * 0.72 * zoom * baseScale;
  dest.save();
  dest.globalAlpha = alpha;
  dest.translate(sx, sy);
  dest.rotate(screenAng);
  dest.scale(1, squash);
  paint(dest, sc);
  dest.restore();
}

function drawFlatSprite(
  dest: CanvasRenderingContext2D,
  flat: FlatSprite,
  worldHeading: number,
  sx: number,
  sy: number,
  zoom: number,
  baseScale: number,
  alpha: number,
  depth: number,
) {
  const screenAng = worldHeadingToScreen(worldHeading);
  const squash = ISO_SQUASH * (1 - depth * 0.1);
  const size = FLAT_SIZE * 0.72 * zoom * baseScale;
  dest.save();
  dest.globalAlpha = alpha;
  dest.imageSmoothingEnabled = true;
  dest.imageSmoothingQuality = "medium";
  dest.translate(sx, sy);
  dest.rotate(screenAng);
  dest.scale(1, squash);
  dest.drawImage(flat.canvas, -size / 2, -size / 2, size, size);
  dest.restore();
}

export function drawLiveShip(
  dest: CanvasRenderingContext2D,
  cls: ShipClass,
  worldHeading: number,
  sx: number,
  sy: number,
  zoom: number,
  baseScale: number,
  alpha = 1,
  depth = 0,
) {
  ensureSpriteSheets();
  if (cls === "sub") {
    const flat = flatEnemySub ?? flatShips.get("sub");
    if (flat) {
      drawFlatSprite(dest, flat, worldHeading, sx, sy, zoom, baseScale, alpha, depth || 0.35);
      return;
    }
  }
  const flat = flatShips.get(cls);
  if (flat) {
    drawFlatSprite(dest, flat, worldHeading, sx, sy, zoom, baseScale, alpha, depth);
    return;
  }
  drawPlanVessel(
    dest,
    (c, sc) => paintShipBody(c, cls, sc),
    worldHeading,
    sx,
    sy,
    zoom,
    baseScale,
    alpha,
    depth,
  );
}

export function drawLiveSub(
  dest: CanvasRenderingContext2D,
  worldHeading: number,
  sx: number,
  sy: number,
  zoom: number,
  baseScale: number,
  alpha = 1,
  depth = 0,
) {
  ensureSpriteSheets();
  if (flatSub) {
    drawFlatSprite(dest, flatSub, worldHeading, sx, sy, zoom, baseScale, alpha, depth);
    return;
  }
  drawPlanVessel(dest, paintSubBody, worldHeading, sx, sy, zoom, baseScale, alpha, depth);
}

export function drawFacingFrame(
  ctx: CanvasRenderingContext2D,
  sheet: ShipSheet,
  facing: number,
  sx: number,
  sy: number,
  zoom: number,
  baseScale: number,
  alpha = 1,
) {
  const f = ((facing % FACINGS) + FACINGS) % FACINGS;
  const size = FRAME_SIZE * 0.72 * zoom * baseScale;
  ctx.save();
  ctx.globalAlpha = alpha;
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = "medium";
  ctx.drawImage(
    sheet.atlas,
    f * FRAME_SIZE,
    0,
    FRAME_SIZE,
    FRAME_SIZE,
    sx - size / 2,
    sy - size / 2,
    size,
    size,
  );
  ctx.restore();
}

/** Fast torpedo — prebaked body + rotate (no per-frame path paint). */
export function drawFastTorpedo(
  ctx: CanvasRenderingContext2D,
  sx: number,
  sy: number,
  rot: number,
  zoom: number,
  seeking: boolean,
  _time: number,
  alpha = 1,
) {
  ensureSpriteSheets();
  const img = seeking ? torpSeeker : torpMk;
  const w = 36 * zoom;
  const h = 14 * zoom;
  ctx.save();
  ctx.globalAlpha = alpha;
  ctx.translate(sx, sy);
  ctx.rotate(rot);
  if (img) {
    ctx.drawImage(img, -w / 2, -h / 2, w, h);
  } else {
    ctx.fillStyle = seeking ? "#5eead4" : "#ff9f43";
    ctx.beginPath();
    ctx.ellipse(0, 0, w / 2, h / 3, 0, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();
}

export const SUN = {
  dirX: 0.55,
  dirY: 0.85,
  elev: 0.55,
};

export type ShadowParams = {
  sx: number;
  sy: number;
  depth: number;
  radiusX: number;
  radiusY: number;
  strength?: number;
  soft?: boolean;
};

export function drawDynamicShadow(ctx: CanvasRenderingContext2D, p: ShadowParams) {
  const depth = Math.max(0, Math.min(1, p.depth));
  const strength = p.strength ?? 1;
  const cast = (0.4 + (1 - SUN.elev) * 0.95 + depth * 1.55) * strength;
  const ox = SUN.dirX * cast * p.radiusX * 0.6;
  const oy = SUN.dirY * cast * p.radiusY * 0.8 + depth * p.radiusY * 0.45;
  const rx = p.radiusX * (1 + depth * 0.75);
  const ry = p.radiusY * (0.55 + depth * 0.65);
  // Deeper units cast softer, more diffuse umbra on the surface plane
  const alpha = (0.48 - depth * 0.1) * strength;
  const cx = p.sx + ox;
  const cy = p.sy + oy;

  ctx.save();
  // Soft outer umbra
  const g = ctx.createRadialGradient(cx, cy, 0, cx, cy, Math.max(rx, ry) * 1.2);
  g.addColorStop(0, `rgba(0,6,18,${alpha})`);
  g.addColorStop(0.55, `rgba(0,8,22,${alpha * 0.55})`);
  g.addColorStop(1, "rgba(0,8,22,0)");
  ctx.fillStyle = g;
  ctx.beginPath();
  ctx.ellipse(cx, cy, rx * 1.25, ry * 1.25, 0.12, 0, Math.PI * 2);
  ctx.fill();
  // Core shadow
  ctx.fillStyle = `rgba(0,4,14,${alpha * 0.75})`;
  ctx.beginPath();
  ctx.ellipse(cx, cy, rx * 0.72, ry * 0.72, 0.12, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

export function depthHaze(depth: number) {
  const d = Math.max(0, Math.min(1, depth));
  return { r: 4 + d * 6, g: 18 + d * 20, b: 40 + d * 35, a: d * 0.42 };
}

export function drawDepthVeil(
  ctx: CanvasRenderingContext2D,
  sx: number,
  sy: number,
  depth: number,
  zoom: number,
) {
  if (depth < 0.08) return;
  const h = depthHaze(depth);
  const r = (32 + depth * 48) * zoom;
  const g = ctx.createRadialGradient(sx, sy, 0, sx, sy, r);
  g.addColorStop(0, `rgba(${h.r},${h.g},${h.b},${h.a * 1.15})`);
  g.addColorStop(0.4, `rgba(${h.r},${h.g},${h.b},${h.a * 0.65})`);
  g.addColorStop(0.75, `rgba(${h.r},${h.g + 8},${h.b + 12},${h.a * 0.28})`);
  g.addColorStop(1, `rgba(${h.r},${h.g},${h.b},0)`);
  ctx.fillStyle = g;
  ctx.beginPath();
  ctx.ellipse(sx, sy, r, r * 0.52, 0, 0, Math.PI * 2);
  ctx.fill();
  // Surface silhouette ring — object is under the water plane
  if (depth > 0.15) {
    ctx.strokeStyle = `rgba(120,180,220,${0.12 + depth * 0.12})`;
    ctx.lineWidth = Math.max(1, 1.2 * zoom);
    ctx.beginPath();
    ctx.ellipse(sx, sy + depth * 6 * zoom, (18 + depth * 8) * zoom, (7 + depth * 3) * zoom, 0, 0, Math.PI * 2);
    ctx.stroke();
  }
}

export function drawFacingDebug(
  ctx: CanvasRenderingContext2D,
  sx: number,
  sy: number,
  worldHeading: number,
  zoom: number,
  label: string,
) {
  const screenAng = worldHeadingToScreen(worldHeading);
  const facing = worldHeadingToFacing(worldHeading);
  const binAng = facingToScreenAngle(facing);
  const len = 40 * zoom;

  const drawRay = (ang: number, color: string, width: number, dash?: number[]) => {
    ctx.save();
    ctx.strokeStyle = color;
    ctx.fillStyle = color;
    ctx.lineWidth = width;
    if (dash) ctx.setLineDash(dash);
    ctx.beginPath();
    ctx.moveTo(sx, sy);
    ctx.lineTo(sx + Math.cos(ang) * len, sy + Math.sin(ang) * len);
    ctx.stroke();
    const ax = sx + Math.cos(ang) * len;
    const ay = sy + Math.sin(ang) * len;
    ctx.beginPath();
    ctx.moveTo(ax, ay);
    ctx.lineTo(ax - Math.cos(ang - 0.4) * 8 * zoom, ay - Math.sin(ang - 0.4) * 8 * zoom);
    ctx.lineTo(ax - Math.cos(ang + 0.4) * 8 * zoom, ay - Math.sin(ang + 0.4) * 8 * zoom);
    ctx.closePath();
    ctx.fill();
    ctx.restore();
  };

  drawRay(screenAng, "rgba(80,255,140,0.95)", 2.4);
  drawRay(binAng, "rgba(80,220,255,0.8)", 1.5, [4, 3]);

  const deg = ((worldHeading * 180) / Math.PI + 360) % 360;
  ctx.save();
  ctx.font = `600 ${Math.max(9, 10 * zoom)}px ui-monospace, monospace`;
  ctx.lineWidth = 3;
  ctx.strokeStyle = "rgba(0,0,0,0.65)";
  const text = `${label} ${deg.toFixed(0)}° f${facing}`;
  ctx.strokeText(text, sx + 10 * zoom, sy - 12 * zoom);
  ctx.fillStyle = "#e2e8f0";
  ctx.fillText(text, sx + 10 * zoom, sy - 12 * zoom);
  ctx.restore();
}

export function drawFacingDebugLegend(ctx: CanvasRenderingContext2D, x: number, y: number) {
  const mem = getSpriteMemoryStats();
  ctx.save();
  ctx.font = "600 11px ui-sans-serif, system-ui, sans-serif";
  ctx.fillStyle = "rgba(8,16,28,0.78)";
  ctx.fillRect(x, y, 260, 78);
  ctx.strokeStyle = "rgba(120,160,200,0.4)";
  ctx.strokeRect(x, y, 260, 78);
  ctx.fillStyle = "#94a3b8";
  ctx.fillText("Facing debug (D) · green = motion forward", x + 10, y + 16);
  ctx.fillStyle = "#50ff8c";
  ctx.fillText("─ projected velocity / bow must match", x + 10, y + 34);
  ctx.fillStyle = "#50dcff";
  ctx.fillText("─ 16-dir bin center", x + 10, y + 50);
  ctx.fillStyle = "#cbd5e1";
  ctx.fillText(`atlas ~${mem.atlasKB}KB · plan-view art`, x + 10, y + 66);
  ctx.restore();
}

export function paintLiveShip(ctx: CanvasRenderingContext2D, cls: ShipClass, sc: number) {
  paintShipBody(ctx, cls, sc);
}

export function paintLiveSub(ctx: CanvasRenderingContext2D, sc: number) {
  paintSubBody(ctx, sc);
}

export function paintLiveTorpedo(
  ctx: CanvasRenderingContext2D,
  sc: number,
  seeking: boolean,
  time: number,
) {
  paintTorpedoBody(ctx, sc, seeking, time);
}

export const ISO_TILE = { w: TILE_W, h: TILE_H };
