/**
 * Player combat autopilot — pick a target + tactic, AI drives helm & tubes.
 *
 * Phases per tactic (simplified doctrine):
 *  ambush   — silent deep approach → peri beam shot → deep evade
 *  stalk    — quiet trail at range → fire when aspect good → re-stalk
 *  intercept— aggressive close → fire → break contact
 *  evade    — away from threats, deep + silent, CM if pressured
 *  exfil    — route to FOB, charge if needed, silent near escorts
 */
import { angleDiff, clamp, dist } from "./iso";
import {
  findPath,
  followPath,
  lineClear,
  makeSubClear,
  steerAvoid,
} from "./pathfinding";
import { THERMOCLINE } from "./tactics";
import type { GameState, Ship, TerrainCell, Vec2 } from "./types";
import { WORLD_SIZE, isShipNavigable } from "./world";

export type AutopilotTactic =
  | "manual"
  | "ambush"
  | "stalk"
  | "intercept"
  | "evade"
  | "exfil";

export type AutopilotPhase =
  | "idle"
  | "approach"
  | "setup"
  | "attack"
  | "breakaway"
  | "hold"
  | "dock";

export interface AutopilotState {
  enabled: boolean;
  tactic: AutopilotTactic;
  /** Override selectedTarget if set; else uses selectedTarget. */
  targetId: number | null;
  phase: AutopilotPhase;
  phaseTimer: number;
  shotTimer: number;
  repathTimer: number;
  path: Vec2[];
  status: string;
}

export function createAutopilot(): AutopilotState {
  return {
    enabled: false,
    tactic: "manual",
    targetId: null,
    phase: "idle",
    phaseTimer: 0,
    shotTimer: 0,
    repathTimer: 0,
    path: [],
    status: "Manual helm",
  };
}

function findShip(state: GameState, id: number | null): Ship | null {
  if (id == null) return null;
  return state.ships.find((s) => s.id === id && !s.dead && s.sinking === 0) ?? null;
}

function nearestThreat(state: GameState): Ship | null {
  let best: Ship | null = null;
  let bestD = Infinity;
  for (const s of state.ships) {
    if (s.dead || s.sinking > 0) continue;
    if (s.class === "freighter") continue;
    const d = dist(s.x, s.y, state.sub.x, state.sub.y);
    const score = d - (s.alert > 0.5 ? 4 : 0);
    if (score < bestD) {
      bestD = score;
      best = s;
    }
  }
  return best;
}

/** Point offset on target's beam for a good shot. */
function beamAimPoint(ship: Ship, preferPort: boolean): Vec2 {
  const side = preferPort ? -1 : 1;
  const bx = Math.cos(ship.heading + (Math.PI / 2) * side);
  const by = Math.sin(ship.heading + (Math.PI / 2) * side);
  // Stand off ~5–7 tiles on the beam
  const standoff = 5.5;
  // Slightly ahead of beam for lead
  const ahead = 1.2;
  return {
    x: ship.x + bx * standoff + Math.cos(ship.heading) * ahead,
    y: ship.y + by * standoff + Math.sin(ship.heading) * ahead,
  };
}

function stalkPoint(ship: Ship, sub: { x: number; y: number }): Vec2 {
  // Stay ~9–12u behind quarter
  const back = ship.heading + Math.PI + 0.4 * (sub.x > ship.x ? 1 : -1);
  return {
    x: ship.x + Math.cos(back) * 10,
    y: ship.y + Math.sin(back) * 10,
  };
}

function interceptPoint(ship: Ship): Vec2 {
  // Aim ahead of track
  const lead = Math.max(2, ship.speed * 2.5);
  return {
    x: ship.x + Math.cos(ship.heading) * lead,
    y: ship.y + Math.sin(ship.heading) * lead,
  };
}

function aspectQuality(subHeading: number, ship: Ship, sub: { x: number; y: number }): number {
  const toShip = Math.atan2(ship.y - sub.y, ship.x - sub.x);
  const rel = Math.abs(angleDiff(ship.heading, toShip + Math.PI));
  // beam = PI/2
  return 1 - Math.abs(rel - Math.PI / 2) / (Math.PI / 2);
}

function setDepth(state: GameState, z: number) {
  state.sub.targetDepth = clamp(z, 0.05, 0.92);
}

function setSpeed(state: GameState, s: number) {
  const max = Math.max(0.2, state.sub.maxSpeed || 2.4);
  // Sticky order so HUD speed band stays selected while AI drives
  state.sub.speedOrder = clamp(s / max, 0, 1);
  let v = state.sub.speedOrder * max;
  if (state.sub.silentRunning) v = Math.min(v, max * 0.28);
  if ((state.sub.sysPropulsion || 1) < 0.95) {
    v = Math.min(v, max * (0.45 + state.sub.sysPropulsion * 0.55));
  }
  state.sub.targetSpeed = v;
}

function setSilent(state: GameState, on: boolean) {
  state.sub.silentRunning = on;
  if (on) {
    state.sub.scopeUp = false;
    state.sub.snorkel = false;
  }
  // Re-apply caps from speedOrder without wiping the band
  const max = Math.max(0.2, state.sub.maxSpeed || 2.4);
  let v = clamp(state.sub.speedOrder ?? 0, 0, 1) * max;
  if (on) v = Math.min(v, max * 0.28);
  state.sub.targetSpeed = v;
}

function setScope(state: GameState, on: boolean) {
  if (on && state.sub.z > 0.45) {
    setDepth(state, 0.28);
    return;
  }
  if (on && state.sub.z < 0.1) return;
  state.sub.scopeUp = on;
  if (on) state.sub.snorkel = false;
}

function steerTo(
  state: GameState,
  terrain: TerrainCell[][],
  goal: Vec2,
  dt: number,
  ap: AutopilotState,
) {
  const boat = state.sub;
  const open = makeSubClear(terrain, boat.z);
  const g = {
    x: clamp(goal.x, 2, WORLD_SIZE - 3),
    y: clamp(goal.y, 2, WORLD_SIZE - 3),
  };
  // Snap goal if on land
  if (!open(g.x, g.y)) {
    for (let r = 1; r <= 8; r++) {
      let found = false;
      for (let i = 0; i < 12; i++) {
        const a = (i / 12) * Math.PI * 2;
        const nx = g.x + Math.cos(a) * r;
        const ny = g.y + Math.sin(a) * r;
        if (open(nx, ny)) {
          g.x = nx;
          g.y = ny;
          found = true;
          break;
        }
      }
      if (found) break;
    }
  }

  ap.repathTimer -= dt;
  const need =
    ap.path.length === 0 ||
    !lineClear(boat.x, boat.y, ap.path[0]!.x, ap.path[0]!.y, open, 0.75);
  if (need && ap.repathTimer <= 0) {
    ap.path = findPath({ x: boat.x, y: boat.y }, g, open, 700);
    ap.repathTimer = 1.0;
  }
  const fl = followPath(boat.x, boat.y, ap.path, 0.95);
  ap.path = fl.path;
  let desired =
    fl.heading != null
      ? fl.heading
      : Math.atan2(g.y - boat.y, g.x - boat.x);
  desired = steerAvoid(boat.x, boat.y, desired, 2.4, open, { rays: 11 });
  const ad = angleDiff(boat.heading, desired);
  const turn = 1.65 * (boat.z > 0.6 ? 0.75 : 1);
  boat.heading += clamp(ad, -turn * dt, turn * dt);
  // Also set waypoint so existing movement integrates
  boat.waypoint = { x: g.x, y: g.y };
}

function tryFire(
  state: GameState,
  ship: Ship,
  opts: { seeking?: boolean; spread?: boolean },
  fireWeapon: (state: GameState, x: number, y: number) => void,
): boolean {
  const boat = state.sub;
  if (boat.z < 0.1 || boat.z > 0.75) return false;
  if (opts.seeking) {
    if (boat.seekers <= 0 || boat.reloadMk18 > 0) return false;
    state.weapon = "seeker";
  } else {
    if (boat.torpedoes <= 0 || boat.reloadMk14 > 0) return false;
    state.weapon = "torpedo";
    state.torpedoSpread = !!opts.spread;
  }
  state.selectedTarget = ship.id;
  // Lead aim
  const lead = ship.speed * 1.4;
  const aimX = ship.x + Math.cos(ship.heading) * lead;
  const aimY = ship.y + Math.sin(ship.heading) * lead;
  fireWeapon(state, aimX, aimY);
  return true;
}

function tryCm(
  state: GameState,
  deployCountermeasure: (state: GameState) => void,
) {
  if (state.sub.cmCharges > 0 && state.sub.cmCooldown <= 0) {
    deployCountermeasure(state);
  }
}

function tryFoxer(
  state: GameState,
  fireWeapon: (state: GameState, x: number, y: number) => void,
) {
  if (state.sub.decoys <= 0) return;
  state.weapon = "decoy";
  fireWeapon(state, state.sub.x, state.sub.y);
}

export function engageAutopilot(
  state: GameState,
  tactic: AutopilotTactic,
  targetId?: number | null,
) {
  if (!state.autopilot) state.autopilot = createAutopilot();
  const ap = state.autopilot;
  if (tactic === "manual") {
    ap.enabled = false;
    ap.tactic = "manual";
    ap.phase = "idle";
    ap.status = "Manual helm";
    ap.path = [];
    state.message = "Autopilot disengaged — manual helm.";
    state.messageLife = 2;
    return;
  }
  ap.enabled = true;
  ap.tactic = tactic;
  ap.targetId =
    targetId !== undefined
      ? targetId
      : state.selectedTarget ?? ap.targetId;
  if (tactic !== "evade" && tactic !== "exfil" && ap.targetId == null) {
    // pick nearest merchant/warship
    let best: Ship | null = null;
    let bestD = Infinity;
    for (const s of state.ships) {
      if (s.dead || s.sinking > 0) continue;
      const d = dist(s.x, s.y, state.sub.x, state.sub.y);
      if (d < bestD) {
        bestD = d;
        best = s;
      }
    }
    if (best) {
      ap.targetId = best.id;
      state.selectedTarget = best.id;
    }
  }
  ap.phase = tactic === "evade" ? "breakaway" : tactic === "exfil" ? "approach" : "approach";
  ap.phaseTimer = 0;
  ap.shotTimer = 0;
  ap.path = [];
  ap.status = `AI · ${tactic}`;
  state.message = `Autopilot: ${tactic.toUpperCase()}${ap.targetId != null ? " — target locked" : ""}.`;
  state.messageLife = 3;
}

export function disengageAutopilot(state: GameState) {
  engageAutopilot(state, "manual");
}

/**
 * Called each tick while playing. Mutates sub helm; uses injected fire helpers
 * to avoid circular imports with engine.
 */
export function updateAutopilot(
  state: GameState,
  terrain: TerrainCell[][],
  dt: number,
  deps: {
    fireWeapon: (state: GameState, x: number, y: number) => void;
    deployCountermeasure: (state: GameState) => void;
  },
) {
  if (!state.autopilot) state.autopilot = createAutopilot();
  const ap = state.autopilot;
  if (!ap.enabled || ap.tactic === "manual") return;
  if (state.phase !== "playing") return;

  // Only hold still when RTB has reached the pier — combat tactics must LEAVE the FOB
  const atFob =
    state.base &&
    Math.hypot(state.sub.x - state.base.x, state.sub.y - state.base.y) <
      (state.base.radius ?? 4);
  if (ap.tactic === "exfil" && ap.phase === "dock" && atFob) {
    setSpeed(state, 0);
    ap.status = "AI · docking FOB";
    return;
  }
  // If a combat tactic is engaged while sitting in the safe zone, push out first
  if (
    atFob &&
    (ap.tactic === "ambush" || ap.tactic === "stalk" || ap.tactic === "intercept")
  ) {
    const base = state.base!;
    const away = Math.atan2(state.sub.y - base.y, state.sub.x - base.x);
    const out = {
      x: base.x + Math.cos(away) * (base.radius + 6),
      y: base.y + Math.sin(away) * (base.radius + 6),
    };
    setSilent(state, true);
    setDepth(state, 0.45);
    setSpeed(state, state.sub.maxSpeed * 0.55);
    steerTo(state, terrain, out, dt, ap);
    ap.status = "AI · clearing FOB";
    ap.phase = "approach";
    // fall through once outside; this frame still moves outbound
  }

  ap.phaseTimer += dt;
  ap.shotTimer = Math.max(0, ap.shotTimer - dt);

  const boat = state.sub;
  const target = findShip(state, ap.targetId ?? state.selectedTarget);
  const threat = nearestThreat(state);

  // Emergency: heavy damage / flooding / battery → auto evade or exfil
  if (boat.sysFlood > 0.45 || boat.hp < 28 || boat.battery < 12) {
    if (ap.tactic !== "exfil" && ap.tactic !== "evade") {
      ap.tactic = boat.hp < 28 || boat.sysFlood > 0.45 ? "exfil" : "evade";
      ap.phase = "breakaway";
      ap.status = "AI · emergency";
    }
  }

  // Threat pressure → CM
  if (threat && threat.alert > 0.7 && dist(threat.x, threat.y, boat.x, boat.y) < 10) {
    if (Math.random() < dt * 0.4) tryCm(state, deps.deployCountermeasure);
    if (threat.alert > 0.85 && boat.decoys > 0 && Math.random() < dt * 0.2) {
      tryFoxer(state, deps.fireWeapon);
    }
  }

  const runEvade = () => {
    setSilent(state, true);
    setScope(state, false);
    setDepth(state, 0.78 + Math.random() * 0.08);
    const awayFrom = threat || target;
    let gx = boat.x;
    let gy = boat.y;
    if (awayFrom) {
      const a = Math.atan2(boat.y - awayFrom.y, boat.x - awayFrom.x);
      gx = boat.x + Math.cos(a) * 14;
      gy = boat.y + Math.sin(a) * 14;
    } else {
      gx = boat.x + Math.cos(boat.heading) * 10;
      gy = boat.y + Math.sin(boat.heading) * 10;
    }
    // Prefer deeper water
    steerTo(state, terrain, { x: gx, y: gy }, dt, ap);
    setSpeed(state, boat.maxSpeed * 0.25);
    ap.status = "AI · evade · silent deep";
    if (ap.phaseTimer > 12 && (!threat || dist(threat.x, threat.y, boat.x, boat.y) > 16)) {
      ap.enabled = false;
      ap.tactic = "manual";
      ap.status = "Manual helm — clear";
      state.message = "Autopilot: contact broken. Helm to you.";
      state.messageLife = 2.5;
    }
  };

  if (ap.tactic === "evade") {
    runEvade();
    return;
  }

  if (ap.tactic === "exfil") {
    const base = state.base;
    if (!base) {
      ap.status = "AI · no FOB";
      return;
    }
    const dBase = dist(boat.x, boat.y, base.x, base.y);
    if (dBase < base.radius * 0.9) {
      setSpeed(state, 0);
      boat.waypoint = null;
      ap.path = [];
      ap.phase = "dock";
      ap.status = "AI · docking FOB";
      setSilent(state, false);
      setDepth(state, 0.2);
      return;
    }
    // Low battery mid-route: snorkel if safe
    if (boat.battery < 30 && (!threat || dist(threat.x, threat.y, boat.x, boat.y) > 14)) {
      setDepth(state, 0.3);
      setSilent(state, false);
      boat.snorkel = true;
      boat.scopeUp = false;
      setSpeed(state, boat.maxSpeed * 0.35);
      ap.status = "AI · snorkel charge";
    } else {
      boat.snorkel = false;
      setSilent(state, !!threat && dist(threat.x, threat.y, boat.x, boat.y) < 18);
      setDepth(state, threat && threat.alert > 0.4 ? 0.72 : 0.45);
      setSpeed(state, boat.silentRunning ? boat.maxSpeed * 0.25 : boat.maxSpeed * 0.7);
      ap.status = "AI · RTB FOB";
    }
    steerTo(state, terrain, { x: base.x, y: base.y }, dt, ap);
    return;
  }

  // Combat tactics need a target
  if (!target) {
    ap.status = "AI · no target";
    // Hold quiet
    setSilent(state, true);
    setSpeed(state, 0.2);
    setDepth(state, 0.55);
    if (ap.phaseTimer > 4) {
      // pick new target
      engageAutopilot(state, ap.tactic, null);
    }
    return;
  }

  state.selectedTarget = target.id;
  const d = dist(boat.x, boat.y, target.x, target.y);
  const asp = aspectQuality(boat.heading, target, boat);

  // If escorts very close while not in breakaway, peel off
  if (
    threat &&
    threat.id !== target.id &&
    threat.alert > 0.75 &&
    dist(threat.x, threat.y, boat.x, boat.y) < 6 &&
    ap.phase !== "breakaway"
  ) {
    ap.phase = "breakaway";
    ap.phaseTimer = 0;
  }

  if (ap.phase === "breakaway") {
    runEvade();
    if (ap.phaseTimer > 8) {
      ap.phase = "approach";
      ap.phaseTimer = 0;
      ap.tactic = ap.tactic === "intercept" ? "stalk" : ap.tactic;
    }
    return;
  }

  // --- AMBUSH ---
  if (ap.tactic === "ambush") {
    if (ap.phase === "approach" || ap.phase === "idle") {
      setSilent(state, true);
      setScope(state, false);
      setDepth(state, 0.65);
      const goal = beamAimPoint(target, target.id % 2 === 0);
      steerTo(state, terrain, goal, dt, ap);
      setSpeed(state, boat.maxSpeed * 0.22);
      ap.status = `AI · ambush approach · ${d.toFixed(0)}u`;
      if (d < 7.5) {
        ap.phase = "setup";
        ap.phaseTimer = 0;
      }
    } else if (ap.phase === "setup") {
      setSilent(state, true);
      setDepth(state, 0.28);
      setSpeed(state, boat.maxSpeed * 0.15);
      const goal = beamAimPoint(target, true);
      steerTo(state, terrain, goal, dt, ap);
      ap.status = "AI · ambush setup · peri";
      if (Math.abs(boat.z - 0.28) < 0.08 && d < 8 && asp > 0.45) {
        ap.phase = "attack";
        ap.phaseTimer = 0;
      }
      if (ap.phaseTimer > 18) {
        ap.phase = "approach";
        ap.phaseTimer = 0;
      }
    } else if (ap.phase === "attack") {
      setScope(state, true);
      setSilent(state, false);
      setDepth(state, 0.28);
      setSpeed(state, 0.3);
      // Point bow at lead
      const lead = target.speed * 1.5;
      const aimH = Math.atan2(
        target.y + Math.sin(target.heading) * lead - boat.y,
        target.x + Math.cos(target.heading) * lead - boat.x,
      );
      boat.heading += clamp(angleDiff(boat.heading, aimH), -1.8 * dt, 1.8 * dt);
      ap.status = "AI · ambush FIRE";
      if (ap.shotTimer <= 0 && boat.z > 0.12 && boat.z < 0.55) {
        const fired = tryFire(state, target, { spread: true }, deps.fireWeapon);
        if (fired) {
          ap.shotTimer = 4;
          ap.phase = "breakaway";
          ap.phaseTimer = 0;
        } else if (boat.seekers > 0) {
          tryFire(state, target, { seeking: true }, deps.fireWeapon);
          ap.shotTimer = 4;
          ap.phase = "breakaway";
          ap.phaseTimer = 0;
        }
      }
    }
    return;
  }

  // --- STALK ---
  if (ap.tactic === "stalk") {
    setSilent(state, true);
    setScope(state, false);
    setDepth(state, d < 8 ? 0.55 : 0.48);
    const goal = stalkPoint(target, boat);
    steerTo(state, terrain, goal, dt, ap);
    setSpeed(state, boat.maxSpeed * 0.2);
    ap.status = `AI · stalk · asp ${(asp * 100).toFixed(0)}% · ${d.toFixed(0)}u`;
    if (d < 9 && d > 4 && asp > 0.55 && ap.shotTimer <= 0 && boat.battery > 20) {
      setDepth(state, 0.32);
      if (Math.abs(boat.z - 0.32) < 0.12) {
        setScope(state, true);
        const fired = tryFire(
          state,
          target,
          { seeking: target.class === "sub" || target.speed > 1.2, spread: target.class === "freighter" },
          deps.fireWeapon,
        );
        if (fired) {
          ap.shotTimer = 8;
          ap.phase = "breakaway";
          ap.phaseTimer = 0;
          ap.status = "AI · stalk shot · break";
        }
      }
    }
    return;
  }

  // --- INTERCEPT ---
  if (ap.tactic === "intercept") {
    if (ap.phase === "approach" || ap.phase === "idle" || ap.phase === "setup") {
      setSilent(state, d > 12);
      setScope(state, false);
      setDepth(state, d > 10 ? 0.5 : 0.32);
      const goal = interceptPoint(target);
      steerTo(state, terrain, goal, dt, ap);
      setSpeed(
        state,
        boat.silentRunning ? boat.maxSpeed * 0.25 : boat.maxSpeed * 0.85,
      );
      ap.status = `AI · intercept · ${d.toFixed(0)}u`;
      if (d < 8) {
        ap.phase = "attack";
        ap.phaseTimer = 0;
      }
    } else if (ap.phase === "attack") {
      setSilent(state, false);
      setDepth(state, 0.3);
      setScope(state, true);
      const goal = interceptPoint(target);
      steerTo(state, terrain, goal, dt, ap);
      setSpeed(state, boat.maxSpeed * 0.5);
      ap.status = "AI · intercept FIRE";
      if (ap.shotTimer <= 0) {
        const fired =
          tryFire(state, target, { seeking: true }, deps.fireWeapon) ||
          tryFire(state, target, { spread: true }, deps.fireWeapon);
        if (fired) {
          ap.shotTimer = 5;
          ap.phase = "breakaway";
          ap.phaseTimer = 0;
        }
      }
      if (ap.phaseTimer > 10) {
        ap.phase = "breakaway";
        ap.phaseTimer = 0;
      }
    }
    return;
  }
}
