/**
 * Isometric projection — classic 2:1 diamond tiles.
 *
 * Single vertical scale for the whole theater:
 *   world-z = 0  → water surface
 *   world-z > 0  → above surface (land peaks)
 *   world-z < 0  → below surface (sub depth, trenches)
 *
 * Screen:  sy decreases as world-z increases (up on canvas).
 */

export const TILE_W = 64;
export const TILE_H = 32;

/** Pixels of vertical lift per world-z unit at zoom = 1. */
export const ISO_Z_PX = 40;

/**
 * Sub depth 0..1 → |world-z| below surface.
 * depth 1 → 0.55 world-z → ~22px drop at zoom 1 (matches prior feel).
 */
export const DEPTH_WORLD_Z = 0.55;

/**
 * Extra rotation after projecting world heading → screen angle.
 * Keep 0: local +X (bow) must match projected velocity atan2(dsy, dsx).
 */
export const ART_NOSE_OFFSET = 0;

/** World-z for a submerged depth band (0 surface … 1 deep). Negative = down. */
export function depthToWorldZ(depth: number): number {
  const d = depth < 0 ? 0 : depth > 1 ? 1 : depth;
  return -d * DEPTH_WORLD_Z;
}

/** @deprecated use depthToWorldZ — kept as alias for clarity in call sites */
export function depthToZ(depth: number): number {
  return depthToWorldZ(depth);
}

export function worldToScreen(
  x: number,
  y: number,
  z: number,
  camX: number,
  camY: number,
  zoom: number,
  viewW: number,
  viewH: number,
): { sx: number; sy: number } {
  const rx = x - camX;
  const ry = y - camY;
  const sx = (rx - ry) * (TILE_W / 2) * zoom + viewW / 2;
  const sy = (rx + ry) * (TILE_H / 2) * zoom - z * ISO_Z_PX * zoom + viewH / 2;
  return { sx, sy };
}

/**
 * Inverse projector at a fixed world-z (default: water surface).
 * Click-to-move / hover always use z = 0.
 */
export function screenToWorld(
  sx: number,
  sy: number,
  camX: number,
  camY: number,
  zoom: number,
  viewW: number,
  viewH: number,
  z = 0,
): { x: number; y: number } {
  const px = (sx - viewW / 2) / zoom;
  const py = (sy - viewH / 2 + z * ISO_Z_PX * zoom) / zoom;
  const rx = px / (TILE_W / 2);
  const ry = py / (TILE_H / 2);
  const x = (rx + ry) / 2 + camX;
  const y = (ry - rx) / 2 + camY;
  return { x, y };
}

/**
 * Convert a screen-space drag (pixels) into world-space delta.
 * Same basis as screenToWorld — use for grab-pan so pan matches click.
 *
 * Grab pan:  cam += screenDeltaToWorld(dx, dy, zoom)   is wrong for "content follows finger".
 * Use:       cam -= screenDeltaToWorld(dx, dy, zoom)   so the grabbed point sticks.
 */
export function screenDeltaToWorld(
  dsx: number,
  dsy: number,
  zoom: number,
): { x: number; y: number } {
  const z = zoom === 0 ? 1 : zoom;
  const px = dsx / z;
  const py = dsy / z;
  const rx = px / (TILE_W / 2);
  const ry = py / (TILE_H / 2);
  return {
    x: (rx + ry) / 2,
    y: (ry - rx) / 2,
  };
}

/** Apply grab-pan: content follows pointer. */
export function panCameraByScreenDelta(
  cam: { x: number; y: number; targetX: number; targetY: number },
  dsx: number,
  dsy: number,
  zoom: number,
): void {
  const d = screenDeltaToWorld(dsx, dsy, zoom);
  cam.targetX -= d.x;
  cam.targetY -= d.y;
  cam.x = cam.targetX;
  cam.y = cam.targetY;
}

/** Screen-space velocity for unit speed along world heading θ. */
export function worldHeadingScreenDelta(heading: number): { dsx: number; dsy: number } {
  const c = Math.cos(heading);
  const s = Math.sin(heading);
  return {
    dsx: (c - s) * (TILE_W / 2),
    dsy: (c + s) * (TILE_H / 2),
  };
}

/**
 * World heading → canvas rotation for nose-on-+local-X art.
 * Uses the real projector so bow tracks on-screen motion.
 */
export function worldHeadingToScreen(heading: number): number {
  const a = worldToScreen(0, 0, 0, 0, 0, 1, 0, 0);
  const b = worldToScreen(Math.cos(heading), Math.sin(heading), 0, 0, 0, 1, 0, 0);
  const dsx = b.sx - a.sx;
  const dsy = b.sy - a.sy;
  if (dsx * dsx + dsy * dsy < 1e-12) return heading + ART_NOSE_OFFSET;
  return Math.atan2(dsy, dsx) + ART_NOSE_OFFSET;
}

export function worldHeadingScreenDir(heading: number): { x: number; y: number } {
  const { dsx, dsy } = worldHeadingScreenDelta(heading);
  const len = Math.hypot(dsx, dsy) || 1;
  return { x: dsx / len, y: dsy / len };
}

export function sternOffset(
  heading: number,
  dist: number,
): { x: number; y: number } {
  return { x: -Math.cos(heading) * dist, y: -Math.sin(heading) * dist };
}

/**
 * Stroke a circle of constant world radius as a screen ellipse
 * (projected via the same basis — honest range cue).
 */
export function strokeWorldCircle(
  ctx: CanvasRenderingContext2D,
  cx: number,
  cy: number,
  radius: number,
  camX: number,
  camY: number,
  zoom: number,
  viewW: number,
  viewH: number,
  worldZ = 0,
  segments = 64,
): void {
  if (radius <= 0) return;
  const n = Math.max(12, segments);
  ctx.beginPath();
  for (let i = 0; i <= n; i++) {
    const a = (i / n) * Math.PI * 2;
    const { sx, sy } = worldToScreen(
      cx + Math.cos(a) * radius,
      cy + Math.sin(a) * radius,
      worldZ,
      camX,
      camY,
      zoom,
      viewW,
      viewH,
    );
    if (i === 0) ctx.moveTo(sx, sy);
    else ctx.lineTo(sx, sy);
  }
  ctx.closePath();
  ctx.stroke();
}

export function dist2(ax: number, ay: number, bx: number, by: number): number {
  const dx = ax - bx;
  const dy = ay - by;
  return dx * dx + dy * dy;
}

export function dist(ax: number, ay: number, bx: number, by: number): number {
  return Math.hypot(ax - bx, ay - by);
}

export function clamp(v: number, a: number, b: number): number {
  return Math.max(a, Math.min(b, v));
}

export function lerp(a: number, b: number, t: number): number {
  return a + (b - a) * t;
}

export function angleDiff(a: number, b: number): number {
  let d = b - a;
  while (d > Math.PI) d -= Math.PI * 2;
  while (d < -Math.PI) d += Math.PI * 2;
  return d;
}

export function hash2(x: number, y: number, seed = 0): number {
  const s = Math.sin(x * 127.1 + y * 311.7 + seed * 74.7) * 43758.5453123;
  return s - Math.floor(s);
}

function fade(t: number): number {
  return t * t * t * (t * (t * 6 - 15) + 10);
}

function grad(ix: number, iy: number, seed: number, x: number, y: number): number {
  const h = hash2(ix, iy, seed);
  const a = h * Math.PI * 2;
  return Math.cos(a) * x + Math.sin(a) * y;
}

export function noise2(x: number, y: number, seed = 0): number {
  const x0 = Math.floor(x);
  const y0 = Math.floor(y);
  const fx = x - x0;
  const fy = y - y0;
  const u = fade(fx);
  const v = fade(fy);
  const n00 = grad(x0, y0, seed, fx, fy);
  const n10 = grad(x0 + 1, y0, seed, fx - 1, fy);
  const n01 = grad(x0, y0 + 1, seed, fx, fy - 1);
  const n11 = grad(x0 + 1, y0 + 1, seed, fx - 1, fy - 1);
  const nx0 = n00 + (n10 - n00) * u;
  const nx1 = n01 + (n11 - n01) * u;
  const n = nx0 + (nx1 - nx0) * v;
  return n * 0.5 + 0.5;
}

export function fbm(x: number, y: number, seed = 0, octaves = 4): number {
  let amp = 0.5;
  let freq = 1;
  let sum = 0;
  let norm = 0;
  for (let i = 0; i < octaves; i++) {
    sum += noise2(x * freq, y * freq, seed + i * 17) * amp;
    norm += amp;
    amp *= 0.5;
    freq *= 2;
  }
  return sum / norm;
}
