/**
 * Land / shoal avoidance for surface ships and the player sub.
 * - Multi-feeler steering for local avoidance
 * - Coarse A* for blocked long-range goals (patrols, player plot)
 */
import { angleDiff, clamp, dist } from "./iso";
import { WORLD_SIZE, isLand, isNavigable, isShipNavigable } from "./world";
import type { TerrainCell, Vec2 } from "./types";

export type ClearFn = (x: number, y: number) => boolean;

/** Ship hull clearance: sample a disc so big hulls don't clip land. */
export function makeShipClear(
  terrain: TerrainCell[][],
  radius = 0.55,
): ClearFn {
  return (x, y) => {
    if (!isShipNavigable(terrain, x, y) || isLand(terrain, x, y)) return false;
    if (radius <= 0.35) return true;
    const steps = radius > 0.8 ? 6 : 4;
    for (let i = 0; i < steps; i++) {
      const a = (i / steps) * Math.PI * 2;
      const px = x + Math.cos(a) * radius;
      const py = y + Math.sin(a) * radius;
      if (!isShipNavigable(terrain, px, py) || isLand(terrain, px, py)) return false;
    }
    return true;
  };
}

export function makeSubClear(terrain: TerrainCell[][], depth: number): ClearFn {
  return (x, y) =>
    !isLand(terrain, x, y) && isNavigable(terrain, x, y, depth);
}

export function shipClearRadius(cls: string): number {
  switch (cls) {
    case "battleship":
      return 1.05;
    case "cruiser":
      return 0.85;
    case "freighter":
      return 0.9;
    case "destroyer":
      return 0.65;
    case "sub":
      return 0.75;
    case "patrol":
      return 0.45;
    default:
      return 0.55;
  }
}

/**
 * Multi-distance feeler steering. Returns a heading that keeps the vessel in open water.
 */
export function steerAvoid(
  x: number,
  y: number,
  heading: number,
  lookAhead: number,
  clear: ClearFn,
  opts: { rays?: number; maxDeflect?: number } = {},
): number {
  const rays = opts.rays ?? 11;
  const maxDeflect = opts.maxDeflect ?? Math.PI * 0.95;
  const dists = [
    lookAhead * 0.45,
    lookAhead * 0.85,
    lookAhead * 1.25,
    lookAhead * 1.7,
  ];

  let bestH = heading;
  let bestScore = -Infinity;

  for (let i = 0; i < rays; i++) {
    const t = rays === 1 ? 0 : i / (rays - 1);
    const deflect = (t - 0.5) * 2 * maxDeflect;
    const h = heading + deflect;
    let score = 0;
    let blocked = false;
    for (let d = 0; d < dists.length; d++) {
      const distLook = dists[d]!;
      const px = x + Math.cos(h) * distLook;
      const py = y + Math.sin(h) * distLook;
      if (!clear(px, py)) {
        // Near hits hurt more
        score -= (dists.length - d) * 4;
        if (d === 0) blocked = true;
        break;
      }
      score += 1 + d * 0.35;
    }
    // Prefer continuing roughly forward
    score -= Math.abs(deflect) * 0.55;
    // Side clearance bonus
    const side = h + Math.PI / 2;
    if (clear(x + Math.cos(side) * 0.7, y + Math.sin(side) * 0.7)) score += 0.25;
    if (clear(x - Math.cos(side) * 0.7, y - Math.sin(side) * 0.7)) score += 0.25;

    if (!blocked && score > bestScore) {
      bestScore = score;
      bestH = h;
    }
  }

  // Emergency reverse if everything blocked
  if (bestScore < -8) {
    return heading + Math.PI * 0.6;
  }
  return bestH;
}

/** Legacy-compatible wrapper used by older call sites. */
export function steerClear(
  x: number,
  y: number,
  heading: number,
  lookAhead: number,
  clear: ClearFn,
): number {
  return steerAvoid(x, y, heading, lookAhead, clear, { rays: 13, maxDeflect: Math.PI * 0.9 });
}

const PATH_STEP = 2; // coarse grid for A*

function key(ix: number, iy: number) {
  return ix * 1024 + iy;
}

function cellOk(clear: ClearFn, ix: number, iy: number): boolean {
  const x = ix * PATH_STEP + PATH_STEP * 0.5;
  const y = iy * PATH_STEP + PATH_STEP * 0.5;
  if (x < 2 || y < 2 || x >= WORLD_SIZE - 2 || y >= WORLD_SIZE - 2) return false;
  return clear(x, y);
}

/**
 * Coarse A* path in world tiles. Returns waypoints (including goal) or empty if none.
 */
export function findPath(
  start: Vec2,
  goal: Vec2,
  clear: ClearFn,
  maxNodes = 900,
): Vec2[] {
  const sx = clamp(Math.floor(start.x / PATH_STEP), 0, Math.floor(WORLD_SIZE / PATH_STEP) - 1);
  const sy = clamp(Math.floor(start.y / PATH_STEP), 0, Math.floor(WORLD_SIZE / PATH_STEP) - 1);
  let gx = clamp(Math.floor(goal.x / PATH_STEP), 0, Math.floor(WORLD_SIZE / PATH_STEP) - 1);
  let gy = clamp(Math.floor(goal.y / PATH_STEP), 0, Math.floor(WORLD_SIZE / PATH_STEP) - 1);

  // Snap goal to nearest open cell
  if (!cellOk(clear, gx, gy)) {
    let found = false;
    for (let r = 1; r <= 6 && !found; r++) {
      for (let dy = -r; dy <= r && !found; dy++) {
        for (let dx = -r; dx <= r && !found; dx++) {
          if (cellOk(clear, gx + dx, gy + dy)) {
            gx += dx;
            gy += dy;
            found = true;
          }
        }
      }
    }
    if (!found) return [];
  }
  if (!cellOk(clear, sx, sy)) {
    // Start slightly invalid — try neighbors
    for (let r = 1; r <= 4; r++) {
      for (let dy = -r; dy <= r; dy++) {
        for (let dx = -r; dx <= r; dx++) {
          if (cellOk(clear, sx + dx, sy + dy)) {
            return findPath(
              { x: (sx + dx) * PATH_STEP + 1, y: (sy + dy) * PATH_STEP + 1 },
              goal,
              clear,
              maxNodes,
            );
          }
        }
      }
    }
    return [];
  }

  // Direct line free? skip A*
  if (lineClear(start.x, start.y, goal.x, goal.y, clear)) {
    return [{ x: goal.x, y: goal.y }];
  }

  type Node = { ix: number; iy: number; g: number; f: number; px: number; py: number };
  const open: Node[] = [];
  const gScore = new Map<number, number>();
  const came = new Map<number, number>(); // child -> parent key
  const startK = key(sx, sy);
  gScore.set(startK, 0);
  open.push({
    ix: sx,
    iy: sy,
    g: 0,
    f: Math.hypot(gx - sx, gy - sy),
    px: -1,
    py: -1,
  });

  const dirs = [
    [1, 0],
    [-1, 0],
    [0, 1],
    [0, -1],
    [1, 1],
    [1, -1],
    [-1, 1],
    [-1, -1],
  ];

  let expanded = 0;
  let found: Node | null = null;

  while (open.length > 0 && expanded < maxNodes) {
    // pop lowest f
    let bi = 0;
    for (let i = 1; i < open.length; i++) {
      if (open[i]!.f < open[bi]!.f) bi = i;
    }
    const cur = open[bi]!;
    open[bi] = open[open.length - 1]!;
    open.pop();
    expanded++;

    if (cur.ix === gx && cur.iy === gy) {
      found = cur;
      break;
    }

    for (const [dx, dy] of dirs) {
      const nix = cur.ix + dx!;
      const niy = cur.iy + dy!;
      if (!cellOk(clear, nix, niy)) continue;
      // Corner cut prevention
      if (dx !== 0 && dy !== 0) {
        if (!cellOk(clear, cur.ix + dx!, cur.iy) || !cellOk(clear, cur.ix, cur.iy + dy!)) continue;
      }
      const nk = key(nix, niy);
      const step = dx !== 0 && dy !== 0 ? 1.414 : 1;
      const tent = cur.g + step;
      if (tent >= (gScore.get(nk) ?? Infinity)) continue;
      gScore.set(nk, tent);
      came.set(nk, key(cur.ix, cur.iy));
      const h = Math.hypot(gx - nix, gy - niy);
      open.push({ ix: nix, iy: niy, g: tent, f: tent + h, px: cur.ix, py: cur.iy });
    }
  }

  if (!found) return [];

  // Reconstruct
  const cells: { ix: number; iy: number }[] = [{ ix: found.ix, iy: found.iy }];
  let ck = key(found.ix, found.iy);
  while (came.has(ck)) {
    const pk = came.get(ck)!;
    const pix = Math.floor(pk / 1024);
    const piy = pk % 1024;
    // decode: key = ix * 1024 + iy — careful if iy can be large
    // WORLD_SIZE/2 ~ 48, so iy < 1024 ok
    cells.push({ ix: pix, iy: piy });
    ck = pk;
    if (cells.length > 200) break;
  }
  cells.reverse();

  // Convert to world waypoints, skip every other for smoothing, always end at goal
  const path: Vec2[] = [];
  for (let i = 1; i < cells.length; i++) {
    if (i < cells.length - 1 && i % 2 === 0) continue;
    const c = cells[i]!;
    path.push({
      x: c.ix * PATH_STEP + PATH_STEP * 0.5,
      y: c.iy * PATH_STEP + PATH_STEP * 0.5,
    });
  }
  path.push({ x: goal.x, y: goal.y });
  return path;
}

export function lineClear(
  x0: number,
  y0: number,
  x1: number,
  y1: number,
  clear: ClearFn,
  step = 0.6,
): boolean {
  const d = dist(x0, y0, x1, y1);
  if (d < 0.01) return clear(x1, y1);
  const n = Math.ceil(d / step);
  for (let i = 1; i <= n; i++) {
    const t = i / n;
    const x = x0 + (x1 - x0) * t;
    const y = y0 + (y1 - y0) * t;
    if (!clear(x, y)) return false;
  }
  return true;
}

/** Advance along a path; returns remaining path and desired heading. */
export function followPath(
  x: number,
  y: number,
  path: Vec2[],
  arrive = 1.1,
): { path: Vec2[]; heading: number | null; arrived: boolean } {
  if (!path.length) return { path, heading: null, arrived: true };
  let p = path.slice();
  while (p.length && dist(x, y, p[0]!.x, p[0]!.y) < arrive) {
    p = p.slice(1);
  }
  if (!p.length) return { path: [], heading: null, arrived: true };
  return {
    path: p,
    heading: Math.atan2(p[0]!.y - y, p[0]!.x - x),
    arrived: false,
  };
}

export function repathIfNeeded(
  x: number,
  y: number,
  goal: Vec2,
  path: Vec2[] | null | undefined,
  clear: ClearFn,
  repathTimer: number,
): { path: Vec2[]; repathTimer: number } {
  let timer = repathTimer;
  const need =
    !path ||
    path.length === 0 ||
    (path.length > 0 && !lineClear(x, y, path[0]!.x, path[0]!.y, clear, 0.8));

  if (need && timer <= 0) {
    const np = findPath({ x, y }, goal, clear);
    return { path: np, repathTimer: 1.2 };
  }
  return { path: path ?? [], repathTimer: timer };
}
