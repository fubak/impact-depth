export type GamePhase = "menu" | "playing" | "paused" | "gameover" | "victory";

export type DepthBand = 0 | 1 | 2;

/** Surface ships + enemy U-boats. Battleships + U-boats drop depth charges. */
export type ShipClass =
  | "patrol"
  | "destroyer"
  | "freighter"
  | "cruiser"
  | "battleship"
  | "sub";

/** torpedo = straight / light wire · seeker = upgraded acoustic · decoy = foxer noisemaker */
export type WeaponMode = "torpedo" | "seeker" | "decoy";

export type AutopilotTactic =
  | "manual"
  | "ambush"
  | "stalk"
  | "intercept"
  | "evade"
  | "exfil";

export type AutopilotPhase =
  | "idle"
  | "approach"
  | "setup"
  | "attack"
  | "breakaway"
  | "hold"
  | "dock";

export interface AutopilotState {
  enabled: boolean;
  tactic: AutopilotTactic;
  targetId: number | null;
  phase: AutopilotPhase;
  phaseTimer: number;
  shotTimer: number;
  repathTimer: number;
  path: { x: number; y: number }[];
  status: string;
}

/** Floating pickups scattered across the map. */
export type PowerupKind =
  | "health"
  | "ammo"
  | "hull"
  | "weapon"
  | "speed"
  | "counter";

export interface Vec2 {
  x: number;
  y: number;
}

export interface Particle {
  x: number;
  y: number;
  z: number;
  vx: number;
  vy: number;
  vz: number;
  life: number;
  maxLife: number;
  size: number;
  color: string;
  kind:
    | "bubble"
    | "wake"
    | "spark"
    | "smoke"
    | "debris"
    | "splash"
    | "trail"
    | "flash"
    | "ember";
}

/** Short-lived screen-space rings / flashes for hits, detonations, pickups. */
export interface ImpactFx {
  x: number;
  y: number;
  z: number;
  life: number;
  maxLife: number;
  radius: number;
  color: string;
  kind: "shock" | "hit" | "pickup" | "spawn" | "splash" | "boom";
}

export interface Torpedo {
  id: number;
  x: number;
  y: number;
  z: number;
  vx: number;
  vy: number;
  heading: number;
  targetId: number | null;
  life: number;
  owner: "player" | "enemy";
  damage: number;
  armed: boolean;
  seeking: boolean;
  trailTimer: number;
}

export interface DepthCharge {
  id: number;
  x: number;
  y: number;
  z: number;
  vz: number;
  fuse: number;
  radius: number;
  damage: number;
  divertX: number | null;
  divertY: number | null;
  diverted: boolean;
  /** Hedgehog contact-fused projectile (explodes only near hull). */
  contact?: boolean;
  /** Preferred detonation depth band 0..1. */
  setDepth?: number;
}

export interface AircraftPatrol {
  x: number;
  y: number;
  heading: number;
  life: number;
  cooldown: number;
}

export interface Countermeasure {
  id: number;
  x: number;
  y: number;
  z: number;
  life: number;
  maxLife: number;
  radius: number;
  kind: "bubble" | "foxer";
  strength: number;
}

export interface Ship {
  id: number;
  class: ShipClass;
  x: number;
  y: number;
  heading: number;
  displayHeading: number;
  speed: number;
  maxSpeed: number;
  hp: number;
  maxHp: number;
  sinking: number;
  alert: number;
  fireCooldown: number;
  patrolAngle: number;
  dead: boolean;
  name: string;
  trailTimer: number;
  turnRate: number;
  /** Looping navigable waypoints when not engaged. */
  patrolRoute: Vec2[];
  patrolIndex: number;
  /** 1 = forward along route, -1 = reverse (for linear freighter lanes). */
  patrolDir: 1 | -1;
  /** freighter lanes reverse at ends; others loop. */
  patrolLoop: boolean;
  /** Runtime path from A* (not networked). */
  path?: { x: number; y: number }[];
  repathTimer?: number;
  /** Hold-down: how long this escort has been tracking player. */
  holdContact?: number;
  /** Convoy id for screen formation (freighter group). */
  convoyId?: number;
  /** Role in convoy: merchant | screen | hunter */
  role?: "merchant" | "screen" | "hunter";
}

export interface Submarine {
  x: number;
  y: number;
  z: number;
  heading: number;
  displayHeading: number;
  bank: number;
  speed: number;
  targetSpeed: number;
  /** Player speed intent 0..1 of maxSpeed (HUD sticky; caps applied to targetSpeed). */
  speedOrder: number;
  maxSpeed: number;
  hp: number;
  maxHp: number;
  torpedoes: number;
  maxTorpedoes: number;
  seekers: number;
  maxSeekers: number;
  /** Shared tube busy timer (legacy / UI max of per-type). */
  reload: number;
  /** Mk-14 tube recycle remaining (s). */
  reloadMk14: number;
  /** Mk-18 seeker tube recycle remaining (s). */
  reloadMk18: number;
  /** Duration of current Mk-14 recycle (for progress bar). */
  reloadMk14Max: number;
  reloadMk18Max: number;
  decoys: number;
  cmCharges: number;
  maxCmCharges: number;
  cmCooldown: number;
  noise: number;
  waypoint: Vec2 | null;
  targetDepth: number;
  ballast: number;
  invuln: number;
  trailTimer: number;
  /** Permanent upgrade tiers from powerups (0–3). */
  hullTier: number;
  weaponTier: number;
  speedTier: number;
  /** Seconds remaining of dock repair feedback. */
  docked: number;
  /** Electric battery 0..maxBattery. */
  battery: number;
  maxBattery: number;
  /** Silent running — speed & noise capped. */
  silentRunning: boolean;
  /** Periscope / attack scope raised. */
  scopeUp: boolean;
  /** Snorkel for battery charge at peri depth. */
  snorkel: boolean;
  /** System integrity 0..1 */
  sysSonar: number;
  sysPropulsion: number;
  sysTubes: number;
  /** Flooding 0..1 */
  sysFlood: number;
  /** Crew stress 0..1 from prolonged ASW. */
  crewStress: number;
}

export interface Powerup {
  id: number;
  x: number;
  y: number;
  kind: PowerupKind;
  /** Visual phase. */
  pulse: number;
  /** Age since spawn — drives spawn glow / despawn. */
  age: number;
  /** Optional despawn timer (0 = permanent until pickup). */
  life: number;
}

/** Friendly forward operating base — repairs & resupply when you slow nearby. */
export interface NavalBase {
  x: number;
  y: number;
  radius: number;
  name: string;
}

export interface TerrainCell {
  height: number;
  biome: number;
  plant: number;
  plantType: number;
  land: boolean;
}

export interface FloatingText {
  x: number;
  y: number;
  text: string;
  life: number;
  color: string;
  vy: number;
}

/** Player sonar picture — passive hydrophone or active ASDIC return. */
export interface SonarContact {
  id: number;
  targetId: number | null;
  x: number;
  y: number;
  bearing: number;
  range: number;
  strength: number;
  label: string;
  source: "passive" | "active";
  age: number;
  maxAge: number;
}

export interface Camera {
  x: number;
  y: number;
  zoom: number;
  shake: number;
  targetX: number;
  targetY: number;
  follow: boolean;
  followTimer: number;
}

export interface GameStats {
  score: number;
  shipsSunk: number;
  torpedoesFired: number;
  damageDealt: number;
  timeSurvived: number;
  wave: number;
  powerupsTaken: number;
  repairs: number;
}

export interface GameState {
  phase: GamePhase;
  sub: Submarine;
  ships: Ship[];
  torpedoes: Torpedo[];
  depthCharges: DepthCharge[];
  countermeasures: Countermeasure[];
  powerups: Powerup[];
  base: NavalBase;
  particles: Particle[];
  impacts: ImpactFx[];
  floats: FloatingText[];
  /** Hydrophone / ASDIC contacts (player picture). */
  sonarContacts: SonarContact[];
  camera: Camera;
  stats: GameStats;
  weapon: WeaponMode;
  selectedTarget: number | null;
  hoverWorld: Vec2 | null;
  seed: number;
  nextId: number;
  message: string;
  messageLife: number;
  gameOverReason: string;
  /** Active ping life remaining (0 = idle). */
  sonarPing: number;
  /** Seconds until active sonar ready. */
  sonarActiveCooldown: number;
  /** Passive sweep angle for UI/FX. */
  sonarSweep: number;
  time: number;
  victoryTarget: number;
  muted: boolean;
  /** Show world/screen facing rays + 16-dir bin */
  debugFacing: boolean;
  /** Cooldown before next powerup respawn. */
  powerupSpawnTimer: number;
  /** 0..1 day cycle. */
  timeOfDay: number;
  /** Sea state 0 calm .. 1 rough. */
  seaState: number;
  /** Mission type flavor. */
  missionType: "patrol" | "ambush" | "exfil" | "hunter";
  aircraft: AircraftPatrol;
  /** Torpedo fire mode: single or spread. */
  torpedoSpread: boolean;
  autopilot: AutopilotState;
}
