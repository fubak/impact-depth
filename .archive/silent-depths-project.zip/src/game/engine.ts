// @ts-nocheck
/**
 * Silent Depths — game simulation (reconstructed).
 */
import * as audio from "./audio";
import { angleDiff, clamp, dist, dist2, lerp, worldToScreen } from "./iso";
import {
  WORLD_SIZE,
  floorClearance,
  generateTerrain,
  isLand,
  isNavigable,
  isShipNavigable,
  sampleTerrain,
} from "./world";
import {
  findPath,
  followPath,
  lineClear,
  makeShipClear,
  makeSubClear,
  steerAvoid,
} from "./pathfinding";
import type { GameState, PowerupKind, ShipClass, TerrainCell, WeaponMode } from "./types";
import { fireActiveSonar, updatePlayerSonar } from "./sonar";
import {
  THERMOCLINE,
  applySystemsNoise,
  aspectBonus,
  convoyScreenOffset,
  damageSystems,
  fireHedgehog,
  mastSignature,
  tickSystems,
  updateAircraft,
  updateBattery,
} from "./tactics";
import {
  createAutopilot,
  disengageAutopilot,
  engageAutopilot,
  updateAutopilot,
} from "./autopilot";
import { invalidateWaterMask } from "./waterPass";

const SHIP_NAMES = [
  "IJN Akashi", "KMS Bismarck Escort", "IJN Yukikaze", "KMS Admiral Hipper",
  "IJN Fubuki", "Merchant Pacific Star", "Freighter Iron Maru", "Destroyer Shimakaze",
  "Cruiser Tone", "Patrol Boat Type-C", "Tanker Sakura", "Escort Matsu",
];
const BATTLESHIP_NAMES = ["IJN Yamato", "IJN Musashi", "KMS Bismarck", "KMS Tirpitz", "IJN Nagato"];
const ENEMY_SUB_NAMES = ["U-47", "U-99", "I-19", "I-168", "U-552", "I-58", "U-96"];
const DEFAULT_CRUISE = 1.6;
const DC_ENGAGE_RANGE = 3.25;

let openWater = [];

function rebuildOpenWater(terrain) {
  openWater = [];
  for (let y = 3; y < WORLD_SIZE - 3; y += 2) {
    for (let x = 3; x < WORLD_SIZE - 3; x += 2) {
      if (isShipNavigable(terrain, x, y)) openWater.push({ x, y });
    }
  }
}

function pickOpenWaterNear(x, y) {
  if (!openWater.length) return { x: WORLD_SIZE / 2, y: WORLD_SIZE / 2 };
  let best = openWater[0], bestD = Infinity;
  const n = Math.min(openWater.length, 48);
  const start = Math.floor(Math.random() * openWater.length);
  for (let i = 0; i < n; i++) {
    const p = openWater[(start + i) % openWater.length];
    const d = dist2(p.x, p.y, x, y);
    if (d < bestD) { bestD = d; best = p; }
  }
  return best;
}

function uid(state) { return state.nextId++; }

function applySpeedCaps(boat) {
  const max = Math.max(0.2, boat.maxSpeed || 2.4);
  let order = boat.speedOrder;
  if (order == null || Number.isNaN(order)) {
    order = clamp((boat.targetSpeed || 0) / max, 0, 1);
    boat.speedOrder = order;
  }
  let s = clamp(order, 0, 1) * max;
  if (boat.silentRunning) s = Math.min(s, max * 0.28);
  if ((boat.battery ?? 100) <= 0.5 && boat.z >= 0.12 && !boat.snorkel) s = Math.min(s, 0.35);
  if ((boat.sysPropulsion || 1) < 0.95) s = Math.min(s, max * (0.45 + boat.sysPropulsion * 0.55));
  boat.targetSpeed = s;
  return s;
}

function shipStats(cls) {
  switch (cls) {
    case "patrol": return { maxSpeed: 2.6, maxHp: 50, turnRate: 1.05 };
    case "destroyer": return { maxSpeed: 2.35, maxHp: 120, turnRate: 0.82 };
    case "freighter": return { maxSpeed: 1.15, maxHp: 95, turnRate: 0.4 };
    case "cruiser": return { maxSpeed: 1.9, maxHp: 200, turnRate: 0.55 };
    case "battleship": return { maxSpeed: 1.35, maxHp: 420, turnRate: 0.32 };
    case "sub": return { maxSpeed: 1.7, maxHp: 260, turnRate: 0.7 };
    default: return { maxSpeed: 1.8, maxHp: 100, turnRate: 0.6 };
  }
}

function buildPatrolRoute(terrain, x, y, cls) {
  const route = [];
  const n = cls === "freighter" ? 4 : 5;
  const rad = cls === "freighter" ? 10 : 7 + Math.random() * 5;
  const base = Math.random() * Math.PI * 2;
  for (let i = 0; i < n; i++) {
    const a = base + (i / n) * Math.PI * 2;
    let px = clamp(x + Math.cos(a) * rad, 3, WORLD_SIZE - 4);
    let py = clamp(y + Math.sin(a) * rad * 0.85, 3, WORLD_SIZE - 4);
    if (!isShipNavigable(terrain, px, py)) {
      const o = pickOpenWaterNear(px, py);
      px = o.x; py = o.y;
    }
    route.push({ x: px, y: py });
  }
  return route;
}

function spawnShip(state, cls, x, y, terrain) {
  const s = shipStats(cls);
  let name = SHIP_NAMES[Math.floor(Math.random() * SHIP_NAMES.length)];
  if (cls === "battleship") name = BATTLESHIP_NAMES[Math.floor(Math.random() * BATTLESHIP_NAMES.length)];
  if (cls === "sub") name = ENEMY_SUB_NAMES[Math.floor(Math.random() * ENEMY_SUB_NAMES.length)];
  const heading = Math.random() * Math.PI * 2;
  const hpMul = cls === "sub" ? 1.35 : 1;
  return {
    id: uid(state), class: cls, x, y, heading, displayHeading: heading,
    speed: 0, maxSpeed: s.maxSpeed * (cls === "sub" ? 0.95 : 1),
    hp: s.maxHp * hpMul, maxHp: s.maxHp * hpMul,
    sinking: 0, alert: 0, fireCooldown: 3 + Math.random() * 3,
    patrolAngle: Math.random() * Math.PI * 2, dead: false, name, trailTimer: 0,
    turnRate: s.turnRate, patrolRoute: buildPatrolRoute(terrain, x, y, cls),
    patrolIndex: 0, patrolDir: 1, patrolLoop: cls !== "freighter",
    path: [], repathTimer: 0, holdContact: 0, role: "hunter", convoyId: 0,
  };
}

function findShipSpawn(terrain, preferX, preferY, minDistFrom, minClear = 5) {
  for (let attempt = 0; attempt < 48; attempt++) {
    const ang = Math.random() * Math.PI * 2;
    const rad = attempt < 12 ? Math.random() * 4 : 2 + Math.random() * 22;
    const x = clamp(preferX + Math.cos(ang) * rad, 3, WORLD_SIZE - 4);
    const y = clamp(preferY + Math.sin(ang) * rad, 3, WORLD_SIZE - 4);
    if (dist(x, y, minDistFrom.x, minDistFrom.y) < minClear) continue;
    if (isShipNavigable(terrain, x, y)) return { x, y };
  }
  return pickOpenWaterNear(preferX, preferY);
}

export function snapToNavigable(terrain, x, y, depth) {
  const cx = clamp(x, 1, WORLD_SIZE - 2);
  const cy = clamp(y, 1, WORLD_SIZE - 2);
  if (isNavigable(terrain, cx, cy, depth) && !isLand(terrain, cx, cy)) return { x: cx, y: cy };
  for (let r = 1; r <= 12; r++) {
    for (let i = 0; i < 16; i++) {
      const a = (i / 16) * Math.PI * 2;
      const nx = clamp(cx + Math.cos(a) * r, 1, WORLD_SIZE - 2);
      const ny = clamp(cy + Math.sin(a) * r, 1, WORLD_SIZE - 2);
      if (isNavigable(terrain, nx, ny, depth)) return { x: nx, y: ny };
    }
  }
  return { x: WORLD_SIZE / 2, y: WORLD_SIZE / 2 + 4 };
}

function placeNavalBase(terrain, seed) {
  const rng = ((seed * 1103515245 + 12345) >>> 0) / 0xffffffff;
  const ang = rng * Math.PI * 2;
  const r = 10 + (seed % 7);
  let x = WORLD_SIZE * 0.45 + Math.cos(ang) * r;
  let y = WORLD_SIZE * 0.55 + Math.sin(ang) * r;
  const p = snapToNavigable(terrain, x, y, 0.2);
  return { x: p.x, y: p.y, radius: 4.2, name: "FOB Argus" };
}

const POWER_KINDS = ["health", "ammo", "hull", "weapon", "speed", "counter"];

function spawnPowerup(state, terrain, kind) {
  const o = openWater[Math.floor(Math.random() * Math.max(1, openWater.length))] || { x: 20, y: 20 };
  state.powerups.push({
    id: uid(state), x: o.x, y: o.y,
    kind: kind || POWER_KINDS[Math.floor(Math.random() * POWER_KINDS.length)],
    pulse: Math.random() * Math.PI * 2, age: 0, life: 90 + Math.random() * 40,
  });
}

function seedPowerups(state, terrain, n) {
  for (let i = 0; i < n; i++) spawnPowerup(state, terrain);
}

function seedWave(state, terrain, wave) {
  const cx = state.sub.x, cy = state.sub.y;
  const convoyId = wave * 10 + 1;
  const convoyN = 2 + Math.min(3, wave);
  const laneAng = Math.random() * Math.PI * 2;
  const laneDist = 14 + Math.random() * 10;
  const baseX = clamp(cx + Math.cos(laneAng) * laneDist, 8, WORLD_SIZE - 9);
  const baseY = clamp(cy + Math.sin(laneAng) * laneDist, 8, WORLD_SIZE - 9);
  const heading = laneAng + Math.PI / 2;
  const merchants = [];
  for (let i = 0; i < convoyN; i++) {
    const ox = Math.cos(heading) * (i * 2.8 - convoyN);
    const oy = Math.sin(heading) * (i * 2.8 - convoyN);
    const pos = findShipSpawn(terrain, baseX + ox, baseY + oy, { x: cx, y: cy }, 4);
    const ship = spawnShip(state, "freighter", pos.x, pos.y, terrain);
    ship.heading = heading; ship.displayHeading = heading;
    ship.convoyId = convoyId; ship.role = "merchant";
    state.ships.push(ship); merchants.push(ship);
  }
  const screenN = 2 + Math.min(3, wave);
  const screenClasses = ["destroyer", "patrol", "destroyer", "patrol", "cruiser"];
  for (let i = 0; i < screenN; i++) {
    const lead = merchants[i % merchants.length];
    const off = convoyScreenOffset(i, screenN, heading);
    const pos = findShipSpawn(terrain, lead.x + off.x, lead.y + off.y, { x: cx, y: cy }, 4);
    const cls = wave >= 3 && i === 0 ? "destroyer" : screenClasses[i % screenClasses.length];
    const ship = spawnShip(state, cls, pos.x, pos.y, terrain);
    ship.heading = heading; ship.displayHeading = heading;
    ship.convoyId = convoyId; ship.role = "screen";
    state.ships.push(ship);
  }
  if (wave >= 2) {
    const ang = Math.random() * Math.PI * 2;
    const pos = findShipSpawn(terrain, cx + Math.cos(ang) * 18, cy + Math.sin(ang) * 18, { x: cx, y: cy }, 8);
    const bb = spawnShip(state, "battleship", pos.x, pos.y, terrain);
    bb.role = "hunter";
    state.ships.push(bb);
  }
  const subN = wave >= 3 ? 2 : 1;
  for (let i = 0; i < subN; i++) {
    const ang = Math.random() * Math.PI * 2;
    const pos = findShipSpawn(terrain, cx + Math.cos(ang) * 14, cy + Math.sin(ang) * 14, { x: cx, y: cy }, 7);
    const sub = spawnShip(state, "sub", pos.x, pos.y, terrain);
    sub.role = "hunter";
    state.ships.push(sub);
  }
}

export function createGame(seed = Date.now() % 1e9): {
  state: GameState;
  terrain: TerrainCell[][];
} {
  const terrain = generateTerrain(seed);
  rebuildOpenWater(terrain);
  const subStart = snapToNavigable(terrain, WORLD_SIZE / 2, WORLD_SIZE / 2 + 4, 0.45);
  const state = {
    phase: "menu" as const,
    sub: {
      x: subStart.x, y: subStart.y, z: 0.45, heading: -Math.PI / 2, displayHeading: -Math.PI / 2,
      bank: 0, speed: 0, targetSpeed: 0, speedOrder: 0, maxSpeed: 2.4,
      hp: 100, maxHp: 100, torpedoes: 8, maxTorpedoes: 8, seekers: 4, maxSeekers: 4,
      reload: 0, reloadMk14: 0, reloadMk18: 0, reloadMk14Max: 2.4, reloadMk18Max: 3.2,
      decoys: 3, cmCharges: 3, maxCmCharges: 3, cmCooldown: 0, noise: 0.12,
      waypoint: null, targetDepth: 0.45, ballast: 0.45, invuln: 0, trailTimer: 0,
      hullTier: 0, weaponTier: 0, speedTier: 0, docked: 0,
      battery: 100, maxBattery: 100, silentRunning: false, scopeUp: false, snorkel: false,
      sysSonar: 1, sysPropulsion: 1, sysTubes: 1, sysFlood: 0, crewStress: 0,
    },
    ships: [], torpedoes: [], depthCharges: [], countermeasures: [], powerups: [],
    base: { x: subStart.x, y: subStart.y, radius: 4.2, name: "FOB Argus" },
    particles: [], impacts: [], floats: [], sonarContacts: [],
    camera: { x: subStart.x, y: subStart.y, zoom: 1.05, shake: 0, targetX: subStart.x, targetY: subStart.y, follow: true, followTimer: 0 },
    stats: { score: 0, shipsSunk: 0, torpedoesFired: 0, damageDealt: 0, timeSurvived: 0, wave: 1, powerupsTaken: 0, repairs: 0 },
    weapon: "torpedo" as WeaponMode, selectedTarget: null, hoverWorld: null, seed, nextId: 1,

    message: "Click course. Target a ship, then Ambush — or helm yourself.",
    messageLife: 6, gameOverReason: "", sonarPing: 0, sonarActiveCooldown: 0, sonarSweep: 0,
    time: 0, victoryTarget: 8, muted: false, debugFacing: false, powerupSpawnTimer: 12,
    timeOfDay: 0.15 + Math.random() * 0.1, seaState: 0.3, missionType: "patrol",
    aircraft: { x: 0, y: 0, heading: 0, life: 0, cooldown: 30 },
    torpedoSpread: false, autopilot: createAutopilot(),
  };
  state.base = placeNavalBase(terrain, seed);
  const near = snapToNavigable(terrain, state.base.x + 2.5, state.base.y + 1.5, 0.45);
  state.sub.x = near.x; state.sub.y = near.y;
  state.camera.x = near.x; state.camera.y = near.y;
  state.camera.targetX = near.x; state.camera.targetY = near.y;
  seedPowerups(state, terrain, 7);
  seedWave(state, terrain, 1);
  return { state, terrain };
}

export function startMission(state) {
  state.phase = "playing";
  const missions = ["patrol", "ambush", "exfil", "hunter"];
  state.missionType = missions[Math.floor(Math.random() * missions.length)];
  if (state.missionType === "exfil") {
    state.sub.hp = Math.min(state.sub.hp, 55);
    state.sub.battery = 35;
    state.message = "EXFIL: damaged — reach FOB Argus.";
  } else if (state.missionType === "ambush") {
    state.timeOfDay = 0.05;
    state.message = "AMBUSH: night transit. Silent recommended.";
  } else {
    state.message = "PATROL: target a ship → Ambush, or helm manually. Off / click sea to cancel AI.";
  }
  state.messageLife = 5.5;
  audio.unlockAudio();
  audio.sfxSonar();
}

export function restartGame(bundle) {
  const keepMuted = bundle.state.muted;
  const keepDebug = bundle.state.debugFacing;
  const next = createGame(Date.now() % 1e9);
  Object.assign(bundle.state, next.state);
  bundle.state.muted = keepMuted;
  bundle.state.debugFacing = keepDebug;
  bundle.terrain.splice(0, bundle.terrain.length, ...next.terrain);
  rebuildOpenWater(bundle.terrain);
  startMission(bundle.state);
}

export function setPhase(state, phase) { state.phase = phase; }
export function setWeapon(state, w) { state.weapon = w; audio.sfxClick(); }
export function toggleDebugFacing(state) {
  state.debugFacing = !state.debugFacing;
  state.message = state.debugFacing ? "Facing debug ON." : "Facing debug OFF.";
  state.messageLife = 2;
  audio.sfxClick();
}

export function setDepthOrder(state, depth) {
  state.sub.targetDepth = clamp(depth, 0, 0.95);
  audio.sfxClick();
  if (depth < 0.15) state.message = "Surfacing — exposed to deck guns.";
  else if (depth < 0.4) state.message = "Periscope depth.";
  else if (depth < 0.7) state.message = "Attack depth.";
  else state.message = "Deep dive.";
  state.messageLife = 2.5;
}

export function setSpeedOrder(state, speed) {
  const max = Math.max(0.2, state.sub.maxSpeed || 2.4);
  state.sub.speedOrder = clamp(speed / max, 0, 1);
  applySpeedCaps(state.sub);
  audio.sfxClick();
}

export function toggleSilentRunning(state) {
  if (state.phase !== "playing") return;
  state.sub.silentRunning = !state.sub.silentRunning;
  if (state.sub.silentRunning) {
    state.sub.scopeUp = false;
    state.message = "Silent running.";
  } else state.message = "All systems normal.";
  applySpeedCaps(state.sub);
  state.messageLife = 2;
  audio.sfxClick();
}

export function toggleScope(state) {
  if (state.phase !== "playing") return;
  if (state.sub.z > 0.45) {
    state.message = "Rise to periscope depth to raise the scope.";
    state.messageLife = 2;
    return;
  }
  state.sub.scopeUp = !state.sub.scopeUp;
  if (state.sub.scopeUp) {
    state.sub.snorkel = false;
    state.message = "Periscope up.";
  } else state.message = "Periscope housed.";
  state.messageLife = 2;
  audio.sfxClick();
}

export function toggleSnorkel(state) {
  if (state.phase !== "playing") return;
  if (state.sub.z < 0.12 || state.sub.z > 0.42) {
    state.message = "Snorkel only near periscope depth.";
    state.messageLife = 2;
    return;
  }
  state.sub.snorkel = !state.sub.snorkel;
  if (state.sub.snorkel) {
    state.sub.scopeUp = false;
    state.sub.silentRunning = false;
    state.message = "Snorkel — charging, noisy.";
  } else state.message = "Snorkel secured.";
  applySpeedCaps(state.sub);
  state.messageLife = 2;
  audio.sfxClick();
}

export function toggleTorpedoSpread(state) {
  state.torpedoSpread = !state.torpedoSpread;
  state.message = state.torpedoSpread ? "Tube mode: SPREAD." : "Tube mode: SINGLE.";
  state.messageLife = 2;
  audio.sfxClick();
}

export function setAutopilot(state, tactic, targetId) {
  if (state.phase !== "playing") return;
  engageAutopilot(state, tactic, targetId);
  audio.sfxClick();
}

export function cancelAutopilot(state) {
  disengageAutopilot(state);
  audio.sfxClick();
}

export function orderMove(state, x, y, terrain) {
  if (state.phase !== "playing") return;
  let wx = clamp(x, 1, WORLD_SIZE - 2);
  let wy = clamp(y, 1, WORLD_SIZE - 2);
  if (terrain) {
    const snapped = snapToNavigable(terrain, wx, wy, state.sub.z);
    if (isLand(terrain, wx, wy) || !isNavigable(terrain, wx, wy, state.sub.z)) {
      wx = snapped.x; wy = snapped.y;
      state.message = "Course adjusted around shoals.";
    } else state.message = "Helm answering — new course.";
    state.messageLife = 2;
  }
  state.sub.waypoint = { x: wx, y: wy };
  state.sub.path = [];
  state.sub.repathTimer = 0;
  if ((state.sub.speedOrder ?? 0) < 0.15) {
    state.sub.speedOrder = DEFAULT_CRUISE / Math.max(0.2, state.sub.maxSpeed);
  }
  applySpeedCaps(state.sub);
  if (state.autopilot?.enabled) {
    disengageAutopilot(state);
    state.message = "Course plotted — autopilot off.";
    state.messageLife = 2;
  }
  state.camera.follow = true;
  audio.sfxClick();
}

export function selectTarget(state, id) {
  if (id != null && state.selectedTarget === id) id = null;
  state.selectedTarget = id;
  if (state.autopilot) state.autopilot.targetId = id;
  if (id != null) {
    const ship = state.ships.find((s) => s.id === id);
    if (ship) {
      state.message = `Target locked: ${ship.name}`;
      state.messageLife = 2;
      audio.sfxClick();
    }
  } else {
    if (
      state.autopilot?.enabled &&
      ["ambush", "stalk", "intercept"].includes(state.autopilot.tactic)
    ) {
      disengageAutopilot(state);
      state.sub.waypoint = null;
      state.sub.path = [];
      state.message = "Target cleared — AI off. Helm is yours.";
    } else {
      state.message = "Target cleared.";
    }
    state.messageLife = 2.5;
    audio.sfxClick();
  }
}

export function clearEngagement(state) {
  state.selectedTarget = null;
  if (state.autopilot) {
    state.autopilot.targetId = null;
    if (state.autopilot.enabled && state.autopilot.tactic !== "exfil") {
      disengageAutopilot(state);
    }
  }
  state.sub.waypoint = null;
  state.sub.path = [];
  state.sub.speedOrder = 0;
  applySpeedCaps(state.sub);
  state.message = "Engagement broken — all stop, manual helm.";
  state.messageLife = 2.5;
  audio.sfxClick();
}

export function detachCamera(state) {
  state.camera.follow = false;
  state.camera.followTimer = 4;
}

function isAtFob(state) {
  if (!state.base) return false;
  return dist(state.sub.x, state.sub.y, state.base.x, state.base.y) < state.base.radius;
}

function spawnParticles(state, x, y, z, kind, n, color, size = 1) {
  for (let i = 0; i < n; i++) {
    state.particles.push({
      x: x + (Math.random() - 0.5) * 0.4,
      y: y + (Math.random() - 0.5) * 0.4,
      z, vx: (Math.random() - 0.5) * 2, vy: (Math.random() - 0.5) * 2, vz: Math.random() * 0.5,
      life: 0.4 + Math.random() * 0.6, maxLife: 1, size, color, kind,
    });
  }
}

function spawnImpact(state, x, y, z, kind, radius, color) {
  const life =
    kind === "hit"
      ? 0.55
      : kind === "shock"
        ? 0.9
        : kind === "boom"
          ? 1.05
          : kind === "pickup"
            ? 0.7
            : 0.55;
  state.impacts.push({ x, y, z, life, maxLife: life, radius, color, kind });
}

function impactHitFx(state, x, y, z, color) {
  spawnImpact(state, x, y, z, "hit", 1.45, color);
  spawnImpact(state, x, y, z, "shock", 1.1, color);
  spawnParticles(state, x, y, z, "spark", 10, color);
  spawnParticles(state, x, y, z, "ember", 6, color);
  spawnParticles(state, x, y, z, "flash", 3, "#ffffff", 1.6);
  audio.sfxAnimeImpact(1);
}

function explode(state, x, y, z, n, opts = {}) {
  const big = !!opts.big;
  const scale = big ? 1.45 : 1;
  spawnParticles(state, x, y, z, "flash", big ? 8 : 5, "#ffe8a0", 2.2 * scale);
  spawnParticles(state, x, y, z, "spark", Math.floor((n + 10) * scale), "#ffb070");
  spawnParticles(state, x, y, z, "ember", Math.floor(10 * scale), "#ff6030");
  spawnParticles(state, x, y, z, "smoke", Math.floor(8 * scale), "#6a7080", 1.4);
  spawnParticles(state, x, y, z, "debris", Math.floor(6 * scale), "#c4a882");
  spawnParticles(state, x, y, z, "bubble", Math.floor((n / 2 + 6) * scale), "#9ad4ff");
  spawnParticles(state, x, y, z, "splash", Math.floor(6 * scale), "#c8e8ff", 1.2);
  spawnImpact(state, x, y, z, "boom", 3.2 * scale, "#ff9a50");
  spawnImpact(state, x, y, z, "shock", 2.8 * scale, "#ffb080");
  spawnImpact(state, x, y, z, "hit", 2.0 * scale, "#fff0c0");
  state.camera.shake = Math.max(state.camera.shake, big ? 0.85 : 0.55);
  // Full explosion stack: boom body + anime punch
  audio.sfxExplosion();
  audio.sfxAnimeImpact(big ? 1.25 : 1.0);
  if (big) audio.sfxSecondaryBoom();
}

function damageSub(state, dmg, reason) {
  if (state.sub.invuln > 0 || state.phase !== "playing") return;
  if (isAtFob(state) || state.sub.docked > 0) return;
  dmg *= 1 - Math.min(0.28, (state.sub.hullTier || 0) * 0.08);
  state.sub.hp -= dmg;
  state.sub.crewStress = Math.min(1, (state.sub.crewStress || 0) + dmg * 0.012);
  const sysMsg = damageSystems(state.sub, dmg);
  if (sysMsg && state.messageLife < 1.2) {
    state.message = sysMsg + ".";
    state.messageLife = 2.5;
  }
  state.camera.shake = Math.max(state.camera.shake, 0.55);
  audio.sfxHit();
  impactHitFx(state, state.sub.x, state.sub.y, state.sub.z, "#f07178");
  if (state.sub.hp <= 0) {
    state.sub.hp = 0;
    state.phase = "gameover";
    state.gameOverReason = reason;
    explode(state, state.sub.x, state.sub.y, state.sub.z, 36, { big: true });
    audio.sfxGameOver();
  } else if (state.sub.hp < 35) audio.sfxAlarm();
}

function damageShip(state, ship, dmg) {
  if (ship.dead || ship.sinking > 0) return;
  ship.hp -= dmg;
  state.stats.damageDealt += dmg;
  ship.alert = 1;
  impactHitFx(state, ship.x, ship.y, ship.class === "sub" ? 0.3 : 0, "#ffd080");
  if (ship.hp <= 0) {
    ship.hp = 0;
    ship.sinking = 0.01;
    state.stats.shipsSunk++;
    state.stats.score += ship.class === "battleship" ? 700 : ship.class === "sub" ? 550 : ship.class === "cruiser" ? 400 : ship.class === "destroyer" ? 300 : 150;
    explode(state, ship.x, ship.y, ship.class === "sub" ? 0.3 : 0, 28, {
      big: ship.class === "battleship" || ship.class === "cruiser" || ship.class === "sub",
    });
    state.floats.push({ x: ship.x, y: ship.y, text: "SUNK", life: 1.6, color: "#f07178", vy: -0.5 });
  }
}

function spawnCountermeasure(state, kind, x, y, z) {
  state.countermeasures.push({
    id: uid(state), x, y, z, life: kind === "foxer" ? 14 : 10, maxLife: kind === "foxer" ? 14 : 10,
    radius: kind === "foxer" ? 3.5 : 4.5, kind, strength: 1,
  });
}

export function deployCountermeasure(state) {
  if (state.phase !== "playing") return;
  const boat = state.sub;
  if (boat.cmCooldown > 0 || boat.cmCharges <= 0) {
    state.message = boat.cmCharges <= 0 ? "No bubble charges." : `CM reload ${Math.max(1, Math.ceil(boat.cmCooldown))}s`;

    state.messageLife = 1.5;
    return;
  }
  boat.cmCharges--;
  boat.cmCooldown = 6;
  spawnCountermeasure(state, "bubble", boat.x, boat.y, clamp(boat.z, 0.1, 0.8));
  spawnParticles(state, boat.x, boat.y, boat.z, "bubble", 16, "#9ad4ff");
  audio.sfxBubbleScreen();
  state.message = "Bubble screen deployed.";
  state.messageLife = 2;
}

export function fireWeapon(state, aimX, aimY) {
  if (state.phase !== "playing") return;
  const boat = state.sub;
  if (state.weapon === "decoy") {
    if (boat.decoys <= 0) { state.message = "No decoys."; state.messageLife = 2; return; }
    boat.decoys--;
    const fx = boat.x + Math.cos(boat.heading) * 2;
    const fy = boat.y + Math.sin(boat.heading) * 2;
    spawnCountermeasure(state, "foxer", fx, fy, clamp(boat.z + 0.05, 0.1, 0.7));
    for (const ship of state.ships) {
      if (!ship.dead && dist(ship.x, ship.y, boat.x, boat.y) < 20) ship.alert = Math.max(0, ship.alert - 0.6);
    }
    state.message = "Foxer deployed.";
    state.messageLife = 2;
    audio.sfxFoxer();
    return;
  }
  const seeking = state.weapon === "seeker";
  if (seeking) {
    if (boat.seekers <= 0 || boat.reloadMk18 > 0) {
      state.message = boat.seekers <= 0 ? "No seekers." : `Mk-18 reload ${Math.max(1, Math.ceil(boat.reloadMk18))}s`;

      state.messageLife = 1.5;
      return;
    }
  } else if (boat.torpedoes <= 0 || boat.reloadMk14 > 0) {
    state.message = boat.torpedoes <= 0 ? "Torpedo room empty." : `Mk-14 reload ${Math.max(1, Math.ceil(boat.reloadMk14))}s`;

    state.messageLife = 1.5;
    return;
  }
  if ((boat.sysTubes || 1) < 0.35) { state.message = "Tubes jammed."; state.messageLife = 2; return; }
  if (boat.z < 0.08 || boat.z > 0.85) {
    state.message = boat.z < 0.08 ? "Too shallow for tubes." : "Too deep for clean shot.";
    state.messageLife = 2;
    return;
  }
  let targetId = state.selectedTarget;
  if (targetId == null) {
    let best = Infinity;
    for (const ship of state.ships) {
      if (ship.dead || ship.sinking > 0) continue;
      const d = dist2(aimX, aimY, ship.x, ship.y);
      if (d < best && d < 36) { best = d; targetId = ship.id; }
    }
  }
  const heading = Math.atan2(aimY - boat.y, aimX - boat.x);
  const dmgMul = 1 + (boat.weaponTier || 0) * 0.18;
  const tubeFactor = 0.7 + (boat.sysTubes || 1) * 0.3;
  const spawnOne = (h, seek, tid) => {
    const sp = seek ? 8.2 : 9.5;
    state.torpedoes.push({
      id: uid(state), x: boat.x + Math.cos(h) * 0.8, y: boat.y + Math.sin(h) * 0.8,
      z: clamp(boat.z, 0.15, 0.55), vx: Math.cos(h) * sp, vy: Math.sin(h) * sp, heading: h,
      targetId: seek || tid != null ? tid : null, life: seek ? 10 : 8, owner: "player",
      damage: (seek ? 58 : 48) * dmgMul * tubeFactor, armed: false, seeking: seek, trailTimer: 0,
    });
  };
  if (seeking) {
    boat.seekers--;
    spawnOne(heading, true, targetId);
    boat.reloadMk18 = Math.max(1.4, 3.4 - (boat.weaponTier || 0) * 0.22);
    boat.reloadMk18Max = boat.reloadMk18;
    audio.sfxSeekerLock();
    state.message = "Seeker away.";
  } else {
    const spread = state.torpedoSpread && boat.torpedoes >= 2;
    const n = spread ? Math.min(3, boat.torpedoes) : 1;
    const offsets = n === 1 ? [0] : n === 2 ? [-0.08, 0.08] : [-0.12, 0, 0.12];
    for (let i = 0; i < n; i++) { boat.torpedoes--; spawnOne(heading + offsets[i], false, targetId); }
    boat.reloadMk14 = Math.max(1.4, (spread ? 3.8 : 2.5) - (boat.weaponTier || 0) * 0.22);
    boat.reloadMk14Max = boat.reloadMk14;
    audio.sfxTorpedo();
    state.message = spread ? `Spread away — ${n} fish.` : "Torpedo away.";
  }
  boat.reload = Math.max(boat.reloadMk14, boat.reloadMk18);
  boat.noise = Math.min(1, boat.noise + 0.35);
  applySpeedCaps(boat);
  state.stats.torpedoesFired++;
  state.messageLife = 2;
}

export function sonarPulse(state) {
  if (state.phase !== "playing") return;
  if (state.sonarActiveCooldown > 0) {
    state.message = `Sonar recycle ${Math.max(1, Math.ceil(state.sonarActiveCooldown))}s`;

    state.messageLife = 1.4;
    return;
  }
  if (!fireActiveSonar(state)) return;
  audio.sfxSonar();
  for (const ship of state.ships) {
    if (ship.dead) continue;
    const d = dist(ship.x, ship.y, state.sub.x, state.sub.y);
    if (d < 30) ship.alert = Math.min(1, ship.alert + 0.35 * (1 - d / 30));
  }
  state.message = "Active sonar ping.";
  state.messageLife = 1.5;
}

function ejectDepthCharge(state, ship, tx, ty, tz) {
  const ang = Math.atan2(ty - ship.y, tx - ship.x);
  const dropR = 2 + Math.random();
  state.depthCharges.push({
    id: uid(state),
    x: ship.x + Math.cos(ang) * dropR + (Math.random() - 0.5) * 0.6,
    y: ship.y + Math.sin(ang) * dropR + (Math.random() - 0.5) * 0.6,
    z: 0.05, vz: 1.4 + Math.random() * 0.5,
    fuse: 1.2 + Math.random() * 0.6 + tz * 0.8,
    radius: 2.2, damage: 38 + Math.random() * 14,
    divertX: null, divertY: null, diverted: false,
    setDepth: clamp(tz + (Math.random() - 0.5) * 0.1, 0.15, 0.9),
  });
}

function updateBaseAndPowerups(state, terrain, dt) {
  const boat = state.sub;
  if (isAtFob(state)) {
    boat.docked = 0.5;
    if (boat.speed < 0.6) {
      boat.hp = Math.min(boat.maxHp, boat.hp + 12 * dt);
      boat.battery = Math.min(boat.maxBattery, boat.battery + 18 * dt);
      boat.torpedoes = Math.min(boat.maxTorpedoes, boat.torpedoes + 0.35 * dt);
      boat.seekers = Math.min(boat.maxSeekers, boat.seekers + 0.2 * dt);
      if (Math.random() < dt * 0.15) {
        boat.decoys = Math.min(3, boat.decoys + 1);
        boat.cmCharges = Math.min(boat.maxCmCharges, boat.cmCharges + 1);
      }
      boat.sysFlood = Math.max(0, boat.sysFlood - dt * 0.3);
      boat.sysSonar = Math.min(1, boat.sysSonar + dt * 0.15);
      boat.sysPropulsion = Math.min(1, boat.sysPropulsion + dt * 0.12);
      boat.sysTubes = Math.min(1, boat.sysTubes + dt * 0.18);
      state.stats.repairs += dt;
    }
  } else boat.docked = Math.max(0, boat.docked - dt);

  for (const p of state.powerups) {
    p.age += dt; p.pulse += dt * 3; p.life -= dt;
    if (dist(p.x, p.y, boat.x, boat.y) < 1.3) {
      applyPowerup(state, p.kind);
      p.life = -1;
      state.stats.powerupsTaken++;
      spawnImpact(state, p.x, p.y, 0, "pickup", 1.6, "#a0e8ff");
      audio.sfxPowerup();
    }
  }
  state.powerups = state.powerups.filter((p) => p.life > 0);
  state.powerupSpawnTimer -= dt;
  if (state.powerupSpawnTimer <= 0 && state.powerups.length < 10) {
    spawnPowerup(state, terrain);
    state.powerupSpawnTimer = 14 + Math.random() * 10;
  }
}

function applyPowerup(state, kind) {
  const boat = state.sub;
  switch (kind) {
    case "health":
      boat.hp = Math.min(boat.maxHp, boat.hp + 35);
      state.message = "Hull patched +35.";
      break;
    case "ammo":
      boat.torpedoes = boat.maxTorpedoes;
      boat.seekers = Math.min(boat.maxSeekers, boat.seekers + 2);
      state.message = "Magazine restocked.";
      break;
    case "hull":
      boat.hullTier = Math.min(3, boat.hullTier + 1);
      boat.maxHp += 20; boat.hp = Math.min(boat.maxHp, boat.hp + 20);
      state.message = `Hull upgrade Mk-${boat.hullTier}.`;
      break;
    case "weapon":
      boat.weaponTier = Math.min(3, boat.weaponTier + 1);
      state.message = `Warhead kit Mk-${boat.weaponTier}.`;
      break;
    case "speed":
      boat.speedTier = Math.min(3, boat.speedTier + 1);
      boat.maxSpeed += 0.18;
      state.message = `Engine upgrade Mk-${boat.speedTier}.`;
      break;
    case "counter":
      boat.cmCharges = boat.maxCmCharges;
      boat.decoys = 3;
      state.message = "Countermeasures restocked.";
      break;
  }
  state.messageLife = 2.5;
}

function updateSub(state, terrain, dt) {
  const boat = state.sub;
  const clear = floorClearance(terrain, boat.x, boat.y);
  const desired = Math.min(boat.targetDepth, clear - 0.02);
  boat.ballast = lerp(boat.ballast, desired, 1 - Math.exp(-1.8 * dt));
  boat.z = boat.ballast;
  if (boat.z > clear) {
    boat.z = clear;
    damageSub(state, 18 * dt, "Hull crushed against the seamount.");
  }
  if (isLand(terrain, boat.x, boat.y)) {
    const safe = snapToNavigable(terrain, boat.x, boat.y, boat.z);
    boat.x = safe.x; boat.y = safe.y; boat.speed *= 0.3; boat.waypoint = null;
  }
  const open = makeSubClear(terrain, boat.z);
  if (!boat.path) boat.path = [];
  if (boat.repathTimer == null) boat.repathTimer = 0;
  if (boat.repathTimer > 0) boat.repathTimer -= dt;

  // Manual helm follows waypoints; autopilot owns heading via updateAutopilot
  // but we still integrate motion from heading + speed either way.
  if (boat.waypoint && !state.autopilot?.enabled) {
    if (!open(boat.waypoint.x, boat.waypoint.y)) {
      const s = snapToNavigable(terrain, boat.waypoint.x, boat.waypoint.y, boat.z);
      boat.waypoint = { x: s.x, y: s.y };
      boat.path = [];
    }
    const goal = boat.waypoint;
    if (dist(boat.x, boat.y, goal.x, goal.y) < 0.5) {
      boat.waypoint = null;
      boat.path = [];
    } else {
      let path = boat.path;
      if ((!path.length || !lineClear(boat.x, boat.y, path[0].x, path[0].y, open, 0.7)) && boat.repathTimer <= 0) {
        path = findPath({ x: boat.x, y: boat.y }, goal, open, 700);
        boat.path = path;
        boat.repathTimer = 0.9;
      }
      const follow = followPath(boat.x, boat.y, path, 0.95);
      boat.path = follow.path;
      let desiredHeading = follow.heading != null ? follow.heading : Math.atan2(goal.y - boat.y, goal.x - boat.x);
      desiredHeading = steerAvoid(boat.x, boat.y, desiredHeading, 2.2, open, { rays: 13 });
      boat.heading += clamp(angleDiff(boat.heading, desiredHeading), -1.55 * dt, 1.55 * dt);
    }
  }

  boat.bank = lerp(boat.bank, clamp(angleDiff(boat.displayHeading, boat.heading) * 1.8, -0.7, 0.7), 1 - Math.exp(-5 * dt));
  boat.displayHeading += angleDiff(boat.displayHeading, boat.heading) * (1 - Math.exp(-14 * dt));

  updateBattery(boat, dt, state.seaState || 0.3);
  applySpeedCaps(boat);
  tickSystems(boat, dt, boat.docked > 0 || isAtFob(state));

  const depthFactor = boat.z < 0.2 ? 1.05 : boat.z > 0.7 ? 0.72 : 0.9;
  boat.speed = lerp(boat.speed, Math.min(boat.targetSpeed, boat.maxSpeed * depthFactor), 1 - Math.exp(-2 * dt));

  let nx = boat.x + Math.cos(boat.heading) * boat.speed * dt;
  let ny = boat.y + Math.sin(boat.heading) * boat.speed * dt;
  if (open(nx, ny)) { boat.x = nx; boat.y = ny; }
  else {
    boat.heading = steerAvoid(boat.x, boat.y, boat.heading, 2.2, open, { rays: 15 });
    nx = boat.x + Math.cos(boat.heading) * boat.speed * dt * 0.85;
    ny = boat.y + Math.sin(boat.heading) * boat.speed * dt * 0.85;
    if (open(nx, ny)) { boat.x = nx; boat.y = ny; }
    else if (open(nx, boat.y)) boat.x = nx;
    else if (open(boat.x, ny)) boat.y = ny;
    else boat.speed *= 0.35;
  }

  const speedNoise = (boat.speed / Math.max(0.2, boat.maxSpeed)) * 0.55;
  const depthQuiet = boat.z > THERMOCLINE + 0.08 ? 0.28 : boat.z < 0.15 ? 0.95 : 0.55;
  let targetNoise = clamp(speedNoise * depthQuiet, 0.05, 1);
  if (boat.silentRunning) targetNoise = Math.min(targetNoise, 0.16);
  boat.noise = lerp(boat.noise, targetNoise, 1 - Math.exp(-1.2 * dt));
  boat.noise = applySystemsNoise(boat);

  if (boat.reloadMk14 > 0) boat.reloadMk14 = Math.max(0, boat.reloadMk14 - dt);
  if (boat.reloadMk18 > 0) boat.reloadMk18 = Math.max(0, boat.reloadMk18 - dt);
  boat.reload = Math.max(boat.reloadMk14 || 0, boat.reloadMk18 || 0);
  if (boat.invuln > 0) boat.invuln = Math.max(0, boat.invuln - dt);
  if (boat.cmCooldown > 0) boat.cmCooldown = Math.max(0, boat.cmCooldown - dt);
  if (boat.crewStress > 0) boat.crewStress = Math.max(0, boat.crewStress - dt * 0.02);

  boat.trailTimer -= dt;
  if (boat.speed > 0.6 && boat.trailTimer <= 0) {
    boat.trailTimer = 0.12;
    spawnParticles(state, boat.x - Math.cos(boat.heading) * 0.5, boat.y - Math.sin(boat.heading) * 0.5, boat.z, boat.z < 0.12 ? "wake" : "trail", 1, boat.z < 0.12 ? "#cfe9ff" : "#7eb6e8");
  }
  if (boat.speed > 0.4) {
    audio.sfxEnginePulse(clamp(boat.speed / Math.max(0.2, boat.maxSpeed), 0, 1));
  }
  if (state.camera.follow) {
    state.camera.targetX = boat.x;
    state.camera.targetY = boat.y;
  } else if (state.camera.followTimer > 0) {
    state.camera.followTimer -= dt;
    if (state.camera.followTimer <= 0) state.camera.follow = true;
  }
}

function updateShips(state, terrain, dt, contacts) {
  const boat = state.sub;
  const clearCache = new Map();
  const clearFor = (cls) => {
    if (!clearCache.has(cls)) clearCache.set(cls, makeShipClear(terrain, cls === "sub" ? 0.9 : 1.1));
    return clearCache.get(cls);
  };

  for (const ship of state.ships) {
    if (ship.dead) continue;
    if (ship.sinking > 0) {
      ship.sinking += dt;
      ship.speed *= 0.9;
      if (ship.sinking > 3) ship.dead = true;
      continue;
    }
    if (ship.repathTimer > 0) ship.repathTimer -= dt;
    const shipClear = clearFor(ship.class);

    // Detection
    let heard = 0;
    for (const c of contacts) {
      const d = dist(ship.x, ship.y, c.x, c.y);
      const range = enemyDetectLike(ship, c);
      if (d < range) heard = Math.max(heard, (1 - d / range) * (c.noise || 0.3));
    }
    const mast = mastSignature(boat, state.timeOfDay || 0.5);
    const dBoat = dist(ship.x, ship.y, boat.x, boat.y);
    if (mast > 0.3 && dBoat < 20 && ship.class !== "sub") {
      heard = Math.max(heard, mast * 0.7 * (1 - dBoat / 20));
    }
    ship.alert = clamp(ship.alert + (heard > 0.12 ? heard * 1.4 * dt : -0.12 * dt), 0, 1);

    let desiredHeading = ship.heading;
    let wantSpeed = ship.maxSpeed * 0.5;

    if (ship.alert > 0.4) {
      if (ship.class === "sub") {
        desiredHeading = Math.atan2(boat.y - ship.y, boat.x - ship.x);
        wantSpeed = dBoat > 6 ? ship.maxSpeed * 0.9 : ship.maxSpeed * 0.4;
      } else if (ship.class === "battleship") {
        const toSub = Math.atan2(boat.y - ship.y, boat.x - ship.x);
        const orbit = toSub + (Math.PI / 2) * (ship.id % 2 === 0 ? 1 : -1);
        desiredHeading = dBoat > DC_ENGAGE_RANGE + 1.5 ? toSub : orbit;
        wantSpeed = ship.maxSpeed * 0.7;
      } else {
        const toSub = Math.atan2(boat.y - ship.y, boat.x - ship.x);
        desiredHeading = dBoat > 7 ? toSub : toSub + Math.PI / 2;
        wantSpeed = ship.maxSpeed * 0.85;
      }
    } else {
      const route = ship.patrolRoute;
      if (route?.length) {
        if (ship.patrolIndex == null) ship.patrolIndex = 0;
        let wp = route[ship.patrolIndex];
        if (wp && dist(ship.x, ship.y, wp.x, wp.y) < 1.4) {
          ship.patrolIndex = ship.patrolLoop !== false
            ? (ship.patrolIndex + 1) % route.length
            : clamp(ship.patrolIndex + (ship.patrolDir || 1), 0, route.length - 1);
          wp = route[ship.patrolIndex];
        }
        if (wp) desiredHeading = Math.atan2(wp.y - ship.y, wp.x - ship.x);
      }
      wantSpeed = ship.class === "freighter" ? ship.maxSpeed * 0.7 : ship.maxSpeed * 0.55;
    }

    desiredHeading = steerAvoid(ship.x, ship.y, desiredHeading, 2.5, shipClear, { rays: 11 });
    ship.heading += clamp(angleDiff(ship.heading, desiredHeading), -ship.turnRate * dt, ship.turnRate * dt);
    ship.speed = lerp(ship.speed, wantSpeed, 1 - Math.exp(-1.3 * dt));
    ship.displayHeading += angleDiff(ship.displayHeading, ship.heading) * (1 - Math.exp(-12 * dt));

    let nx = ship.x + Math.cos(ship.heading) * ship.speed * dt;
    let ny = ship.y + Math.sin(ship.heading) * ship.speed * dt;
    nx = clamp(nx, 2, WORLD_SIZE - 3);
    ny = clamp(ny, 2, WORLD_SIZE - 3);
    if (shipClear(nx, ny)) { ship.x = nx; ship.y = ny; }
    else {
      ship.heading = steerAvoid(ship.x, ship.y, ship.heading, 2.8, shipClear, { rays: 15 });
      ship.speed *= 0.5;
    }

    ship.fireCooldown -= dt;
    if (ship.fireCooldown > 0 || ship.alert < 0.5) continue;
    if (isAtFob(state) || state.sub.docked > 0) {
      ship.fireCooldown = 1.2;
      continue;
    }

    if (ship.holdContact == null) ship.holdContact = 0;
    if (ship.alert > 0.55 && dBoat < 22) ship.holdContact += dt;
    else ship.holdContact = Math.max(0, ship.holdContact - dt * 0.35);

    if (ship.class === "battleship") {
      if (boat.z > 0.12 && dBoat <= DC_ENGAGE_RANGE) {
        ejectDepthCharge(state, ship, boat.x, boat.y, boat.z);
        if (Math.random() < 0.4) ejectDepthCharge(state, ship, boat.x, boat.y, boat.z);
        ship.fireCooldown = 5.2;
        state.floats.push({ x: ship.x, y: ship.y, text: "DEPTH CHARGES!", life: 1.4, color: "#ffb080", vy: -0.45 });
      } else if (boat.z < 0.18 && dBoat < 10) {
        if (Math.random() < 0.45) damageSub(state, 16 + Math.random() * 12, "Battleship shellfire.");
        ship.fireCooldown = 2.8;
      } else ship.fireCooldown = 0.9;
    } else if (ship.class === "sub") {
      if (dBoat < 14 && dBoat > 2.5) {
        const h = Math.atan2(boat.y - ship.y, boat.x - ship.x);
        const sp = 7.5;
        state.torpedoes.push({
          id: uid(state), x: ship.x + Math.cos(h) * 1.2, y: ship.y + Math.sin(h) * 1.2, z: 0.32,
          vx: Math.cos(h) * sp, vy: Math.sin(h) * sp, heading: h, targetId: -999, life: 9,
          owner: "enemy", damage: 42, armed: false, seeking: Math.random() < 0.45, trailTimer: 0,
        });
        ship.fireCooldown = 7 + Math.random() * 3;
        state.floats.push({ x: ship.x, y: ship.y, text: "TORPEDO!", life: 1.3, color: "#ff8060", vy: -0.45 });
      } else ship.fireCooldown = 1;
    } else if (ship.class === "destroyer" || ship.class === "patrol" || ship.class === "cruiser") {
      if (boat.z > 0.12 && dBoat < 5.5 && ship.alert > 0.6 && (ship.holdContact || 0) > 1.5) {
        fireHedgehog(state, ship, boat.x, boat.y, boat.z, () => uid(state));
        audio.sfxShellSplash();
      } else if (boat.z < 0.18 && dBoat < 12) {
        if (Math.random() < 0.4) damageSub(state, 10 + Math.random() * 10, "Deck gun fire.");
        ship.fireCooldown = ship.class === "patrol" ? 2.6 : 2;
      } else ship.fireCooldown = 1.1;
    }
  }
  state.ships = state.ships.filter((s) => !s.dead);
}

function enemyDetectLike(ship, c) {
  const base = ship.class === "sub" ? 14 : ship.class === "destroyer" ? 18 : 12;
  return base * (0.7 + (c.noise || 0.3));
}

function updateTorpedoes(state, terrain, dt) {
  let foxerX = null, foxerY = null;
  for (const cm of state.countermeasures) {
    if (cm.kind === "foxer") { foxerX = cm.x; foxerY = cm.y; break; }
  }
  for (const t of state.torpedoes) {
    t.life -= dt;
    if (!t.armed && t.life < (t.seeking ? 9.4 : 7.6)) t.armed = true;
    if (t.owner === "player" && t.targetId != null) {
      const ship = state.ships.find((s) => s.id === t.targetId && !s.dead && s.sinking === 0);
      if (ship) {
        let aimX = ship.x, aimY = ship.y;
        if (t.seeking && foxerX != null) { aimX = foxerX; aimY = foxerY; }
        const desired = Math.atan2(aimY - t.y, aimX - t.x);
        const cur = Math.atan2(t.vy, t.vx);
        const nh = cur + clamp(angleDiff(cur, desired), -(t.seeking ? 2.8 : 2.2) * dt, (t.seeking ? 2.8 : 2.2) * dt);
        const sp = Math.hypot(t.vx, t.vy);
        t.vx = Math.cos(nh) * sp; t.vy = Math.sin(nh) * sp; t.heading = nh;
      }
    } else if (t.owner === "enemy") {
      let aimX = state.sub.x, aimY = state.sub.y;
      if (t.seeking && foxerX != null) { aimX = foxerX; aimY = foxerY; }
      const quiet = state.sub.noise < 0.22 || state.sub.silentRunning;
      const turn = t.seeking ? (quiet ? 1.1 : 2.4) : 0.9;
      const desired = Math.atan2(aimY - t.y, aimX - t.x);
      const cur = Math.atan2(t.vy, t.vx);
      const nh = cur + clamp(angleDiff(cur, desired), -turn * dt, turn * dt);
      const sp = Math.hypot(t.vx, t.vy) || 7;
      t.vx = Math.cos(nh) * sp; t.vy = Math.sin(nh) * sp; t.heading = nh;
    }
    t.x += t.vx * dt; t.y += t.vy * dt;
    if (isLand(terrain, t.x, t.y)) { explode(state, t.x, t.y, 0.05, 10); t.life = 0; continue; }
    t.trailTimer -= dt;
    if (t.trailTimer <= 0) {
      t.trailTimer = 0.08;
      spawnParticles(state, t.x, t.y, t.z, "trail", 1, t.owner === "enemy" ? "#ff9a7a" : t.seeking ? "#5eead4" : "#9ad0ff", 0.7);
    }
    if (t.armed && t.owner === "player") {
      for (const ship of state.ships) {
        if (ship.dead || ship.sinking > 0) continue;
        const hitR = ship.class === "sub" ? 1.55 : ship.class === "battleship" ? 1.25 : 0.95;
        if (dist(t.x, t.y, ship.x, ship.y) < hitR) {
          const asp = aspectBonus(t.heading, ship.heading);
          damageShip(state, ship, t.damage * asp.mul);
          if (asp.mul >= 1.2) state.floats.push({ x: ship.x, y: ship.y, text: asp.label + " HIT", life: 1.2, color: "#5eead4", vy: -0.5 });
          explode(state, t.x, t.y, 0.1, 20);
          t.life = 0;
          break;
        }
      }
    }
    if (t.armed && t.owner === "enemy") {
      if (dist(t.x, t.y, state.sub.x, state.sub.y) < 0.95 && Math.abs(t.z - state.sub.z) < 0.4) {
        damageSub(state, t.damage, "Enemy torpedo struck the pressure hull.");
        explode(state, t.x, t.y, t.z, 16);
        t.life = 0;
      } else if (t.seeking && foxerX != null && dist(t.x, t.y, foxerX, foxerY) < 1.2) {
        explode(state, t.x, t.y, t.z, 10); t.life = 0;
      }
    }
    if (t.x < 0 || t.y < 0 || t.x > WORLD_SIZE || t.y > WORLD_SIZE) t.life = 0;
  }
  state.torpedoes = state.torpedoes.filter((t) => t.life > 0);
}

function updateDepthCharges(state, dt) {
  for (const dc of state.depthCharges) {
    dc.fuse -= dt;
    dc.z += dc.vz * dt;
    if (dc.diverted && dc.divertX != null) {
      dc.x = lerp(dc.x, dc.divertX, 1 - Math.exp(-2 * dt));
      dc.y = lerp(dc.y, dc.divertY, 1 - Math.exp(-2 * dt));
    }
    if (dc.fuse <= 0) {
      explode(state, dc.x, dc.y, clamp(dc.z, 0, 1.5), 14);
      spawnImpact(state, dc.x, dc.y, clamp(dc.z, 0, 1.5), "shock", 2.8, "#ffb080");
      audio.sfxDepthChargeDetonate();
      const d = dist(dc.x, dc.y, state.sub.x, state.sub.y);
      const dz = Math.abs(state.sub.z - clamp(dc.z / 2, 0, 1));
      let dmgMul = 1;
      for (const cm of state.countermeasures) {
        if (cm.kind === "bubble" && dist(cm.x, cm.y, state.sub.x, state.sub.y) < cm.radius + 1.5) dmgMul *= 0.75;
      }
      if (dc.contact) {
        if (d < 0.95 && Math.abs((dc.setDepth ?? state.sub.z) - state.sub.z) < 0.22) {
          damageSub(state, dc.damage * dmgMul * 1.15, "Hedgehog projectile struck.");
        }
      } else if (d < dc.radius && dz < 0.45) {
        damageSub(state, dc.damage * (1 - d / dc.radius) * (1 - dz / 0.45) * dmgMul * 0.72, "Depth charge concussion.");
      }
      dc.fuse = -999;
    }
  }
  state.depthCharges = state.depthCharges.filter((d) => d.fuse > 0);
}

function updateCountermeasures(state, dt) {
  for (const cm of state.countermeasures) {
    cm.life -= dt;
    if (cm.kind === "foxer") {
      cm.x += Math.sin(state.time * 0.7 + cm.id) * 0.25 * dt;
      cm.y += Math.cos(state.time * 0.5 + cm.id) * 0.25 * dt;
    }
  }
  state.countermeasures = state.countermeasures.filter((c) => c.life > 0);
}

function updateParticles(state, dt) {
  const arr = state.particles;
  let w = 0;
  for (let i = 0; i < arr.length; i++) {
    const p = arr[i];
    p.life -= dt;
    if (p.life <= 0) continue;
    p.x += p.vx * dt * 0.35; p.y += p.vy * dt * 0.35; p.z += p.vz * dt * 0.25;
    if (p.kind === "bubble" || p.kind === "trail") { p.z -= dt * 0.35; p.z = Math.max(0, p.z); }
    if (p.kind === "wake") p.size *= 1 + dt * 0.8;
    arr[w++] = p;
  }
  arr.length = w;
  if (arr.length > 120) arr.splice(0, arr.length - 120);
}

function updateImpacts(state, dt) {
  if (!state.impacts) state.impacts = [];
  state.impacts = state.impacts.filter((fx) => { fx.life -= dt; return fx.life > 0; });
}

function updateFloats(state, dt) {
  state.floats = state.floats.filter((f) => { f.life -= dt; f.y += f.vy * dt; return f.life > 0; });
}

function updateCamera(state, dt) {
  const c = state.camera;
  const k = 1 - Math.exp(-4 * dt);
  c.x = lerp(c.x, c.targetX, k);
  c.y = lerp(c.y, c.targetY, k);
  c.shake = Math.max(0, c.shake - dt * 2.6);
}

export function updateGame(state, terrain, dt, opts = {}) {
  const capped = Math.min(dt, 0.05);
  const simulateWorld = opts.simulateWorld !== false;
  const contacts = opts.contacts ?? [];
  if (state.phase !== "playing") {
    state.time += capped * 0.35;
    updateParticles(state, capped);
    updateImpacts(state, capped);
    updateCamera(state, capped);
    return;
  }
  state.time += capped;
  state.stats.timeSurvived += capped;
  state.timeOfDay = ((state.timeOfDay || 0) + capped / 480) % 1;
  if (state.messageLife > 0) state.messageLife -= capped;

  updateAutopilot(state, terrain, capped, { fireWeapon, deployCountermeasure });
  updateSub(state, terrain, capped);
  if (state.sub.hp <= 0 && state.phase === "playing") {
    state.phase = "gameover";
    state.gameOverReason = "Flooding overwhelmed the pumps.";
    audio.sfxGameOver();
  }
  updatePlayerSonar(state, capped);
  updateAircraft(state, capped);

  if (simulateWorld) {
    const allContacts = [
      { x: state.sub.x, y: state.sub.y, z: state.sub.z, noise: state.sub.noise },
      ...contacts,
    ];
    updateShips(state, terrain, capped, allContacts);
    updateTorpedoes(state, terrain, capped);
    updateDepthCharges(state, capped);
    updateCountermeasures(state, capped);
    updateBaseAndPowerups(state, terrain, capped);
    if (state.ships.length === 0) {
      state.stats.wave++;
      if (state.stats.shipsSunk >= state.victoryTarget) {
        state.phase = "victory";
        state.message = "Sector cleared.";
        state.messageLife = 10;
        state.stats.score += 1000;
        audio.sfxVictory();
      } else {
        state.sub.torpedoes = Math.min(state.sub.maxTorpedoes, state.sub.torpedoes + 4);
        state.sub.seekers = Math.min(state.sub.maxSeekers, state.sub.seekers + 2);
        state.sub.battery = Math.min(state.sub.maxBattery, state.sub.battery + 40);
        state.sub.hp = Math.min(state.sub.maxHp, state.sub.hp + 20);
        state.message = `Wave ${state.stats.wave} — reinforcements inbound.`;
        state.messageLife = 4;
        seedWave(state, terrain, state.stats.wave);
        for (let i = 0; i < 3; i++) spawnPowerup(state, terrain);
        audio.sfxWaveClear();
      }
    }
  } else {
    updateTorpedoes(state, terrain, capped);
    updateCountermeasures(state, capped);
    updateBaseAndPowerups(state, terrain, capped);
  }
  updateParticles(state, capped);
  updateImpacts(state, capped);
  updateFloats(state, capped);
  updateCamera(state, capped);
}

export function pickShipAt(state, wx, wy, radius = 1.6) {
  let best = null, bestD = radius * radius;
  for (const ship of state.ships) {
    if (ship.dead) continue;
    const d = dist2(wx, wy, ship.x, ship.y);
    if (d < bestD) { bestD = d; best = ship; }
  }
  return best;
}

export function pickShipAtScreen(state, sx, sy, viewW, viewH, maxPx = 36) {
  const cam = state.camera;
  let best = null, bestD = maxPx * maxPx;
  for (const ship of state.ships) {
    if (ship.dead || ship.sinking > 0) continue;
    const z = ship.class === "sub" ? -0.2 : 0;
    const p = worldToScreen(ship.x, ship.y, z, cam.x, cam.y, cam.zoom, viewW, viewH);
    const dx = p.sx - sx, dy = p.sy - sy;
    const pad = ship.class === "battleship" ? 1.35 : ship.class === "sub" ? 1.05 : 1.1;
    const d = (dx * dx + dy * dy) / (pad * pad);
    if (d < bestD) { bestD = d; best = ship; }
  }
  return best;
}

export function findShip(state, id) {
  if (id == null) return null;
  return state.ships.find((s) => s.id === id && !s.dead) ?? null;
}

export function applyHostSeed(bundle, seed) {
  if (bundle.state.seed === seed && bundle.terrain.length === WORLD_SIZE) return;
  const terrain = generateTerrain(seed);
  rebuildOpenWater(terrain);
  bundle.terrain.splice(0, bundle.terrain.length, ...terrain);
  bundle.state.seed = seed;
  invalidateWaterMask();
}
