/**
 * Compact multiplayer snapshots for Silent Depths.
 * Packs ships / torps / depth charges with class indices including battleship + sub.
 */
import type {
  DepthCharge,
  GamePhase,
  GameState,
  Ship,
  ShipClass,
  Submarine,
  Torpedo,
} from "./types";

// ── Compact types ────────────────────────────────────────────────────────────

export type CompactShip = {
  id: number;
  c: ShipClass;
  x: number;
  y: number;
  h: number;
  dh: number;
  sp: number;
  hp: number;
  mhp: number;
  sk: number;
  al: number;
  dead: boolean;
  name: string;
};

export type CompactDc = {
  id: number;
  x: number;
  y: number;
  z: number;
  fuse: number;
  radius: number;
  damage: number;
  divertX: number | null;
  divertY: number | null;
  diverted: boolean;
};

export type CompactTorp = {
  id: number;
  x: number;
  y: number;
  z: number;
  vx: number;
  vy: number;
  h: number;
  tid: number | null;
  life: number;
  own: "player" | "enemy";
  dmg: number;
  sk: boolean;
};

export type PlayerSnap = {
  t: "ps";
  id: string;
  n: string;
  x: number;
  y: number;
  z: number;
  h: number;
  dh: number;
  sp: number;
  hp: number;
  noise: number;
  ph: number;
};

export type HostSnap = {
  t: "hs";
  seed: number;
  phase: string;
  ships: CompactShip[];
  dcs: CompactDc[];
  torps: CompactTorp[];
  wave: number;
  score: number;
  sunk: number;
  time: number;
};

/** Dense host world tick (message tag "hw"). */
export type HostTick = {
  t: "hw";
  a: number[];
  d: number[];
  p: number[];
  phase: number;
  wave: number;
  score: number;
  sunk: number;
  time: number;
  seed: number;
};

export type SyncRequest = { t: "req" };
export type HelloMsg = { t: "hi"; id: string; n: string; a: string | null };

export type NetMsg = PlayerSnap | HostSnap | HostTick | SyncRequest | HelloMsg;

export type RemotePlayer = {
  id: string;
  name: string;
  avatar: string | null;
  x: number;
  y: number;
  z: number;
  heading: number;
  displayHeading: number;
  speed: number;
  hp: number;
  noise: number;
  phase: number;
  tx: number;
  ty: number;
  tz: number;
  th: number;
  tdh: number;
  lastSeen: number;
};

const CLS_TO_I: Record<ShipClass, number> = {
  patrol: 0,
  destroyer: 1,
  freighter: 2,
  cruiser: 3,
  battleship: 4,
  sub: 5,
};
const I_TO_CLS: ShipClass[] = [
  "patrol",
  "destroyer",
  "freighter",
  "cruiser",
  "battleship",
  "sub",
];

const PHASE_TO_I: Record<string, number> = {
  menu: 0,
  playing: 1,
  paused: 2,
  gameover: 3,
  victory: 4,
};
const I_TO_PHASE = ["menu", "playing", "paused", "gameover", "victory"] as const;

export function q(v: number, mul: number): number {
  return Math.round(v * mul);
}
export function uq(v: number, mul: number): number {
  return v / mul;
}

export function isHost(selfId: string, peerIds: string[]): boolean {
  if (!selfId) return true;
  if (peerIds.length === 0) return true;
  let min = selfId;
  for (const id of peerIds) {
    if (id < min) min = id;
  }
  return min === selfId;
}

export function shouldAnswerSync(
  selfId: string,
  peerIds: string[],
  _from: string,
): boolean {
  return isHost(selfId, peerIds);
}

export function hostTickInterval(state: GameState): number {
  const load =
    state.ships.length +
    state.torpedoes.length * 0.5 +
    state.depthCharges.length * 0.4;
  if (load > 14) return 0.1;
  if (load > 6) return 0.14;
  return 0.2;
}

export function hostTickFingerprint(tick: HostTick): number {
  let h = tick.phase * 17 + tick.wave * 31 + tick.score + tick.sunk * 13;
  h = (h + tick.a.length * 3 + tick.d.length * 7 + tick.p.length * 11) | 0;
  if (tick.a.length) h = (h + tick.a[0]! + (tick.a[tick.a.length - 1] ?? 0)) | 0;
  if (tick.p.length) h = (h + tick.p[0]! * 5) | 0;
  if (tick.d.length) h = (h + tick.d[0]! * 9) | 0;
  return h;
}

export function applyHello(
  remotes: Map<string, RemotePlayer>,
  msg: HelloMsg,
  now: number,
): void {
  const prev = remotes.get(msg.id);
  if (prev) {
    prev.name = msg.n || prev.name;
    prev.avatar = msg.a;
    prev.lastSeen = now;
    return;
  }
  remotes.set(msg.id, {
    id: msg.id,
    name: msg.n || "Captain",
    avatar: msg.a,
    x: 0,
    y: 0,
    z: 0.45,
    heading: 0,
    displayHeading: 0,
    speed: 0,
    hp: 100,
    noise: 0.2,
    phase: 1,
    tx: 0,
    ty: 0,
    tz: 0.45,
    th: 0,
    tdh: 0,
    lastSeen: now,
  });
}

export function applyPlayerSnap(
  remotes: Map<string, RemotePlayer>,
  msg: PlayerSnap,
  now: number,
): void {
  let r = remotes.get(msg.id);
  if (!r) {
    r = {
      id: msg.id,
      name: msg.n || "Captain",
      avatar: null,
      x: msg.x,
      y: msg.y,
      z: msg.z,
      heading: msg.h,
      displayHeading: msg.dh,
      speed: msg.sp,
      hp: msg.hp,
      noise: msg.noise,
      phase: msg.ph,
      tx: msg.x,
      ty: msg.y,
      tz: msg.z,
      th: msg.h,
      tdh: msg.dh,
      lastSeen: now,
    };
    remotes.set(msg.id, r);
    return;
  }
  r.name = msg.n || r.name;
  r.tx = msg.x;
  r.ty = msg.y;
  r.tz = msg.z;
  r.th = msg.h;
  r.tdh = msg.dh;
  r.speed = msg.sp;
  r.hp = msg.hp;
  r.noise = msg.noise;
  r.phase = msg.ph;
  r.lastSeen = now;
}

export function interpolateRemotes(remotes: Map<string, RemotePlayer>, dt: number): void {
  const k = 1 - Math.exp(-10 * dt);
  for (const r of remotes.values()) {
    r.x += (r.tx - r.x) * k;
    r.y += (r.ty - r.y) * k;
    r.z += (r.tz - r.z) * k;
    let dh = r.th - r.heading;
    while (dh > Math.PI) dh -= Math.PI * 2;
    while (dh < -Math.PI) dh += Math.PI * 2;
    r.heading += dh * k;
    let ddh = r.tdh - r.displayHeading;
    while (ddh > Math.PI) ddh -= Math.PI * 2;
    while (ddh < -Math.PI) ddh += Math.PI * 2;
    r.displayHeading += ddh * k;
  }
}

export function pruneRemotes(
  remotes: Map<string, RemotePlayer>,
  liveIds: Set<string>,
  now: number,
  maxAgeMs = 8000,
): void {
  for (const [id, r] of remotes) {
    if (!liveIds.has(id) && now - r.lastSeen > maxAgeMs) {
      remotes.delete(id);
    }
  }
}

export function packPlayerSnap(
  selfId: string,
  sub: Submarine,
  phase: GamePhase | string,
  name = "",
): PlayerSnap {
  return {
    t: "ps",
    id: selfId,
    n: name,
    x: q(sub.x, 100) / 100,
    y: q(sub.y, 100) / 100,
    z: q(sub.z, 100) / 100,
    h: q(sub.heading, 1000) / 1000,
    dh: q(sub.displayHeading, 1000) / 1000,
    sp: q(sub.speed, 100) / 100,
    hp: Math.round(sub.hp),
    noise: q(sub.noise, 100) / 100,
    ph: PHASE_TO_I[phase] ?? 1,
  };
}

export function packShip(s: Ship): CompactShip {
  return {
    id: s.id,
    c: s.class,
    x: q(s.x, 100) / 100,
    y: q(s.y, 100) / 100,
    h: q(s.heading, 1000) / 1000,
    dh: q(s.displayHeading, 1000) / 1000,
    sp: q(s.speed, 100) / 100,
    hp: Math.round(s.hp),
    mhp: s.maxHp,
    sk: q(s.sinking, 100) / 100,
    al: q(s.alert, 100) / 100,
    dead: s.dead,
    name: s.name,
  };
}

export function unpackShip(c: CompactShip, prev?: Ship): Ship {
  if (prev && prev.id === c.id) {
    prev.x = c.x;
    prev.y = c.y;
    prev.heading = c.h;
    prev.displayHeading = c.dh;
    prev.speed = c.sp;
    prev.hp = c.hp;
    prev.maxHp = c.mhp;
    prev.sinking = c.sk;
    prev.alert = c.al;
    prev.dead = c.dead;
    prev.class = c.c;
    if (c.name) prev.name = c.name;
    return prev;
  }
  return {
    id: c.id,
    class: c.c,
    x: c.x,
    y: c.y,
    heading: c.h,
    displayHeading: c.dh,
    speed: c.sp,
    maxSpeed: defaultMaxSpeed(c.c),
    hp: c.hp,
    maxHp: c.mhp,
    sinking: c.sk,
    alert: c.al,
    fireCooldown: 2,
    patrolAngle: 0,
    dead: c.dead,
    name: c.name || "Ship",
    trailTimer: 0,
    turnRate: 0.6,
    patrolRoute: [],
    patrolIndex: 0,
    patrolDir: 1,
    patrolLoop: true,
  };
}

function defaultMaxSpeed(c: ShipClass): number {
  switch (c) {
    case "patrol":
      return 2.6;
    case "destroyer":
      return 2.2;
    case "freighter":
      return 1.15;
    case "cruiser":
      return 1.85;
    case "battleship":
      return 1.45;
    case "sub":
      return 1.75;
  }
}

function defaultMaxHp(c: ShipClass): number {
  switch (c) {
    case "patrol":
      return 50;
    case "destroyer":
      return 115;
    case "freighter":
      return 95;
    case "cruiser":
      return 190;
    case "battleship":
      return 280;
    case "sub":
      return 150;
  }
}

export function packDc(d: DepthCharge): CompactDc {
  return {
    id: d.id,
    x: q(d.x, 100) / 100,
    y: q(d.y, 100) / 100,
    z: q(d.z, 100) / 100,
    fuse: q(d.fuse, 100) / 100,
    radius: d.radius,
    damage: d.damage,
    divertX: d.divertX,
    divertY: d.divertY,
    diverted: d.diverted,
  };
}

export function unpackDc(c: CompactDc, prev?: DepthCharge): DepthCharge {
  if (prev && prev.id === c.id) {
    prev.x = c.x;
    prev.y = c.y;
    prev.z = c.z;
    prev.fuse = c.fuse;
    prev.radius = c.radius;
    prev.damage = c.damage;
    prev.divertX = c.divertX;
    prev.divertY = c.divertY;
    prev.diverted = c.diverted;
    return prev;
  }
  return {
    id: c.id,
    x: c.x,
    y: c.y,
    z: c.z,
    vz: prev?.vz ?? 0.55,
    fuse: c.fuse,
    radius: c.radius,
    damage: c.damage,
    divertX: c.divertX,
    divertY: c.divertY,
    diverted: c.diverted,
  };
}

export function packTorp(t: Torpedo): CompactTorp {
  return {
    id: t.id,
    x: q(t.x, 100) / 100,
    y: q(t.y, 100) / 100,
    z: q(t.z, 100) / 100,
    vx: q(t.vx, 100) / 100,
    vy: q(t.vy, 100) / 100,
    h: q(t.heading, 1000) / 1000,
    tid: t.targetId,
    life: q(t.life, 100) / 100,
    own: t.owner,
    dmg: t.damage,
    sk: t.seeking,
  };
}

export function unpackTorp(c: CompactTorp, prev?: Torpedo): Torpedo {
  if (prev && prev.id === c.id) {
    prev.x = c.x;
    prev.y = c.y;
    prev.z = c.z;
    prev.vx = c.vx;
    prev.vy = c.vy;
    prev.heading = c.h;
    prev.targetId = c.tid;
    prev.life = c.life;
    prev.owner = c.own;
    prev.damage = c.dmg;
    prev.seeking = c.sk;
    prev.armed = c.life < 7.5;
    return prev;
  }
  return {
    id: c.id,
    x: c.x,
    y: c.y,
    z: c.z,
    vx: c.vx,
    vy: c.vy,
    heading: c.h,
    targetId: c.tid,
    life: c.life,
    owner: c.own,
    damage: c.dmg,
    armed: c.life < 7.5,
    seeking: c.sk,
    trailTimer: 0,
  };
}

function makeShip(
  id: number,
  cls: ShipClass,
  x: number,
  y: number,
  h: number,
  dh: number,
  sp: number,
  hp: number,
  sk: number,
  al: number,
  prev?: Ship,
): Ship {
  if (prev && prev.id === id) {
    prev.x = x;
    prev.y = y;
    prev.heading = h;
    prev.displayHeading = dh;
    prev.speed = sp;
    prev.hp = hp;
    prev.sinking = sk;
    prev.alert = al;
    prev.dead = false;
    prev.class = cls;
    return prev;
  }
  return {
    id,
    class: cls,
    x,
    y,
    heading: h,
    displayHeading: dh,
    speed: sp,
    maxSpeed: defaultMaxSpeed(cls),
    hp,
    maxHp: prev?.maxHp ?? defaultMaxHp(cls),
    sinking: sk,
    alert: al,
    fireCooldown: prev?.fireCooldown ?? 2,
    patrolAngle: prev?.patrolAngle ?? 0,
    dead: false,
    name: prev?.name ?? "Ship",
    trailTimer: prev?.trailTimer ?? 0,
    turnRate: prev?.turnRate ?? 0.6,
    patrolRoute: prev?.patrolRoute ?? [],
    patrolIndex: prev?.patrolIndex ?? 0,
    patrolDir: prev?.patrolDir ?? 1,
    patrolLoop: prev?.patrolLoop ?? true,
  };
}

function makeDc(
  id: number,
  x: number,
  y: number,
  z: number,
  fuse: number,
  radius: number,
  damage: number,
  divertX: number | null,
  divertY: number | null,
  diverted: boolean,
  prev?: DepthCharge,
): DepthCharge {
  if (prev && prev.id === id) {
    prev.x = x;
    prev.y = y;
    prev.z = z;
    prev.fuse = fuse;
    prev.radius = radius;
    prev.damage = damage;
    prev.divertX = divertX;
    prev.divertY = divertY;
    prev.diverted = diverted;
    return prev;
  }
  return {
    id,
    x,
    y,
    z,
    vz: prev?.vz ?? 0.55,
    fuse,
    radius,
    damage,
    divertX,
    divertY,
    diverted,
  };
}

function makeTorp(
  id: number,
  x: number,
  y: number,
  z: number,
  vx: number,
  vy: number,
  h: number,
  tid: number | null,
  life: number,
  own: "player" | "enemy",
  dmg: number,
  sk: boolean,
  prev?: Torpedo,
): Torpedo {
  if (prev && prev.id === id) {
    prev.x = x;
    prev.y = y;
    prev.z = z;
    prev.vx = vx;
    prev.vy = vy;
    prev.heading = h;
    prev.targetId = tid;
    prev.life = life;
    prev.owner = own;
    prev.damage = dmg;
    prev.seeking = sk;
    prev.armed = life < 7.5;
    return prev;
  }
  return {
    id,
    x,
    y,
    z,
    vx,
    vy,
    heading: h,
    targetId: tid,
    life,
    owner: own,
    damage: dmg,
    armed: life < 7.5,
    seeking: sk,
    trailTimer: 0,
  };
}

export function packHostTick(state: GameState): HostTick {
  const ships: number[] = [];
  for (const sh of state.ships) {
    if (sh.dead) continue;
    ships.push(
      sh.id,
      q(sh.x, 100),
      q(sh.y, 100),
      q(sh.heading, 1000),
      q(sh.displayHeading, 1000),
      q(sh.speed, 100),
      Math.round(sh.hp),
      q(sh.sinking, 100),
      q(sh.alert, 100),
      CLS_TO_I[sh.class],
    );
  }
  const dcs: number[] = [];
  for (const dc of state.depthCharges) {
    dcs.push(
      dc.id,
      q(dc.x, 100),
      q(dc.y, 100),
      q(dc.z, 100),
      q(dc.fuse, 100),
      q(dc.radius, 10),
      dc.damage,
      dc.diverted ? 1 : 0,
      dc.divertX != null ? q(dc.divertX, 100) : -1,
      dc.divertY != null ? q(dc.divertY, 100) : -1,
    );
  }
  const torps: number[] = [];
  for (const t of state.torpedoes) {
    torps.push(
      t.id,
      q(t.x, 100),
      q(t.y, 100),
      q(t.z, 100),
      q(t.vx, 100),
      q(t.vy, 100),
      q(t.heading, 1000),
      t.targetId ?? -1,
      q(t.life, 100),
      t.owner === "enemy" ? 1 : 0,
      t.damage,
      t.seeking ? 1 : 0,
    );
  }
  return {
    t: "hw",
    a: ships,
    d: dcs,
    p: torps,
    phase: PHASE_TO_I[state.phase] ?? 1,
    wave: state.stats.wave,
    score: state.stats.score,
    sunk: state.stats.shipsSunk,
    time: q(state.stats.timeSurvived, 10) / 10,
    seed: state.seed,
  };
}

export function applyHostTick(state: GameState, msg: HostTick): void {
  state.phase = I_TO_PHASE[msg.phase] ?? state.phase;
  state.stats.wave = msg.wave;
  state.stats.score = msg.score;
  state.stats.shipsSunk = msg.sunk;
  state.stats.timeSurvived = msg.time;
  if (msg.seed) state.seed = msg.seed;

  const prevShips = new Map<number, Ship>();
  for (const s of state.ships) prevShips.set(s.id, s);
  const nextShips: Ship[] = [];
  const a = msg.a;
  for (let i = 0; i + 9 < a.length; i += 10) {
    const id = a[i]!;
    const cls = I_TO_CLS[a[i + 9]!] ?? "patrol";
    nextShips.push(
      makeShip(
        id,
        cls,
        uq(a[i + 1]!, 100),
        uq(a[i + 2]!, 100),
        uq(a[i + 3]!, 1000),
        uq(a[i + 4]!, 1000),
        uq(a[i + 5]!, 100),
        a[i + 6]!,
        uq(a[i + 7]!, 100),
        uq(a[i + 8]!, 100),
        prevShips.get(id),
      ),
    );
  }
  state.ships = nextShips;

  const prevDc = new Map<number, DepthCharge>();
  for (const dc of state.depthCharges) prevDc.set(dc.id, dc);
  const nextDc: DepthCharge[] = [];
  const d = msg.d;
  for (let i = 0; i + 9 < d.length; i += 10) {
    const id = d[i]!;
    const diverted = d[i + 7] === 1;
    const divertX = d[i + 8]! < 0 ? null : uq(d[i + 8]!, 100);
    const divertY = d[i + 9]! < 0 ? null : uq(d[i + 9]!, 100);
    nextDc.push(
      makeDc(
        id,
        uq(d[i + 1]!, 100),
        uq(d[i + 2]!, 100),
        uq(d[i + 3]!, 100),
        uq(d[i + 4]!, 100),
        uq(d[i + 5]!, 10),
        d[i + 6]!,
        divertX,
        divertY,
        diverted,
        prevDc.get(id),
      ),
    );
  }
  state.depthCharges = nextDc;

  const prevTp = new Map<number, Torpedo>();
  for (const t of state.torpedoes) prevTp.set(t.id, t);
  const nextTp: Torpedo[] = [];
  const p = msg.p;
  for (let i = 0; i + 11 < p.length; i += 12) {
    const id = p[i]!;
    const tid = p[i + 7]! < 0 ? null : p[i + 7]!;
    nextTp.push(
      makeTorp(
        id,
        uq(p[i + 1]!, 100),
        uq(p[i + 2]!, 100),
        uq(p[i + 3]!, 100),
        uq(p[i + 4]!, 100),
        uq(p[i + 5]!, 100),
        uq(p[i + 6]!, 1000),
        tid,
        uq(p[i + 8]!, 100),
        p[i + 9] === 1 ? "enemy" : "player",
        p[i + 10]!,
        p[i + 11] === 1,
        prevTp.get(id),
      ),
    );
  }
  state.torpedoes = nextTp;

  let maxId = state.nextId;
  for (const s of state.ships) if (s.id >= maxId) maxId = s.id + 1;
  for (const dc of state.depthCharges) if (dc.id >= maxId) maxId = dc.id + 1;
  for (const t of state.torpedoes) if (t.id >= maxId) maxId = t.id + 1;
  state.nextId = maxId;
}

export function applyHostSnap(state: GameState, msg: HostSnap): void {
  state.phase = msg.phase as GameState["phase"];
  state.stats.wave = msg.wave;
  state.stats.score = msg.score;
  state.stats.shipsSunk = msg.sunk;
  if (typeof msg.time === "number") {
    state.time = msg.time;
    state.stats.timeSurvived = msg.time;
  }
  state.seed = msg.seed;

  const prevShips = new Map(state.ships.map((s) => [s.id, s] as const));
  state.ships = msg.ships.map((c) => unpackShip(c, prevShips.get(c.id)));
  const prevDc = new Map(state.depthCharges.map((d) => [d.id, d] as const));
  state.depthCharges = msg.dcs.map((c) => unpackDc(c, prevDc.get(c.id)));
  const prevTp = new Map(state.torpedoes.map((t) => [t.id, t] as const));
  state.torpedoes = msg.torps.map((c) => unpackTorp(c, prevTp.get(c.id)));

  let maxId = state.nextId;
  for (const s of state.ships) maxId = Math.max(maxId, s.id + 1);
  for (const dc of state.depthCharges) maxId = Math.max(maxId, dc.id + 1);
  for (const t of state.torpedoes) maxId = Math.max(maxId, t.id + 1);
  state.nextId = maxId;
}
