/** WebAudio SFX bus — unlock on first gesture, layered procedural sounds. */

let ctx: AudioContext | null = null;
let muted = false;
let master: GainNode | null = null;
let sfxBus: GainNode | null = null;
let ambiBus: GainNode | null = null;
let noiseBuf: AudioBuffer | null = null;
let longNoise: AudioBuffer | null = null;
let ambNodes: { stop: () => void } | null = null;
let lastEngine = 0;

function getCtx(): AudioContext | null {
  if (typeof window === "undefined") return null;
  if (!ctx) {
    const AC =
      window.AudioContext ||
      (window as unknown as { webkitAudioContext: typeof AudioContext })
        .webkitAudioContext;
    if (!AC) return null;
    ctx = new AC({ latencyHint: "interactive" });
    master = ctx.createGain();
    sfxBus = ctx.createGain();
    ambiBus = ctx.createGain();
    sfxBus.gain.value = 0.9;
    ambiBus.gain.value = 0.28;
    master.gain.value = 0.92;
    sfxBus.connect(master);
    ambiBus.connect(master);
    master.connect(ctx.destination);
    noiseBuf = ctx.createBuffer(1, ctx.sampleRate * 0.5, ctx.sampleRate);
    const data = noiseBuf.getChannelData(0);
    for (let i = 0; i < data.length; i++) data[i] = Math.random() * 2 - 1;
    longNoise = ctx.createBuffer(1, ctx.sampleRate * 2, ctx.sampleRate);
    const ld = longNoise.getChannelData(0);
    let last = 0;
    for (let i = 0; i < ld.length; i++) {
      // brown-ish noise for ocean
      last = (last + (Math.random() * 2 - 1) * 0.02) * 0.98;
      ld[i] = last * 3.5;
    }
  }
  return ctx;
}

function bus(): GainNode | null {
  getCtx();
  return sfxBus;
}

export function setMuted(m: boolean) {
  muted = m;
  const c = getCtx();
  if (master && c) {
    master.gain.setTargetAtTime(m ? 0 : 0.92, c.currentTime, 0.02);
  }
  if (m) stopAmbient();
}

export function unlockAudio() {
  const c = getCtx();
  if (c?.state === "suspended") void c.resume();
  startAmbient();
}

function tone(
  freq: number,
  dur: number,
  type: OscillatorType,
  gain = 0.08,
  freqEnd?: number,
  when = 0,
) {
  if (muted) return;
  const c = getCtx();
  const b = bus();
  if (!c || !b) return;
  const t0 = c.currentTime + when;
  const osc = c.createOscillator();
  const g = c.createGain();
  osc.type = type;
  osc.frequency.setValueAtTime(freq, t0);
  if (freqEnd != null) {
    osc.frequency.exponentialRampToValueAtTime(Math.max(20, freqEnd), t0 + dur);
  }
  g.gain.setValueAtTime(0.0001, t0);
  g.gain.exponentialRampToValueAtTime(gain, t0 + 0.012);
  g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
  osc.connect(g);
  g.connect(b);
  osc.start(t0);
  osc.stop(t0 + dur + 0.03);
}

function noiseBurst(
  dur: number,
  gain = 0.06,
  when = 0,
  filterFreq = 1200,
  filterType: BiquadFilterType = "lowpass",
  dest: GainNode | null = null,
) {
  if (muted) return;
  const c = getCtx();
  const b = dest ?? bus();
  if (!c || !b || !noiseBuf) return;
  const t0 = c.currentTime + when;
  const src = c.createBufferSource();
  src.buffer = noiseBuf;
  const f = c.createBiquadFilter();
  f.type = filterType;
  f.frequency.setValueAtTime(filterFreq, t0);
  const g = c.createGain();
  g.gain.setValueAtTime(0.0001, t0);
  g.gain.exponentialRampToValueAtTime(gain, t0 + 0.008);
  g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
  src.connect(f);
  f.connect(g);
  g.connect(b);
  src.start(t0);
  src.stop(t0 + dur + 0.02);
}

function pitchJitter(base = 1, amt = 0.08) {
  return base * (1 + (Math.random() * 2 - 1) * amt);
}

/** Low ocean wash + distant sonar bed while unmuted. */
export function startAmbient() {
  if (muted || ambNodes) return;
  const c = getCtx();
  if (!c || !ambiBus || !longNoise) return;
  if (c.state === "suspended") return;

  const src = c.createBufferSource();
  src.buffer = longNoise;
  src.loop = true;
  const f = c.createBiquadFilter();
  f.type = "lowpass";
  f.frequency.value = 420;
  const g = c.createGain();
  g.gain.value = 0.0001;
  g.gain.exponentialRampToValueAtTime(0.55, c.currentTime + 1.2);
  src.connect(f);
  f.connect(g);
  g.connect(ambiBus);
  src.start();

  // Soft distant ping every ~8s
  let pingTimer: ReturnType<typeof setInterval> | null = setInterval(() => {
    if (muted || !ambNodes) return;
    tone(640, 0.9, "sine", 0.012, 280);
    tone(480, 1.1, "sine", 0.008, 200, 0.05);
  }, 7800);

  ambNodes = {
    stop: () => {
      try {
        src.stop();
      } catch {
        /* */
      }
      if (pingTimer) clearInterval(pingTimer);
      pingTimer = null;
    },
  };
}

export function stopAmbient() {
  if (ambNodes) {
    ambNodes.stop();
    ambNodes = null;
  }
}

export function sfxTorpedo() {
  const p = pitchJitter(1, 0.05);
  tone(190 * p, 0.28, "sawtooth", 0.05, 55);
  tone(95 * p, 0.5, "sine", 0.04, 35);
  tone(320 * p, 0.12, "triangle", 0.025, 80, 0.04);
  noiseBurst(0.28, 0.04, 0, 900, "bandpass");
  noiseBurst(0.18, 0.03, 0.05, 2800, "highpass");
}

export function sfxSeekerLock() {
  tone(640, 0.08, "sine", 0.045);
  tone(960, 0.1, "sine", 0.04, undefined, 0.09);
  tone(1280, 0.14, "sine", 0.035, undefined, 0.18);
  noiseBurst(0.08, 0.02, 0.2, 4000, "highpass");
}

export function sfxExplosion() {
  const p = pitchJitter(1, 0.1);
  // Heavy body
  noiseBurst(0.75, 0.16, 0, 320 * p, "lowpass");
  noiseBurst(0.4, 0.12, 0.02, 900, "lowpass");
  // Crack / glass
  noiseBurst(0.28, 0.11, 0.01, 2800, "highpass");
  noiseBurst(0.18, 0.07, 0.06, 7000, "highpass");
  // Sub boom
  tone(100 * p, 0.6, "sawtooth", 0.1, 26);
  tone(48 * p, 0.95, "sine", 0.085, 16);
  tone(32 * p, 1.1, "sine", 0.05, 14, 0.05);
  tone(180, 0.2, "square", 0.05, 55, 0.04);
  // Anime punch layer
  tone(220 * p, 0.09, "square", 0.07, 85);
  tone(1400 * p, 0.06, "sine", 0.035, 380, 0.02);
  tone(700 * p, 0.08, "triangle", 0.03, 120, 0.05);
}

export function sfxSecondaryBoom() {
  noiseBurst(0.4, 0.08, 0, 280, "lowpass");
  tone(70, 0.45, "sine", 0.055, 25);
  tone(200, 0.12, "triangle", 0.03, 80);
}

export function sfxHit() {
  const p = pitchJitter(1, 0.12);
  noiseBurst(0.14, 0.06, 0, 1800, "bandpass");
  noiseBurst(0.08, 0.04, 0.01, 5000, "highpass");
  tone(240 * p, 0.14, "triangle", 0.06, 70);
  tone(520 * p, 0.06, "square", 0.03, 180);
}

/** Bright anime impact — slash + bass thump. */
export function sfxAnimeImpact(intensity = 1) {
  const p = pitchJitter(1, 0.08);
  const g = 0.05 * intensity;
  noiseBurst(0.12, g * 1.2, 0, 3500, "highpass");
  noiseBurst(0.28, g, 0.02, 500, "lowpass");
  tone(180 * p, 0.1, "square", g * 0.9, 60);
  tone(880 * p, 0.06, "sine", g * 0.5, 200);
  tone(60 * p, 0.35, "sine", g * 0.7, 30, 0.03);
}

export function sfxSonar() {
  tone(920, 0.1, "sine", 0.045);
  tone(720, 0.7, "sine", 0.035, 360, 0.06);
  tone(1100, 0.2, "sine", 0.025, 600, 0.12);
  noiseBurst(0.15, 0.015, 0.05, 2000, "bandpass");
}

export function sfxDepthCharge() {
  noiseBurst(0.2, 0.05, 0, 600, "lowpass");
  tone(65, 0.35, "square", 0.05, 35);
  tone(40, 0.55, "sine", 0.035, 22, 0.15);
}

export function sfxDepthChargeDetonate() {
  noiseBurst(0.5, 0.12, 0, 450, "lowpass");
  noiseBurst(0.22, 0.07, 0.03, 2800, "highpass");
  tone(90, 0.4, "sawtooth", 0.07, 30);
  tone(55, 0.6, "sine", 0.05, 22);
  sfxAnimeImpact(0.7);
}

export function sfxClick() {
  tone(560 * pitchJitter(1, 0.04), 0.04, "sine", 0.03);
  tone(900, 0.03, "sine", 0.015, undefined, 0.02);
}

export function sfxSplash() {
  noiseBurst(0.25, 0.05, 0, 2600, "highpass");
  tone(280, 0.2, "triangle", 0.04, 90);
  tone(160, 0.15, "sine", 0.025, 50, 0.05);
}

export function sfxAlarm() {
  tone(880, 0.12, "square", 0.045);
  tone(660, 0.12, "square", 0.04, undefined, 0.14);
  tone(880, 0.12, "square", 0.045, undefined, 0.28);
  tone(990, 0.08, "square", 0.03, undefined, 0.4);
}

export function sfxDetect() {
  tone(440, 0.06, "triangle", 0.035);
  tone(660, 0.08, "triangle", 0.03, undefined, 0.07);
  tone(880, 0.06, "sine", 0.02, undefined, 0.14);
}

export function sfxWaveClear() {
  tone(392, 0.12, "sine", 0.045);
  tone(523, 0.12, "sine", 0.045, undefined, 0.1);
  tone(659, 0.18, "sine", 0.05, undefined, 0.2);
  tone(784, 0.3, "sine", 0.045, undefined, 0.32);
  noiseBurst(0.2, 0.02, 0.3, 2000, "bandpass");
}

export function sfxVictory() {
  tone(523, 0.15, "sine", 0.05);
  tone(659, 0.15, "sine", 0.05, undefined, 0.12);
  tone(784, 0.15, "sine", 0.055, undefined, 0.24);
  tone(1046, 0.45, "sine", 0.055, undefined, 0.36);
  noiseBurst(0.3, 0.025, 0.2, 3000, "highpass");
}

export function sfxGameOver() {
  tone(220, 0.4, "sawtooth", 0.055, 80);
  tone(140, 0.65, "sine", 0.05, 40, 0.1);
  noiseBurst(0.6, 0.05, 0.05, 200, "lowpass");
  tone(90, 0.8, "sine", 0.03, 35, 0.2);
}

export function sfxEnginePulse(intensity = 0.5) {
  if (muted || intensity < 0.08) return;
  const now = performance.now();
  if (now - lastEngine < 90) return;
  lastEngine = now;
  const g = 0.01 + intensity * 0.022;
  tone(48 + intensity * 28, 0.1, "sine", g, 38);
  if (intensity > 0.5) tone(90 + intensity * 20, 0.06, "triangle", g * 0.5, 50);
}

export function sfxShellSplash() {
  noiseBurst(0.12, 0.04, 0, 3200, "highpass");
  tone(400, 0.1, "triangle", 0.03, 120);
  tone(200, 0.08, "sine", 0.02, 80, 0.03);
}

export function sfxBubbleScreen() {
  noiseBurst(0.4, 0.06, 0, 1600, "bandpass");
  tone(200, 0.3, "sine", 0.035, 80);
  tone(320, 0.22, "sine", 0.025, 100, 0.08);
  tone(140, 0.2, "sine", 0.02, 70, 0.12);
}

export function sfxFoxer() {
  tone(180, 0.18, "sawtooth", 0.035, 120);
  tone(240, 0.45, "triangle", 0.03, 90, 0.05);
  noiseBurst(0.35, 0.03, 0, 900, "bandpass");
}

export function sfxPowerup() {
  tone(523, 0.08, "sine", 0.04);
  tone(659, 0.1, "sine", 0.04, undefined, 0.07);
  tone(880, 0.14, "sine", 0.045, undefined, 0.15);
  noiseBurst(0.1, 0.02, 0.05, 4000, "highpass");
}

export function sfxWhoosh() {
  noiseBurst(0.22, 0.05, 0, 1800, "bandpass");
  tone(300, 0.2, "triangle", 0.025, 80);
}
