/**
 * Acoustic detection model for Silent Depths.
 *
 * Inspired by real ASW (scaled to the 96-tile sector):
 *  - Passive hydrophones: always-on listening. Range tracks target noise
 *    (prop / machinery). Quiet deep targets are hard to hear. No range ping —
 *    bearing + SNR only until multiple sweeps refine position.
 *  - Active sonar (ASDIC / ping): short pulse gives range + bearing but
 *    broadcasts your position. WW2 sets were roughly 1–3 nmi; here ~22 tiles.
 *  - Thermocline (~0.5 depth): surface listeners struggle vs deep targets;
 *    deep listeners hear surface traffic better through the layer edge.
 *  - Destroyers / ASW cruisers: best active + passive. Freighters: weak ears.
 *  - Bubble screens / foxers: mask and spoof as noise sources.
 */
import { angleDiff, clamp, dist } from "./iso";
import type { GameState, Ship, ShipClass, SonarContact } from "./types";

/** Game tiles ≈ rough acoustic scale (not literal yards). */
export const ACTIVE_PING_RANGE = 22;
export const ACTIVE_PING_DURATION = 4.8;
export const ACTIVE_COOLDOWN = 6.5;

/** Base passive listen radii by platform (before noise / layer factors). */
const LISTENER_PASSIVE: Record<ShipClass | "player", number> = {
  player: 18,
  patrol: 11,
  destroyer: 20,
  freighter: 7,
  cruiser: 17,
  battleship: 14,
  sub: 16,
};

/** How noisy a surface unit is at flank (0–1). */
export function shipMachineryNoise(ship: Ship): number {
  const speedFrac = clamp(ship.speed / Math.max(0.2, ship.maxSpeed), 0, 1);
  let base = 0.35;
  switch (ship.class) {
    case "freighter":
      base = 0.72;
      break;
    case "battleship":
      base = 0.65;
      break;
    case "cruiser":
      base = 0.48;
      break;
    case "destroyer":
      base = 0.42;
      break;
    case "patrol":
      base = 0.38;
      break;
    case "sub":
      // U-boats are quiet when crawling; noisy when sprinting
      base = 0.18;
      break;
  }
  const wake = speedFrac * speedFrac * 0.55;
  const alertBump = ship.alert > 0.5 ? 0.08 : 0;
  return clamp(base * 0.45 + wake + alertBump, 0.08, 1);
}

/**
 * Thermocline / layer factor: 1 = free propagation, lower = masked.
 * Surface→deep is hard; deep→surface is easier (downward refraction simplified).
 */
export function layerFactor(listenerDepth: number, targetDepth: number): number {
  const L = 0.48; // thermocline band center
  const listenerAbove = listenerDepth < L;
  const targetAbove = targetDepth < L;
  if (listenerAbove === targetAbove) return 1;
  // Crossing the layer
  if (listenerAbove && !targetAbove) {
    // Surface ASW vs deep sub — tough without active
    const howDeep = clamp((targetDepth - L) / 0.5, 0, 1);
    return 0.42 - howDeep * 0.18;
  }
  // Deep listener hearing surface traffic
  return 0.78;
}

export function passiveRange(
  listenerKind: ShipClass | "player",
  targetNoise: number,
  listenerDepth: number,
  targetDepth: number,
  cmMask = 1,
): number {
  const base = LISTENER_PASSIVE[listenerKind] ?? 12;
  const noiseGain = 0.35 + targetNoise * 1.35;
  const layer = layerFactor(listenerDepth, targetDepth);
  // Active receiver depth: slightly better when submerged (array wet)
  const immersion = listenerDepth > 0.08 ? 1.08 : 0.92;
  return base * noiseGain * layer * immersion * cmMask;
}

export function activeRange(listenerKind: ShipClass | "player", listenerDepth: number): number {
  let base = ACTIVE_PING_RANGE;
  if (listenerKind === "destroyer") base = 24;
  else if (listenerKind === "cruiser") base = 22;
  else if (listenerKind === "battleship") base = 18;
  else if (listenerKind === "patrol") base = 14;
  else if (listenerKind === "freighter") base = 8;
  else if (listenerKind === "sub") base = 16;
  // Surface cavitation / rough seas — slight penalty when very shallow
  if (listenerDepth < 0.1) base *= 0.9;
  if (listenerDepth > 0.7) base *= 0.85; // deep / bottom bounce clutter
  return base;
}

function classifyShip(ship: Ship, strength: number): string {
  if (strength < 0.28) return "CONTACT";
  if (strength < 0.5) return ship.class === "sub" ? "SUB?" : "MERCHANT?";
  if (ship.class === "sub") return "U-BOAT";
  if (ship.class === "battleship") return "CAPITAL";
  if (ship.class === "destroyer") return "ESCORT";
  if (ship.class === "cruiser") return "CRUISER";
  if (ship.class === "freighter") return "MERCHANT";
  return "PATROL";
}

function cmMaskAt(state: GameState, x: number, y: number): number {
  let mask = 1;
  for (const cm of state.countermeasures) {
    if (cm.kind !== "bubble") continue;
    if (dist(cm.x, cm.y, x, y) < cm.radius + 2.5) {
      mask *= 1 - cm.strength * 0.55;
    }
  }
  return mask;
}

/** Enemy passive/active detection range vs a noisy contact (player or peer). */
export function enemyDetectRange(
  ship: Ship,
  target: { x: number; y: number; z: number; noise: number },
  state: GameState,
): { passive: number; canActive: boolean; active: number } {
  const mask = cmMaskAt(state, target.x, target.y);
  const targetDepth = target.z;
  // Surface ships sit at depth 0; U-boats ~0.35
  const listenerDepth = ship.class === "sub" ? 0.35 : 0.02;
  let passive = passiveRange(ship.class, target.noise, listenerDepth, targetDepth, mask);

  // Hearing an active ping nearby boosts cueing
  if (state.sonarPing > ACTIVE_PING_DURATION - 1.2) {
    const dPing = dist(ship.x, ship.y, state.sub.x, state.sub.y);
    if (dPing < ACTIVE_PING_RANGE + 6) passive *= 1.35;
  }

  const asw =
    ship.class === "destroyer" || ship.class === "cruiser" || ship.class === "battleship";
  const canActive = asw && ship.alert > 0.35;
  const active = canActive ? activeRange(ship.class, listenerDepth) * (0.85 + ship.alert * 0.2) : 0;

  return { passive, canActive, active };
}

/**
 * Rebuild player sonar contacts from passive listen + active returns.
 * Passive: continuous SNR contacts with jittered position when weak.
 * Active: precise marks while ping expands.
 */
export function updatePlayerSonar(state: GameState, dt: number): void {
  if (!state.sonarContacts) state.sonarContacts = [];
  if (state.sonarActiveCooldown == null) state.sonarActiveCooldown = 0;
  if (state.sonarSweep == null) state.sonarSweep = 0;

  state.sonarSweep = (state.sonarSweep + dt * 0.85) % (Math.PI * 2);
  if (state.sonarActiveCooldown > 0) {
    state.sonarActiveCooldown = Math.max(0, state.sonarActiveCooldown - dt);
  }
  if (state.sonarPing > 0) state.sonarPing = Math.max(0, state.sonarPing - dt);

  const boat = state.sub;
  const listenerDepth = boat.z;
  const next: SonarContact[] = [];

  // Decay existing contacts smoothly (prevents hydrophone list flicker)
  for (const c of state.sonarContacts) {
    c.age += dt;
    if (c.age < c.maxAge) {
      // fade strength slightly
      c.strength *= 0.97;
      next.push(c);
    }
  }

  const activeRadius =
    state.sonarPing > 0
      ? ((ACTIVE_PING_DURATION - state.sonarPing) / 1.05) * activeRange("player", listenerDepth)
      : 0;
  const activeMax = activeRange("player", listenerDepth);

  for (const ship of state.ships) {
    if (ship.dead || ship.sinking > 0.6) continue;
    const d = dist(ship.x, ship.y, boat.x, boat.y);
    const targetDepth = ship.class === "sub" ? 0.35 : 0.02;
    const noise = shipMachineryNoise(ship);
    const mask = cmMaskAt(state, ship.x, ship.y);
    const pRange = passiveRange("player", noise, listenerDepth, targetDepth, mask);

    // Passive contact
    if (d < pRange) {
      const strength = clamp(1 - d / pRange, 0.12, 1) * (0.55 + noise * 0.55);
      // Soft bearing uncertainty — small so blips don't thrash positions
      const jitter = (1 - strength) * 0.55;
      const jx = ship.x + Math.sin(state.time * 0.4 + ship.id) * jitter;
      const jy = ship.y + Math.cos(state.time * 0.35 + ship.id * 0.7) * jitter;
      const bearing = Math.atan2(jy - boat.y, jx - boat.x);
      next.push({
        id: ship.id * 10 + 1,
        targetId: ship.id,
        x: jx,
        y: jy,
        bearing,
        range: d,
        strength,
        label: classifyShip(ship, strength),
        source: "passive",
        age: 0,
        maxAge: 1.15,
      });
    }

    // Active return — only when ping wavefront has reached the contact
    if (state.sonarPing > 0 && d < activeMax && d < activeRadius + 1.2 && d > activeRadius - 3.5) {
      const strength = clamp(1 - d / activeMax, 0.3, 1);
      next.push({
        id: ship.id * 10 + 2,
        targetId: ship.id,
        x: ship.x,
        y: ship.y,
        bearing: Math.atan2(ship.y - boat.y, ship.x - boat.x),
        range: d,
        strength,
        label: classifyShip(ship, Math.min(1, strength + 0.25)),
        source: "active",
        age: 0,
        maxAge: 2.8,
      });
    } else if (state.sonarPing > 0 && d < activeRadius && d < activeMax) {
      // Already swept — solid track for a few seconds
      const strength = clamp(1 - d / activeMax, 0.35, 1);
      next.push({
        id: ship.id * 10 + 2,
        targetId: ship.id,
        x: ship.x,
        y: ship.y,
        bearing: Math.atan2(ship.y - boat.y, ship.x - boat.x),
        range: d,
        strength,
        label: classifyShip(ship, Math.min(1, strength + 0.3)),
        source: "active",
        age: 0,
        maxAge: 2.4,
      });
    }
  }

  // Foxer as false contact for player (confusing)
  for (const cm of state.countermeasures) {
    if (cm.kind !== "foxer") continue;
    const d = dist(cm.x, cm.y, boat.x, boat.y);
    if (d < 20) {
      next.push({
        id: cm.id * 10 + 3,
        targetId: null,
        x: cm.x,
        y: cm.y,
        bearing: Math.atan2(cm.y - boat.y, cm.x - boat.x),
        range: d,
        strength: 0.7,
        label: "NOISE",
        source: "passive",
        age: 0,
        maxAge: 0.3,
      });
    }
  }

  // Merge by targetId preferring active over passive
  const byKey = new Map<string, SonarContact>();
  for (const c of next) {
    const key = c.targetId != null ? `t${c.targetId}` : `i${c.id}`;
    const prev = byKey.get(key);
    if (!prev) {
      byKey.set(key, c);
      continue;
    }
    if (c.source === "active" && prev.source !== "active") byKey.set(key, c);
    else if (c.source === prev.source && c.strength > prev.strength) byKey.set(key, c);
  }
  state.sonarContacts = Array.from(byKey.values());
}

export function fireActiveSonar(state: GameState): boolean {
  if (state.phase !== "playing") return false;
  if (state.sonarActiveCooldown > 0) return false;
  if (state.sonarPing > 0) return false;
  state.sonarPing = ACTIVE_PING_DURATION;
  state.sonarActiveCooldown = ACTIVE_COOLDOWN;
  // Active ping is LOUD — reveals you
  state.sub.noise = Math.min(1, state.sub.noise + 0.62);
  return true;
}

/** Bearing error helper for AI (degrees of uncertainty). */
export function bearingUncertainty(strength: number): number {
  return (1 - clamp(strength, 0, 1)) * 0.55;
}

export function isShipDetectedByPlayer(state: GameState, shipId: number): boolean {
  return state.sonarContacts?.some((c) => c.targetId === shipId && c.strength > 0.15) ?? false;
}
