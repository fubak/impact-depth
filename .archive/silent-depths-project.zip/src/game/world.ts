import { fbm, hash2, ISO_Z_PX } from "./iso";
import type { TerrainCell } from "./types";

export const WORLD_SIZE = 96;
/** Height at/above this is dry land (impassable). */
export const LAND_LEVEL = 0.78;

/**
 * Legacy exaggeration curve (pre-unified Z). Kept for the shaping math;
 * convert with elevationWorldZ() before projecting.
 */
export function elevationVisual(height: number, land: boolean): number {
  if (land) {
    const above = Math.max(0, height - LAND_LEVEL);
    return 10 + above * 95 + Math.pow(above * 4.2, 1.45) * 18;
  }
  if (height > 0.55) return (height - 0.35) * 36;
  if (height < 0.25) return height * 8 - 6;
  return height * 14;
}

/**
 * Seafloor / land height in **world-z** units (same scale as depthToWorldZ).
 * 0 ≈ water surface; positive = above (land); slightly negative = deep sand.
 *
 * Calibrated so elevPx ≈ old `elevationVisual * zoom * 0.55`.
 */
export function elevationWorldZ(height: number, land: boolean): number {
  return (elevationVisual(height, land) * 0.55) / ISO_Z_PX;
}

/** Pixel height of a terrain extrusion at the given zoom. */
export function elevationScreenPx(height: number, land: boolean, zoom: number): number {
  return Math.max(0, elevationWorldZ(height, land) * ISO_Z_PX * zoom);
}

export function generateTerrain(seed: number): TerrainCell[][] {
  const grid: TerrainCell[][] = [];
  for (let y = 0; y < WORLD_SIZE; y++) {
    const row: TerrainCell[] = [];
    for (let x = 0; x < WORLD_SIZE; x++) {
      const nx = x / WORLD_SIZE;
      const ny = y / WORLD_SIZE;
      const ridge = fbm(nx * 3.2, ny * 3.2, seed, 5);
      const trench = fbm(nx * 2.1 + 20, ny * 2.1, seed + 7, 3);
      const detail = fbm(nx * 8, ny * 8, seed + 3, 3);
      const island = fbm(nx * 4.5 + 30, ny * 4.5 - 10, seed + 19, 4);
      const range = fbm(nx * 6.5 - 5, ny * 2.2 + 8, seed + 41, 4);

      const edgeDist = Math.min(nx, ny, 1 - nx, 1 - ny);
      const edgeLand = edgeDist < 0.12 ? (0.12 - edgeDist) / 0.12 : 0;

      let height = ridge * 0.4 + detail * 0.14;
      if (trench > 0.58) height *= 0.22 + (1 - trench) * 0.35;

      if (range > 0.7) height = Math.max(height, 0.55 + (range - 0.7) * 1.4);

      const seamount = fbm(nx * 5.5 + 50, ny * 5.5, seed + 11, 3);
      if (seamount > 0.68) {
        height = Math.max(height, (seamount - 0.5) * 1.35);
      }
      const cone = fbm(nx * 9 + 12, ny * 9 - 3, seed + 77, 2);
      if (cone > 0.82 && seamount > 0.6) {
        height = Math.max(height, 0.75 + (cone - 0.82) * 2.2);
      }

      if (edgeLand > 0.12) {
        height = Math.max(height, 0.7 + edgeLand * 0.42 + detail * 0.1 + ridge * 0.08);
      }
      if (island > 0.64) {
        const peak = (island - 0.58) * 1.75;
        height = Math.max(height, 0.68 + peak);
        if (island > 0.78) height = Math.max(height, 0.86 + (island - 0.78) * 1.5);
      }

      const dx = nx - 0.5;
      const dy = ny - 0.52;
      const centerDist = Math.hypot(dx, dy);
      if (centerDist < 0.18) {
        height = Math.min(height, 0.32 + centerDist * 1.35);
      }
      const dx2 = nx - 0.68;
      const dy2 = ny - 0.45;
      if (Math.hypot(dx2, dy2) < 0.1) {
        height = Math.min(height, 0.4 + Math.hypot(dx2, dy2) * 2);
      }

      height = Math.max(0, Math.min(1, height));
      const land = height >= LAND_LEVEL;

      let biome = 0;
      if (land) {
        if (height > 0.94) biome = 6;
        else if (height > 0.88) biome = 6;
        else if (height > 0.83) biome = 5;
        else if (height > 0.8) biome = 5;
        else biome = 4;
      } else if (height > 0.62) {
        biome = 1;
      } else if (height < 0.18) {
        biome = 3;
      } else if (detail > 0.55 && height < 0.55) {
        biome = 2;
      } else {
        biome = 0;
      }

      const plantNoise = hash2(x, y, seed + 99);
      let plant = 0;
      let plantType = 0;
      if (land) {
        if (biome === 5 && plantNoise > 0.18) {
          plant = 0.55 + plantNoise * 0.45;
          plantType = 4;
        } else if (biome === 4 && plantNoise > 0.68) {
          plant = 0.3 + plantNoise * 0.35;
          plantType = 5;
        } else if (biome === 6 && plantNoise > 0.5) {
          plant = 0.15 + plantNoise * 0.2;
          plantType = 6;
        }
      } else if (biome === 2 && plantNoise > 0.32) {
        plant = 0.4 + plantNoise * 0.6;
        plantType = plantNoise > 0.7 ? 1 : 0;
      } else if (biome === 0 && plantNoise > 0.76 && height < 0.5) {
        plant = 0.2 + plantNoise * 0.3;
        plantType = 2;
      } else if (biome === 3 && plantNoise > 0.82) {
        plant = 0.15;
        plantType = 3;
      }

      row.push({ height, biome, plant, plantType, land });
    }
    grid.push(row);
  }
  return grid;
}

export function sampleTerrain(grid: TerrainCell[][], x: number, y: number): TerrainCell {
  const ix = Math.max(0, Math.min(WORLD_SIZE - 1, Math.floor(x)));
  const iy = Math.max(0, Math.min(WORLD_SIZE - 1, Math.floor(y)));
  return grid[iy]![ix]!;
}

export function sampleHeight(grid: TerrainCell[][], x: number, y: number): number {
  const x0 = Math.floor(x);
  const y0 = Math.floor(y);
  const fx = x - x0;
  const fy = y - y0;
  const h00 = sampleTerrain(grid, x0, y0).height;
  const h10 = sampleTerrain(grid, x0 + 1, y0).height;
  const h01 = sampleTerrain(grid, x0, y0 + 1).height;
  const h11 = sampleTerrain(grid, x0 + 1, y0 + 1).height;
  const hx0 = h00 + (h10 - h00) * fx;
  const hx1 = h01 + (h11 - h01) * fx;
  return hx0 + (hx1 - hx0) * fy;
}

export function floorClearance(grid: TerrainCell[][], x: number, y: number): number {
  const t = sampleTerrain(grid, x, y);
  if (t.land) return 0.02;
  return Math.max(0.05, 1 - t.height * 0.95);
}

export function isLand(grid: TerrainCell[][], x: number, y: number): boolean {
  return sampleTerrain(grid, x, y).land;
}

export function isNavigable(
  grid: TerrainCell[][],
  x: number,
  y: number,
  depth: number,
): boolean {
  if (x < 1 || y < 1 || x >= WORLD_SIZE - 1 || y >= WORLD_SIZE - 1) return false;
  if (isLand(grid, x, y)) return false;
  const clear = floorClearance(grid, x, y);
  return depth <= clear + 0.02;
}

export function isShipNavigable(grid: TerrainCell[][], x: number, y: number): boolean {
  if (x < 2 || y < 2 || x >= WORLD_SIZE - 2 || y >= WORLD_SIZE - 2) return false;
  const t = sampleTerrain(grid, x, y);
  return !t.land && t.height < 0.88;
}
