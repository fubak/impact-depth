/**
 * Cascaded Shadow Maps (CSM) for the isometric theater — WebGL2.
 *
 * 3 cascades (near / mid / far), each an orthographic screen-space region
 * mapped to its own R8 shadow map at a different resolution:
 *
 *   Cascade 0 (near): tight around view center → highest texel density
 *   Cascade 1 (mid):  medium ring
 *   Cascade 2 (far):  full view → lowest res, covers horizon / land
 *
 * Pipeline per cascade: cast blobs → separable Gaussian blur
 * Composite: pick cascade by distance-from-center, soft-blend at splits,
 * output premultiplied darken layer (bilinear-upscaled by 2D canvas).
 */

export type ShadowCaster = {
  sx: number;
  sy: number;
  rx: number;
  ry: number;
  height: number;
  depth?: number;
  strength?: number;
};

export type CascadeInfo = {
  index: number;
  /** Texture resolution. */
  res: number;
  /** Half-extent of cascade region in UV (0.5 = full screen). */
  halfExtent: number;
  bytes: number;
  casters: number;
};

export type ShadowMapStats = {
  viewW: number;
  viewH: number;
  mapW: number;
  mapH: number;
  scale: number;
  bytes: number;
  casters: number;
  cascades: CascadeInfo[];
  /** Split distances in UV radius (0..~0.71 diagonal). */
  splits: [number, number];
};

type GL = WebGL2RenderingContext;

const MAX_CASTERS = 48; // per cascade budget
const NUM_CASCADES = 3;
const RESIZE_HYSTERESIS = 16;

/** Near → far: texel budget + coverage half-extent in UV (from view center). */
const CASCADE_CFG = [
  { res: 256, halfExtent: 0.24 }, // near
  { res: 192, halfExtent: 0.44 }, // mid
  { res: 128, halfExtent: 0.72 }, // far
] as const;

/** Soft blend band at cascade boundaries (UV radius). */
const CASCADE_BLEND = 0.04;

const VERT_FULL = `#version 300 es
precision highp float;
layout(location=0) in vec2 a_pos;
out vec2 v_uv;
void main(){
  v_uv = a_pos * 0.5 + 0.5;
  gl_Position = vec4(a_pos, 0.0, 1.0);
}`;

// Cast into cascade UV space: u_region = (centerUV.xy, halfExtent.x, halfExtent.y)
const FRAG_CAST = `#version 300 es
precision mediump float;
in vec2 v_uv;
layout(location=0) out vec4 o;
uniform vec2 u_sun;          // cast dir in *cascade* UV
uniform vec4 u_region;       // xy = region center screen-UV, zw = half extents screen-UV
uniform int u_count;
uniform vec4 u_casters[48];  // xy screen-UV, zw radii in screen-UV
uniform vec2 u_meta[48];     // x strength, y height

void main(){
  // Cascade UV → screen UV
  vec2 screenUV = u_region.xy + (v_uv - 0.5) * 2.0 * u_region.zw;
  float shadow = 0.0;
  for (int i = 0; i < 48; i++) {
    if (i >= u_count) break;
    vec4 c = u_casters[i];
    vec2 meta = u_meta[i];
    // Project caster along sun (in screen UV), then to cascade space for falloff scale
    vec2 centerScreen = c.xy + u_sun * meta.y * 0.5;
    // Convert radii from screen UV into cascade UV
    vec2 radCascade = c.zw / max(u_region.zw * 2.0, vec2(1e-4));
    vec2 centerCascade = 0.5 + (centerScreen - u_region.xy) / max(u_region.zw * 2.0, vec2(1e-4));
    vec2 d = (v_uv - centerCascade) / max(radCascade, vec2(1e-4));
    float r = length(d);
    float blob = smoothstep(1.2, 0.15, r);
    blob *= meta.x * (0.55 + 0.45 * clamp(meta.y, 0.0, 1.5));
    shadow = max(shadow, blob);
  }
  o = vec4(shadow, 0.0, 0.0, 1.0);
}`;

const FRAG_BLUR = `#version 300 es
precision mediump float;
in vec2 v_uv;
layout(location=0) out vec4 o;
uniform sampler2D u_tex;
uniform vec2 u_dir;
void main(){
  float w0 = 0.227027;
  float w1 = 0.1945946;
  float w2 = 0.1216216;
  float w3 = 0.054054;
  float w4 = 0.016216;
  float s = texture(u_tex, v_uv).r * w0;
  s += texture(u_tex, v_uv + u_dir * 1.0).r * w1;
  s += texture(u_tex, v_uv - u_dir * 1.0).r * w1;
  s += texture(u_tex, v_uv + u_dir * 2.0).r * w2;
  s += texture(u_tex, v_uv - u_dir * 2.0).r * w2;
  s += texture(u_tex, v_uv + u_dir * 3.0).r * w3;
  s += texture(u_tex, v_uv - u_dir * 3.0).r * w3;
  s += texture(u_tex, v_uv + u_dir * 4.0).r * w4;
  s += texture(u_tex, v_uv - u_dir * 4.0).r * w4;
  o = vec4(s, 0.0, 0.0, 1.0);
}`;

// Sample 3 cascades by distance from focus; soft cross-fade at splits
const FRAG_COMP = `#version 300 es
precision mediump float;
in vec2 v_uv;
layout(location=0) out vec4 o;
uniform sampler2D u_near;
uniform sampler2D u_mid;
uniform sampler2D u_far;
uniform vec4 u_region0; // center.xy, half.zw for each cascade
uniform vec4 u_region1;
uniform vec4 u_region2;
uniform vec2 u_splits;  // split radii (screen UV distance from center)
uniform float u_opacity;
uniform float u_debug;  // >0.5 tint cascades for debug

vec2 toCascadeUV(vec2 screenUV, vec4 region) {
  return 0.5 + (screenUV - region.xy) / max(region.zw * 2.0, vec2(1e-4));
}

float sampleCascade(sampler2D tex, vec2 screenUV, vec4 region) {
  vec2 cuv = toCascadeUV(screenUV, region);
  // Outside cascade frustum → no contribution
  if (cuv.x < 0.0 || cuv.x > 1.0 || cuv.y < 0.0 || cuv.y > 1.0) return 0.0;
  // Edge fade inside cascade to hide hard borders
  float edge = min(min(cuv.x, 1.0 - cuv.x), min(cuv.y, 1.0 - cuv.y));
  float fade = smoothstep(0.0, 0.06, edge);
  return texture(tex, cuv).r * fade;
}

void main(){
  vec2 focus = u_region0.xy; // near cascade centered on focus
  float dist = length(v_uv - focus);

  float s0 = sampleCascade(u_near, v_uv, u_region0);
  float s1 = sampleCascade(u_mid, v_uv, u_region1);
  float s2 = sampleCascade(u_far, v_uv, u_region2);

  float split0 = u_splits.x;
  float split1 = u_splits.y;
  float blend = 0.04;

  // Weights: prefer nearer cascade; blend across splits
  float w0 = 1.0 - smoothstep(split0 - blend, split0 + blend, dist);
  float w1 = smoothstep(split0 - blend, split0 + blend, dist)
           * (1.0 - smoothstep(split1 - blend, split1 + blend, dist));
  float w2 = smoothstep(split1 - blend, split1 + blend, dist);
  float wsum = max(w0 + w1 + w2, 1e-4);
  w0 /= wsum; w1 /= wsum; w2 /= wsum;

  float s = s0 * w0 + s1 * w1 + s2 * w2;
  float a = s * u_opacity;

  vec3 col = vec3(0.01, 0.03, 0.06);
  if (u_debug > 0.5) {
    // RGB tint by dominant cascade
    col = vec3(w0, w1, w2) * 0.35 + col * 0.65;
    a = max(a, 0.12 * max(w0, max(w1, w2)));
  }
  o = vec4(col * a, a);
}`;

function compile(gl: GL, type: number, src: string): WebGLShader {
  const sh = gl.createShader(type)!;
  gl.shaderSource(sh, src);
  gl.compileShader(sh);
  if (!gl.getShaderParameter(sh, gl.COMPILE_STATUS)) {
    const log = gl.getShaderInfoLog(sh);
    gl.deleteShader(sh);
    throw new Error(`Shader compile: ${log}`);
  }
  return sh;
}

function link(gl: GL, vs: string, fs: string): WebGLProgram {
  const p = gl.createProgram()!;
  const v = compile(gl, gl.VERTEX_SHADER, vs);
  const f = compile(gl, gl.FRAGMENT_SHADER, fs);
  gl.attachShader(p, v);
  gl.attachShader(p, f);
  gl.linkProgram(p);
  gl.deleteShader(v);
  gl.deleteShader(f);
  if (!gl.getProgramParameter(p, gl.LINK_STATUS)) {
    const log = gl.getProgramInfoLog(p);
    gl.deleteProgram(p);
    throw new Error(`Program link: ${log}`);
  }
  return p;
}

function snapDim(n: number): number {
  return Math.max(8, Math.round(n / 8) * 8);
}

/** Scale cascade res with view size while keeping near denser than far. */
export function computeCascadeResolutions(
  viewW: number,
  viewH: number,
): number[] {
  const longEdge = Math.max(viewW, viewH);
  // On small mobile views, shrink all cascades proportionally
  const fit = Math.min(1, 900 / Math.max(longEdge, 1));
  return CASCADE_CFG.map((c) => snapDim(c.res * fit));
}

type Target = {
  tex: WebGLTexture;
  fbo: WebGLFramebuffer;
  w: number;
  h: number;
  bytes: number;
};

function makeTarget(gl: GL, w: number, h: number, useR8: boolean): Target {
  const tex = gl.createTexture()!;
  gl.bindTexture(gl.TEXTURE_2D, tex);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);

  let bytes: number;
  if (useR8) {
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.R8, w, h, 0, gl.RED, gl.UNSIGNED_BYTE, null);
    bytes = w * h;
  } else {
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA8, w, h, 0, gl.RGBA, gl.UNSIGNED_BYTE, null);
    bytes = w * h * 4;
  }

  const fbo = gl.createFramebuffer()!;
  gl.bindFramebuffer(gl.FRAMEBUFFER, fbo);
  gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, tex, 0);
  const status = gl.checkFramebufferStatus(gl.FRAMEBUFFER);
  gl.bindFramebuffer(gl.FRAMEBUFFER, null);
  if (status !== gl.FRAMEBUFFER_COMPLETE) {
    gl.deleteTexture(tex);
    gl.deleteFramebuffer(fbo);
    throw new Error(`FBO incomplete: 0x${status.toString(16)}`);
  }
  return { tex, fbo, w, h, bytes };
}

function destroyTarget(gl: GL, t: Target | null) {
  if (!t) return;
  gl.deleteTexture(t.tex);
  gl.deleteFramebuffer(t.fbo);
}

function probeR8(gl: GL): boolean {
  try {
    const t = makeTarget(gl, 8, 8, true);
    destroyTarget(gl, t);
    return true;
  } catch {
    return false;
  }
}

type CascadeBuffers = {
  a: Target; // cast + final blur
  b: Target; // blur ping
  res: number;
  halfExtent: number;
  casterCount: number;
};

type Locs = {
  castSun: WebGLUniformLocation | null;
  castRegion: WebGLUniformLocation | null;
  castCount: WebGLUniformLocation | null;
  castCasters: (WebGLUniformLocation | null)[];
  castMeta: (WebGLUniformLocation | null)[];
  blurTex: WebGLUniformLocation | null;
  blurDir: WebGLUniformLocation | null;
  compNear: WebGLUniformLocation | null;
  compMid: WebGLUniformLocation | null;
  compFar: WebGLUniformLocation | null;
  compR0: WebGLUniformLocation | null;
  compR1: WebGLUniformLocation | null;
  compR2: WebGLUniformLocation | null;
  compSplits: WebGLUniformLocation | null;
  compOpacity: WebGLUniformLocation | null;
  compDebug: WebGLUniformLocation | null;
};

export class GpuShadowMaps {
  canvas: HTMLCanvasElement;
  private gl: GL | null = null;
  private castProg: WebGLProgram | null = null;
  private blurProg: WebGLProgram | null = null;
  private compProg: WebGLProgram | null = null;
  private vao: WebGLVertexArrayObject | null = null;
  private cascades: CascadeBuffers[] = [];
  private viewW = 0;
  private viewH = 0;
  private useR8 = true;
  private ready = false;
  private casters: ShadowCaster[] = [];
  private locs: Locs | null = null;
  /** Focus in screen pixels (defaults to view center). */
  private focusX = 0;
  private focusY = 0;
  /** Tint cascades RGB for debug. */
  debugCascades = false;
  private lastStats: ShadowMapStats = {
    viewW: 0,
    viewH: 0,
    mapW: 0,
    mapH: 0,
    scale: 0,
    bytes: 0,
    casters: 0,
    cascades: [],
    splits: [0.22, 0.42],
  };

  constructor() {
    this.canvas = document.createElement("canvas");
    this.canvas.width = 4;
    this.canvas.height = 4;
  }

  get available(): boolean {
    return this.ready;
  }

  get stats(): ShadowMapStats {
    return this.lastStats;
  }

  init(): boolean {
    if (this.ready) return true;
    if (typeof document === "undefined") return false;
    const gl = this.canvas.getContext("webgl2", {
      alpha: true,
      premultipliedAlpha: true,
      antialias: false,
      depth: false,
      stencil: false,
      preserveDrawingBuffer: true,
      powerPreference: "high-performance",
    } as WebGLContextAttributes);
    if (!gl) return false;
    this.gl = gl;
    this.useR8 = probeR8(gl);

    try {
      this.castProg = link(gl, VERT_FULL, FRAG_CAST);
      this.blurProg = link(gl, VERT_FULL, FRAG_BLUR);
      this.compProg = link(gl, VERT_FULL, FRAG_COMP);

      const buf = gl.createBuffer()!;
      gl.bindBuffer(gl.ARRAY_BUFFER, buf);
      gl.bufferData(
        gl.ARRAY_BUFFER,
        new Float32Array([-1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1, 1]),
        gl.STATIC_DRAW,
      );
      this.vao = gl.createVertexArray()!;
      gl.bindVertexArray(this.vao);
      gl.enableVertexAttribArray(0);
      gl.vertexAttribPointer(0, 2, gl.FLOAT, false, 0, 0);
      gl.bindVertexArray(null);

      this.locs = {
        castSun: gl.getUniformLocation(this.castProg, "u_sun"),
        castRegion: gl.getUniformLocation(this.castProg, "u_region"),
        castCount: gl.getUniformLocation(this.castProg, "u_count"),
        castCasters: Array.from({ length: MAX_CASTERS }, (_, i) =>
          gl.getUniformLocation(this.castProg!, `u_casters[${i}]`),
        ),
        castMeta: Array.from({ length: MAX_CASTERS }, (_, i) =>
          gl.getUniformLocation(this.castProg!, `u_meta[${i}]`),
        ),
        blurTex: gl.getUniformLocation(this.blurProg, "u_tex"),
        blurDir: gl.getUniformLocation(this.blurProg, "u_dir"),
        compNear: gl.getUniformLocation(this.compProg, "u_near"),
        compMid: gl.getUniformLocation(this.compProg, "u_mid"),
        compFar: gl.getUniformLocation(this.compProg, "u_far"),
        compR0: gl.getUniformLocation(this.compProg, "u_region0"),
        compR1: gl.getUniformLocation(this.compProg, "u_region1"),
        compR2: gl.getUniformLocation(this.compProg, "u_region2"),
        compSplits: gl.getUniformLocation(this.compProg, "u_splits"),
        compOpacity: gl.getUniformLocation(this.compProg, "u_opacity"),
        compDebug: gl.getUniformLocation(this.compProg, "u_debug"),
      };

      this.ready = true;
      return true;
    } catch {
      this.ready = false;
      this.gl = null;
      return false;
    }
  }

  /** Set CSM focus in screen pixels (typically sub / view center). */
  setFocus(sx: number, sy: number) {
    this.focusX = sx;
    this.focusY = sy;
  }

  resize(viewW: number, viewH: number) {
    if (!this.gl || !this.ready) return;

    const resolutions = computeCascadeResolutions(viewW, viewH);
    const needRebuild =
      this.cascades.length !== NUM_CASCADES ||
      this.cascades.some((c, i) => Math.abs(c.res - resolutions[i]!) >= RESIZE_HYSTERESIS) ||
      Math.abs(viewW - this.viewW) > 64 ||
      Math.abs(viewH - this.viewH) > 64;

    this.viewW = viewW;
    this.viewH = viewH;
    if (this.focusX === 0 && this.focusY === 0) {
      this.focusX = viewW * 0.5;
      this.focusY = viewH * 0.5;
    }

    // Composite canvas matches view aspect at mid-cascade density
    const outScale = (resolutions[1] ?? 384) / Math.max(viewW, viewH);
    const outW = snapDim(viewW * outScale);
    const outH = snapDim(viewH * outScale);
    if (this.canvas.width !== outW || this.canvas.height !== outH) {
      this.canvas.width = outW;
      this.canvas.height = outH;
    }

    if (!needRebuild && this.cascades.length === NUM_CASCADES) {
      this.updateStats(0);
      return;
    }

    const gl = this.gl;
    for (const c of this.cascades) {
      destroyTarget(gl, c.a);
      destroyTarget(gl, c.b);
    }
    this.cascades = [];

    for (let i = 0; i < NUM_CASCADES; i++) {
      const res = resolutions[i]!;
      const halfExtent = CASCADE_CFG[i]!.halfExtent;
      let a: Target;
      let b: Target;
      try {
        a = makeTarget(gl, res, res, this.useR8);
        b = makeTarget(gl, res, res, this.useR8);
      } catch {
        this.useR8 = false;
        a = makeTarget(gl, res, res, false);
        b = makeTarget(gl, res, res, false);
      }
      this.cascades.push({ a, b, res, halfExtent, casterCount: 0 });
    }

    this.updateStats(0);
  }

  clearCasters() {
    this.casters.length = 0;
  }

  addCaster(c: ShadowCaster) {
    if (this.casters.length >= MAX_CASTERS * 2) return;
    const margin = Math.max(c.rx, c.ry) * 3 + 48;
    if (
      c.sx < -margin ||
      c.sy < -margin ||
      c.sx > this.viewW + margin ||
      c.sy > this.viewH + margin
    ) {
      return;
    }
    this.casters.push(c);
  }

  /**
   * Render all cascades + composite.
   * @returns true if this.canvas holds the shadow layer (map-sized square).
   */
  render(sunDirX: number, sunDirY: number, opacity = 0.55): boolean {
    const gl = this.gl;
    const locs = this.locs;
    if (!gl || !this.ready || !this.castProg || !this.blurProg || !this.compProg || !locs) {
      return false;
    }
    if (this.cascades.length !== NUM_CASCADES || this.viewW < 2) return false;

    const sunLen = Math.hypot(sunDirX, sunDirY) || 1;
    const sunU = sunDirX / sunLen;
    const sunV = -sunDirY / sunLen; // flip Y for GL UV

    const focusU = this.focusX / this.viewW;
    const focusV = 1 - this.focusY / this.viewH;

    // Aspect-correct half extents so cascades are circles in screen space
    const aspect = this.viewW / Math.max(1, this.viewH);

    const regions: [number, number, number, number][] = [];
    for (let i = 0; i < NUM_CASCADES; i++) {
      const he = this.cascades[i]!.halfExtent;
      // half extent in UV: x adjusted by aspect so coverage is roughly circular
      const halfX = he;
      const halfY = he * aspect;
      regions.push([focusU, focusV, halfX, halfY]);
    }

    // Splits ≈ near/mid outer radii (for composite selection)
    const split0 = CASCADE_CFG[0]!.halfExtent * 0.95;
    const split1 = CASCADE_CFG[1]!.halfExtent * 0.95;

    let totalCasters = 0;

    for (let ci = 0; ci < NUM_CASCADES; ci++) {
      const cascade = this.cascades[ci]!;
      const region = regions[ci]!;
      const [rcx, rcy, rhx, rhy] = region;

      // Assign casters that overlap this cascade frustum
      const batch: ShadowCaster[] = [];
      for (const c of this.casters) {
        const cu = c.sx / this.viewW;
        const cv = 1 - c.sy / this.viewH;
        const ru = Math.max(c.rx / this.viewW, 0.002);
        const rv = Math.max(c.ry / this.viewH, 0.002);
        // Expanded AABB test (include cast length)
        const expand = 0.08 * c.height + 0.02;
        if (
          cu + ru + expand < rcx - rhx ||
          cu - ru - expand > rcx + rhx ||
          cv + rv + expand < rcy - rhy ||
          cv - rv - expand > rcy + rhy
        ) {
          continue;
        }
        batch.push(c);
        if (batch.length >= MAX_CASTERS) break;
      }
      cascade.casterCount = batch.length;
      totalCasters += batch.length;

      const res = cascade.res;
      // Sun offset in screen-UV, cast shader multiplies by height
      const sunScale = 0.05;

      // Cast
      gl.bindFramebuffer(gl.FRAMEBUFFER, cascade.a.fbo);
      gl.viewport(0, 0, res, res);
      gl.disable(gl.BLEND);
      gl.clearColor(0, 0, 0, 1);
      gl.clear(gl.COLOR_BUFFER_BIT);
      gl.useProgram(this.castProg);
      gl.bindVertexArray(this.vao);
      gl.uniform2f(locs.castSun, sunU * sunScale, sunV * sunScale);
      gl.uniform4f(locs.castRegion, rcx, rcy, rhx, rhy);
      gl.uniform1i(locs.castCount, batch.length);

      for (let i = 0; i < batch.length; i++) {
        const c = batch[i]!;
        const depth = c.depth ?? 0;
        const str = (c.strength ?? 1) * (1 - depth * 0.35);
        const height = c.height * (1 + depth * 0.6);
        gl.uniform4f(
          locs.castCasters[i]!,
          c.sx / this.viewW,
          1 - c.sy / this.viewH,
          Math.max(0.002, c.rx / this.viewW),
          Math.max(0.002, c.ry / this.viewH),
        );
        gl.uniform2f(locs.castMeta[i]!, str, height);
      }
      gl.drawArrays(gl.TRIANGLES, 0, 6);

      // Blur — wider in far cascade (softer distant shadows)
      const blurPx = (1.1 + ci * 0.35) * (512 / res);
      this.blurPass(cascade.a.tex, cascade.b.fbo, res, res, blurPx / res, 0);
      this.blurPass(cascade.b.tex, cascade.a.fbo, res, res, 0, blurPx / res);
    }

    // Composite cascades → canvas
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    gl.viewport(0, 0, this.canvas.width, this.canvas.height);
    gl.clearColor(0, 0, 0, 0);
    gl.clear(gl.COLOR_BUFFER_BIT);
    gl.enable(gl.BLEND);
    gl.blendFunc(gl.ONE, gl.ONE_MINUS_SRC_ALPHA);
    gl.useProgram(this.compProg);
    gl.bindVertexArray(this.vao);

    gl.activeTexture(gl.TEXTURE0);
    gl.bindTexture(gl.TEXTURE_2D, this.cascades[0]!.a.tex);
    gl.uniform1i(locs.compNear, 0);
    gl.activeTexture(gl.TEXTURE1);
    gl.bindTexture(gl.TEXTURE_2D, this.cascades[1]!.a.tex);
    gl.uniform1i(locs.compMid, 1);
    gl.activeTexture(gl.TEXTURE2);
    gl.bindTexture(gl.TEXTURE_2D, this.cascades[2]!.a.tex);
    gl.uniform1i(locs.compFar, 2);

    gl.uniform4f(locs.compR0, regions[0]![0], regions[0]![1], regions[0]![2], regions[0]![3]);
    gl.uniform4f(locs.compR1, regions[1]![0], regions[1]![1], regions[1]![2], regions[1]![3]);
    gl.uniform4f(locs.compR2, regions[2]![0], regions[2]![1], regions[2]![2], regions[2]![3]);
    gl.uniform2f(locs.compSplits, split0, split1);
    gl.uniform1f(locs.compOpacity, opacity);
    gl.uniform1f(locs.compDebug, this.debugCascades ? 1 : 0);

    gl.drawArrays(gl.TRIANGLES, 0, 6);
    gl.bindVertexArray(null);
    gl.disable(gl.BLEND);
    gl.activeTexture(gl.TEXTURE0);

    this.updateStats(totalCasters);
    return true;
  }

  private blurPass(
    srcTex: WebGLTexture,
    dstFbo: WebGLFramebuffer,
    w: number,
    h: number,
    dx: number,
    dy: number,
  ) {
    const gl = this.gl!;
    const locs = this.locs!;
    gl.bindFramebuffer(gl.FRAMEBUFFER, dstFbo);
    gl.viewport(0, 0, w, h);
    gl.useProgram(this.blurProg);
    gl.activeTexture(gl.TEXTURE0);
    gl.bindTexture(gl.TEXTURE_2D, srcTex);
    gl.uniform1i(locs.blurTex, 0);
    gl.uniform2f(locs.blurDir, dx, dy);
    gl.bindVertexArray(this.vao);
    gl.drawArrays(gl.TRIANGLES, 0, 6);
  }

  private updateStats(casters: number) {
    const cascadeInfo: CascadeInfo[] = this.cascades.map((c, i) => ({
      index: i,
      res: c.res,
      halfExtent: c.halfExtent,
      bytes: c.a.bytes + c.b.bytes,
      casters: c.casterCount,
    }));
    const bytes = cascadeInfo.reduce((s, c) => s + c.bytes, 0);
    const near = this.cascades[0]?.res ?? 0;
    this.lastStats = {
      viewW: this.viewW,
      viewH: this.viewH,
      mapW: near,
      mapH: near,
      scale: near / Math.max(1, this.viewW),
      bytes,
      casters,
      cascades: cascadeInfo,
      splits: [CASCADE_CFG[0]!.halfExtent, CASCADE_CFG[1]!.halfExtent],
    };
  }
}

let gpuShadows: GpuShadowMaps | null = null;

export function getGpuShadows(): GpuShadowMaps {
  if (!gpuShadows) {
    gpuShadows = new GpuShadowMaps();
    gpuShadows.init();
  }
  return gpuShadows;
}

/** Toggle RGB cascade visualization (near=R, mid=G, far=B). */
export function setShadowCascadeDebug(on: boolean) {
  getGpuShadows().debugCascades = on;
}
