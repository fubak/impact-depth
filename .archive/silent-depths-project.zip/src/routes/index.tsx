import { createFileRoute } from "@tanstack/react-router";
import { SubmarineGame } from "@/components/SubmarineGame";

export const Route = createFileRoute("/")({
  component: Home,
});

function Home() {
  return <SubmarineGame />;
}
