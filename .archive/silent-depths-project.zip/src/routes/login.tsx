import { createFileRoute, Link } from "@tanstack/react-router";
import { Anchor } from "lucide-react";
import { GROK_PROVIDERS, authEnabled, signIn } from "@/lib/auth/client";
import { useCurrentUserState } from "@/lib/auth/use-current-user";

export const Route = createFileRoute("/login")({
  component: Login,
});

function Login() {
  const { user, isPending } = useCurrentUserState();

  return (
    <main className="relative grid min-h-dvh place-items-center overflow-hidden bg-bg px-4 py-10 text-fg">
      <div
        className="pointer-events-none absolute inset-0 opacity-80"
        style={{
          background:
            "radial-gradient(ellipse 80% 50% at 50% 0%, rgba(59,158,255,0.18), transparent 60%), radial-gradient(ellipse 60% 40% at 80% 80%, rgba(94,234,212,0.08), transparent 50%)",
        }}
      />
      <div className="relative w-full max-w-md space-y-6 rounded-2xl border border-border bg-surface/90 p-6 shadow-2xl backdrop-blur-md sm:p-8">
        <div>
          <div className="mb-1 text-[10px] font-medium uppercase tracking-[0.2em] text-muted">
            Silent Depths
          </div>
          <h1 className="text-2xl font-semibold tracking-tight sm:text-3xl">
            Sign in to join the patrol
          </h1>
          <p className="mt-2 text-sm leading-relaxed text-muted">
            Use your X account so crewmates can see who is on the wire. Drop in
            anytime — open theater, no lobby codes required.
          </p>
        </div>

        {user ? (
          <div className="space-y-3">
            <p className="text-sm text-fg/90">
              Signed in as{" "}
              <strong className="font-medium">
                {user.displayName ?? user.primaryEmail ?? "Captain"}
              </strong>
            </p>
            <Link
              to="/"
              className="inline-flex min-h-11 w-full items-center justify-center gap-2 rounded-xl bg-fg px-4 text-sm font-semibold text-bg transition hover:brightness-110"
            >
              <Anchor size={16} />
              Enter theater
            </Link>
          </div>
        ) : authEnabled ? (
          <div className="space-y-2">
            {GROK_PROVIDERS.filter((p) => p.providerId === "grok-x").map((p) => (
              <button
                key={p.providerId}
                type="button"
                disabled={isPending}
                onClick={() => void signIn(p.providerId, { callbackURL: "/" })}
                className="flex min-h-12 w-full cursor-pointer items-center justify-center gap-2 rounded-xl border border-border bg-bg px-4 text-sm font-semibold transition hover:border-accent/50 hover:bg-fg/5 active:scale-[0.99] disabled:opacity-60"
              >
                <XMark />
                Continue with {p.label}
              </button>
            ))}
            {GROK_PROVIDERS.filter((p) => p.providerId !== "grok-x").map((p) => (
              <button
                key={p.providerId}
                type="button"
                disabled={isPending}
                onClick={() => void signIn(p.providerId, { callbackURL: "/" })}
                className="flex min-h-11 w-full cursor-pointer items-center justify-center gap-2 rounded-xl border border-border/70 bg-transparent px-4 text-sm font-medium text-muted transition hover:border-border hover:text-fg disabled:opacity-60"
              >
                Continue with {p.label}
              </button>
            ))}
          </div>
        ) : (
          <p className="text-sm text-muted">Sign-in is disabled in this environment.</p>
        )}

        <p className="text-center text-xs text-subtle">
          <Link to="/" className="underline-offset-4 hover:underline">
            Skip for now — play as guest
          </Link>
        </p>
      </div>
    </main>
  );
}

function XMark() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor" aria-hidden>
      <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-4.714-6.231-5.401 6.231H2.744l7.73-8.835L1.254 2.25H8.08l4.253 5.622L18.244 2.25zm-1.161 17.52h1.833L7.084 4.126H5.117L17.083 19.77z" />
    </svg>
  );
}
