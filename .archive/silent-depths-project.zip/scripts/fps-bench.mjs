import { chromium } from "playwright";

const browser = await chromium.launch({
  headless: true,
  args: ["--no-sandbox", "--disable-dev-shm-usage"],
});
const page = await browser.newPage({ viewport: { width: 1280, height: 800 } });
page.on("pageerror", (e) => console.log("PAGEERROR", e.message));
page.on("console", (m) => {
  if (m.type() === "error") console.log("CONSOLE", m.text());
});
await page.goto("http://127.0.0.1:8080/", { waitUntil: "networkidle", timeout: 30000 });
await page.waitForTimeout(1000);

const start = page.getByRole("button", { name: /begin patrol/i });
await start.first().click();
await page.waitForTimeout(1200);

const sampleFps = async (ms) =>
  page.evaluate(async (sampleMs) => {
    return new Promise((resolve) => {
      let frames = 0;
      let start = performance.now();
      function tick(now) {
        frames++;
        if (now - start >= sampleMs) {
          resolve({
            fps: Math.round((frames * 1000) / (now - start)),
            frames,
            ms: Math.round(now - start),
          });
          return;
        }
        requestAnimationFrame(tick);
      }
      requestAnimationFrame(tick);
    });
  }, ms);

const steady = await sampleFps(3000);
console.log("STEADY", JSON.stringify(steady));

await page.locator("canvas").click({ position: { x: 900, y: 300 } });
await page.waitForTimeout(300);
const moving = await sampleFps(2500);
console.log("MOVING", JSON.stringify(moving));

await page.screenshot({ path: "/workspace/screenshots/fps-after.png" });
await browser.close();
